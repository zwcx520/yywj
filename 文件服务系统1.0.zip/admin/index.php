<?php
/**
 * 樱屿文件管理器 · 站点后台
 * 概览 / 文件 / 成员 / 设置 / 日志
 */
declare(strict_types=1);

require dirname(__DIR__) . '/core.php';

$user = fm_require_login();
$isAdmin = ($user['role'] ?? '') === 'admin';
$csrf = fm_csrf();
$siteName = fm_site_name();

$tab = (string)($_GET['tab'] ?? 'overview');
if (!in_array($tab, ['overview', 'files', 'users', 'settings', 'logs'], true)) {
    $tab = 'overview';
}

$err = '';
$msgText = '';
$msgMap = [
    'saved'   => '站点设置已保存',
    'mkdir'   => '文件夹已创建',
    'upload'  => '文件已上传',
    'deleted' => '已删除',
    'added'   => '成员已添加',
    'removed' => '成员已删除',
    'reset'   => '密码已重置',
];
$msgKey = (string)($_GET['msg'] ?? '');
if (isset($msgMap[$msgKey])) {
    $msgText = $msgMap[$msgKey];
}

/* ------------------------------------------------------------------ *
 *  退出登录（无需管理员）
 * ------------------------------------------------------------------ */
if (($_POST['act'] ?? '') === 'logout') {
    fm_verify_csrf();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'] ?? '/', $p['domain'] ?? '', (bool)($p['secure'] ?? false), (bool)($p['httponly'] ?? true));
    }
    session_destroy();
    header('Location: ../index.php');
    exit;
}

if (!$isAdmin) {
    http_response_code(403);
}

/* ------------------------------------------------------------------ *
 *  后台动作
 * ------------------------------------------------------------------ */
$act = (string)($_POST['act'] ?? '');
if ($act !== '' && $act !== 'logout' && $isAdmin) {
    fm_verify_csrf();
    $db = fm_db();

    if ($act === 'settings_save') {
        $name = trim((string)($_POST['site_name'] ?? ''));
        $tagline = trim((string)($_POST['site_tagline'] ?? ''));
        $rootInput = trim((string)($_POST['root_dir'] ?? ''));
        if ($name === '') {
            $err = '站点名称不能为空';
        } elseif (mb_strlen($name) > 40) {
            $err = '站点名称最多 40 个字符';
        } else {
            $real = @realpath($rootInput);
            if ($rootInput === '' || $real === false || !is_dir($real)) {
                $err = '文件根目录不存在或不可访问';
            } else {
                fm_set('site_name', $name);
                fm_set('site_tagline', mb_substr($tagline, 0, 80));
                fm_set('root_dir', fm_from_sys($real));
                fm_set('allow_register', !empty($_POST['allow_register']) ? '1' : '0');
                header('Location: index.php?tab=settings&msg=saved');
                exit;
            }
        }
    } elseif (in_array($act, ['mkdir', 'upload', 'fdelete'], true)) {
        $f = fm_normalize_rel((string)($_POST['f'] ?? ''));
        $fileUid = (int)($_POST['user'] ?? 0);
        $fq = '&user=' . $fileUid . '&f=' . urlencode($f);
        $baseAbs = '';
        if ($db && $fileUid > 0) {
            try {
                $st = $db->prepare('SELECT username FROM fm_user WHERE id = ? LIMIT 1');
                $st->execute([$fileUid]);
                $fileUname = (string)($st->fetchColumn() ?: '');
            } catch (Throwable $e) {
                $fileUname = '';
            }
            if ($fileUname !== '') {
                $baseAbs = fm_user_dir($fileUname);
                if (!is_dir($baseAbs)) {
                    @mkdir($baseAbs, 0775, true);
                }
            }
        }
        if ($baseAbs === '') {
            $dirAbs = '';
            $err = '请先选择用户';
        } else {
            try {
                $dirAbs = fm_admin_join($baseAbs, $f);
            } catch (Throwable $e) {
                $dirAbs = '';
                $err = $e->getMessage();
            }
        }
        if ($err === '' && !is_dir($dirAbs)) {
            $err = '目标不是文件夹';
        }
        if ($err === '') {
            if ($act === 'mkdir') {
                $name = trim((string)($_POST['name'] ?? ''));
                if ($name === '' || $name === '.' || $name === '..' || preg_match('#[\\\\/:*?"<>|]#', $name)) {
                    $err = '文件夹名称不合法';
                } else {
                    $target = $dirAbs . DIRECTORY_SEPARATOR . fm_to_sys($name);
                    if (file_exists($target)) {
                        $err = '同名文件夹已存在';
                    } elseif (!@mkdir($target, 0775, true)) {
                        $err = '创建失败，请检查目录权限';
                    } else {
                        fm_log('新建文件夹', fm_join_rel($f, $name));
                        header('Location: index.php?tab=files' . $fq . '&msg=mkdir');
                        exit;
                    }
                }
            } elseif ($act === 'upload') {
                if (!isset($_FILES['file']) || (int)($_FILES['file']['error'] ?? 4) !== UPLOAD_ERR_OK) {
                    $err = '请选择要上传的文件';
                } else {
                    $base = basename((string)($_FILES['file']['name'] ?? ''));
                    $base = (string)preg_replace('/[\\\\\/:*?"<>|]+/u', '_', $base);
                    $base = trim($base);
                    if ($base === '' || $base === '.' || $base === '..') {
                        $err = '文件名无效';
                    } else {
                        $dest = $dirAbs . DIRECTORY_SEPARATOR . fm_to_sys($base);
                        if (!@move_uploaded_file($_FILES['file']['tmp_name'], $dest)) {
                            $err = '上传失败，请检查目录权限与上传大小限制';
                        } else {
                            @chmod($dest, 0644);
                            fm_log('上传文件', fm_join_rel($f, $base));
                            header('Location: index.php?tab=files' . $fq . '&msg=upload');
                            exit;
                        }
                    }
                }
            } else {
                $target = (string)($_POST['target'] ?? '');
                if ($target === '') {
                    $err = '参数错误';
                } else {
                    $rel = fm_join_rel($f, $target);
                    try {
                        $abs = fm_admin_join($baseAbs, $rel);
                        if (is_dir($abs) && !is_link($abs)) {
                            fm_rmdir_recursive($abs);
                        } else {
                            @unlink($abs);
                        }
                        fm_log('删除文件', $rel);
                        header('Location: index.php?tab=files' . $fq . '&msg=deleted');
                        exit;
                    } catch (Throwable $e) {
                        $err = $e->getMessage();
                    }
                }
            }
        }
    } elseif ($act === 'add') {
        $username = trim((string)($_POST['username'] ?? ''));
        $password = (string)($_POST['password'] ?? '');
        $nickname = trim((string)($_POST['nickname'] ?? ''));
        $role = ($_POST['role'] ?? 'user') === 'admin' ? 'admin' : 'user';
        if (!$db) {
            $err = '数据库连接失败';
        } elseif (!preg_match('/^[A-Za-z0-9_\x{4e00}-\x{9fa5}]{2,32}$/u', $username)) {
            $err = '账号需为 2-32 位的中文、字母、数字或下划线';
        } elseif (mb_strlen($password) < 6) {
            $err = '密码至少 6 位';
        } else {
            try {
                $st = $db->prepare('INSERT INTO fm_user (username, password_hash, nickname, role, created_at) VALUES (?, ?, ?, ?, NOW())');
                $st->execute([$username, password_hash($password, PASSWORD_DEFAULT), $nickname !== '' ? $nickname : $username, $role]);
                fm_ensure_user_dir($username);
                header('Location: index.php?tab=users&msg=added');
                exit;
            } catch (PDOException $e) {
                $err = ((string)$e->getCode() === '23000') ? '该账号已存在' : ('保存失败：' . $e->getMessage());
            }
        }
    } elseif ($act === 'reset_pass') {
        $id = (int)($_POST['id'] ?? 0);
        $password = (string)($_POST['password'] ?? '');
        if (!$db) {
            $err = '数据库连接失败';
        } elseif (mb_strlen($password) < 6) {
            $err = '新密码至少 6 位';
        } elseif ($id <= 0) {
            $err = '用户不存在';
        } else {
            $st = $db->prepare('UPDATE fm_user SET password_hash = ? WHERE id = ?');
            $st->execute([password_hash($password, PASSWORD_DEFAULT), $id]);
            if ($st->rowCount() < 1) {
                $chk = $db->prepare('SELECT id FROM fm_user WHERE id = ? LIMIT 1');
                $chk->execute([$id]);
                if (!$chk->fetchColumn()) {
                    $err = '用户不存在';
                }
            }
            if ($err === '') {
                header('Location: index.php?tab=users&msg=reset');
                exit;
            }
        }
    } elseif ($act === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        if (!$db) {
            $err = '数据库连接失败';
        } elseif ($id === (int)$user['id']) {
            $err = '不能删除当前登录的账号';
        } else {
            $st = $db->prepare('SELECT id, username, role FROM fm_user WHERE id = ? LIMIT 1');
            $st->execute([$id]);
            $target = $st->fetch();
            if (!$target) {
                $err = '用户不存在';
            } elseif (($target['role'] ?? '') === 'admin'
                && (int)$db->query("SELECT COUNT(*) FROM fm_user WHERE role = 'admin'")->fetchColumn() <= 1) {
                $err = '至少需要保留一个管理员账号';
            } else {
                fm_purge_user_files($id, (string)$target['username']);
                $db->prepare('DELETE FROM fm_user WHERE id = ?')->execute([$id]);
                header('Location: index.php?tab=users&msg=removed');
                exit;
            }
        }
    }
}

/* ------------------------------------------------------------------ *
 *  数据准备
 * ------------------------------------------------------------------ */
$db = fm_db();
$users = [];
$logRows = [];
if ($db) {
    if (in_array($tab, ['users', 'overview', 'files'], true)) {
        try {
            $users = $db->query('SELECT id, username, nickname, role, created_at, last_login FROM fm_user ORDER BY id ASC')->fetchAll();
        } catch (Throwable $e) {
            $err = $err !== '' ? $err : '读取成员失败';
        }
    }
    if ($tab === 'logs' || $tab === 'overview') {
        try {
            $logRows = $db->query('SELECT * FROM fm_log ORDER BY id DESC LIMIT 50')->fetchAll();
        } catch (Throwable $e) {
            // 忽略
        }
    }
}

$rootAbs = fm_root_dir();
$rootDisplay = fm_from_sys($rootAbs);

/**
 * 将相对路径安全地拼到指定用户目录下，防止越界
 */
function fm_admin_join(string $baseAbs, string $rel): string
{
    $base = realpath($baseAbs);
    if ($base === false) {
        throw new RuntimeException('用户目录不存在');
    }
    $target = $rel === '' ? $base : $base . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $rel);
    $real = realpath($target);
    if ($real === false) {
        throw new RuntimeException('路径不存在');
    }
    $b = str_replace('\\', '/', $base);
    $r = str_replace('\\', '/', $real);
    if (strpos($r . '/', rtrim($b, '/') . '/') !== 0) {
        throw new RuntimeException('路径越界');
    }
    return $real;
}

/**
 * 递归统计文件数量与占用（带上限，避免超大目录卡死）
 */
function fm_admin_stats(string $dir, int &$files, int &$dirs, int &$size, int $depth = 0, int &$budget = 20000): void
{
    if ($depth > 16 || $budget <= 0) {
        return;
    }
    $items = @scandir($dir);
    if ($items === false) {
        return;
    }
    foreach ($items as $item) {
        if ($budget <= 0) {
            return;
        }
        if ($item === '.' || $item === '..') {
            continue;
        }
        $p = $dir . DIRECTORY_SEPARATOR . $item;
        if (is_dir($p) && !is_link($p)) {
            $dirs++;
            fm_admin_stats($p, $files, $dirs, $size, $depth + 1, $budget);
        } elseif (is_file($p)) {
            $files++;
            $size += (int)@filesize($p);
            $budget--;
        }
    }
}

/**
 * 可在线预览的类型：image / video / audio / pdf / text / ''(不支持)
 */
function fm_admin_preview_kind(string $name): string
{
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    $images = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg', 'ico', 'avif'];
    $videos = ['mp4', 'webm', 'ogg', 'ogv', 'm4v', 'mov'];
    $audios = ['mp3', 'wav', 'ogg', 'm4a', 'aac', 'flac', 'opus'];
    $texts  = ['txt', 'md', 'markdown', 'log', 'json', 'xml', 'yml', 'yaml', 'ini', 'conf', 'cfg',
        'css', 'scss', 'less', 'js', 'mjs', 'ts', 'php', 'py', 'rb', 'java', 'c', 'h', 'cpp',
        'go', 'rs', 'sh', 'bash', 'bat', 'ps1', 'sql', 'html', 'htm', 'csv', 'env', 'htaccess'];
    if (in_array($ext, $images, true)) {
        return 'image';
    }
    if (in_array($ext, $videos, true)) {
        return 'video';
    }
    if (in_array($ext, $audios, true)) {
        return 'audio';
    }
    if ($ext === 'pdf') {
        return 'pdf';
    }
    if (in_array($ext, $texts, true)) {
        return 'text';
    }
    return '';
}

function fm_admin_size(int $bytes): string
{
    if ($bytes <= 0) {
        return '0 B';
    }
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = 0;
    $n = (float)$bytes;
    while ($n >= 1024 && $i < count($units) - 1) {
        $n /= 1024;
        $i++;
    }
    return ($i === 0 ? (string)round($n) : number_format($n, 1)) . ' ' . $units[$i];
}

$statFiles = 0;
$statDirs = 0;
$statSize = 0;
$budget = 0;
if ($tab === 'overview' && $isAdmin) {
    $budget = 20000;
    fm_admin_stats($rootAbs, $statFiles, $statDirs, $statSize, 0, $budget);
}

$diskFree = @disk_free_space($rootAbs);
$diskTotal = @disk_total_space($rootAbs);

/* --------- 文件页（按用户分类） --------- */
$curRel = '';
$curAbs = '';
$fileItems = [];
$crumbs = [];
$fileUser = null;
$fileUserCards = [];
$previewKind = '';
$previewText = '';
$previewRaw = '';
$previewName = '';
if ($tab === 'files') {
    $fileUid = (int)($_GET['user'] ?? 0);
    if ($fileUid > 0 && $db) {
        try {
            $st = $db->prepare('SELECT id, username, nickname, role FROM fm_user WHERE id = ? LIMIT 1');
            $st->execute([$fileUid]);
            $row = $st->fetch();
            if ($row) {
                $fileUser = $row;
            }
        } catch (Throwable $e) {
            $fileUser = null;
        }
    }

    if (!$fileUser) {
        // 第一步：展示用户列表，点击后再查看该用户文件
        foreach ($users as $u) {
            $udir = fm_user_dir((string)$u['username']);
            $n = 0;
            $d = 0;
            $s = 0;
            $budget = 8000;
            if (is_dir($udir)) {
                fm_admin_stats($udir, $n, $d, $s, 0, $budget);
            }
            $fileUserCards[] = [
                'id'       => (int)$u['id'],
                'username' => (string)$u['username'],
                'nickname' => (string)($u['nickname'] !== '' ? $u['nickname'] : $u['username']),
                'role'     => (string)$u['role'],
                'initial'  => mb_substr((string)($u['nickname'] !== '' ? $u['nickname'] : $u['username']), 0, 1),
                'avatar'   => fm_avatar_url_for((string)$u['username'], '../api.php'),
                'files'    => $n,
                'size'     => $s,
            ];
        }
    } else {
        $userBase = fm_user_dir((string)$fileUser['username']);
        if (!is_dir($userBase)) {
            @mkdir($userBase, 0775, true);
        }
        $curRel = fm_normalize_rel((string)($_GET['f'] ?? ''));
        try {
            $curAbs = fm_admin_join($userBase, $curRel);
            if (!is_dir($curAbs)) {
                throw new RuntimeException('目标不是文件夹');
            }
        } catch (Throwable $e) {
            $curRel = '';
            $curAbs = $userBase;
            $err = $err !== '' ? $err : $e->getMessage();
        }
        $nick = (string)($fileUser['nickname'] ?? '') !== '' ? $fileUser['nickname'] : $fileUser['username'];
        $crumbs[] = ['name' => '用户列表', 'path' => '', 'list' => true];
        $crumbs[] = ['name' => (string)$nick, 'path' => ''];
        if ($curRel !== '') {
            $acc = [];
            foreach (explode('/', $curRel) as $seg) {
                $acc[] = $seg;
                $crumbs[] = ['name' => $seg, 'path' => implode('/', $acc)];
            }
        }
        $dh = @opendir($curAbs);
        if ($dh !== false) {
            while (($entry = readdir($dh)) !== false) {
                if ($entry === '.' || $entry === '..') {
                    continue;
                }
                $full = $curAbs . DIRECTORY_SEPARATOR . $entry;
                $name = fm_from_sys($entry);
                $isDir = is_dir($full);
                $fileItems[] = [
                    'name'  => $name,
                    'dir'   => $isDir,
                    'size'  => $isDir ? 0 : (int)@filesize($full),
                    'mtime' => (int)@filemtime($full),
                    'rel'   => fm_join_rel($curRel, $name),
                    'kind'  => $isDir ? '' : fm_admin_preview_kind($name),
                ];
            }
            closedir($dh);
        }
        usort($fileItems, function (array $a, array $b): int {
            if ($a['dir'] !== $b['dir']) {
                return $a['dir'] ? -1 : 1;
            }
            return strnatcasecmp($a['name'], $b['name']);
        });

        // 在线预览（仅限当前目录下的文件）
        $previewName = trim((string)($_GET['view'] ?? ''));
        if ($previewName !== '' && basename($previewName) === $previewName) {
            $pAbs = $curAbs . DIRECTORY_SEPARATOR . fm_to_sys($previewName);
            if (is_file($pAbs)) {
                $previewKind = fm_admin_preview_kind($previewName);
                if ($previewKind !== '') {
                    $previewRaw = fm_user_dir_name((string)$fileUser['username'])
                        . ($curRel !== '' ? '/' . $curRel : '') . '/' . $previewName;
                    if ($previewKind === 'text') {
                        $previewText = (string)@file_get_contents($pAbs, false, null, 0, 200000);
                    }
                }
            }
        }
    }
}

$initial = mb_substr($user['nickname'] !== '' ? $user['nickname'] : $user['username'], 0, 1);
$avatarUrl = fm_avatar_url_for((string)$user['username'], '../api.php');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#f9f1fb">
<title>后台管理 · <?= htmlspecialchars($siteName, ENT_QUOTES, 'UTF-8') ?></title>
<link rel="icon" href="data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🌸</text></svg>">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/remixicon@4.5.0/fonts/remixicon.css">
<style>
*{box-sizing:border-box}
:root{
  --ink:#3b3350;--ink2:#6f6485;--ink3:#9a90ad;
  --line:rgba(120,90,160,.13);
  --grad:linear-gradient(135deg,#ec8bb6,#a58bf3);
  --shadow:0 26px 60px -34px rgba(110,80,160,.45);
}
body{
  margin:0;min-height:100vh;color:var(--ink);
  font:14px/1.65 "PingFang SC","Microsoft YaHei",system-ui,-apple-system,sans-serif;
  background:#f8f4fb;
  background-image:radial-gradient(900px 600px at 12% -10%,rgba(236,139,182,.22),transparent 60%),
    radial-gradient(760px 540px at 92% 4%,rgba(165,139,243,.24),transparent 62%);
  padding:24px;
}
a{color:inherit;text-decoration:none}
.wrap{max-width:1120px;margin:0 auto}
.bar{display:flex;align-items:center;gap:14px;margin-bottom:18px;flex-wrap:wrap}
.bar .back{font-size:12.5px;color:var(--ink2);display:inline-flex;align-items:center;gap:6px}
.bar .back:hover{color:#8a67c9}
.title{font-weight:700;font-size:17px;flex:1;min-width:0}
.logout{margin:0}
.logout button{
  height:34px;padding:0 14px;border-radius:10px;border:1px solid var(--line);
  background:rgba(255,255,255,.6);color:var(--ink2);font:inherit;font-size:12.5px;cursor:pointer;
  display:inline-flex;align-items:center;gap:6px;
}
.logout button:hover{color:#c94f6d;border-color:rgba(227,111,140,.35)}
.flash{margin-bottom:14px;padding:11px 14px;border-radius:12px;font-size:12.5px;display:flex;align-items:center;gap:8px}
.flash.ok{background:rgba(110,205,155,.14);color:#2f7d57}
.flash.bad{background:rgba(227,111,140,.12);color:#b23f5c}

.tabs{display:flex;gap:6px;overflow-x:auto;padding:5px;border-radius:14px;background:rgba(255,255,255,.62);border:1px solid var(--line);margin-bottom:18px}
.tabs a{padding:9px 16px;border-radius:10px;font-size:13px;color:var(--ink2);white-space:nowrap;display:inline-flex;align-items:center;gap:6px}
.tabs a:hover{background:rgba(255,255,255,.75);color:var(--ink)}
.tabs a.on{background:var(--grad);color:#fff;box-shadow:0 12px 24px -16px rgba(150,110,210,.9)}

.panel{background:rgba(255,255,255,.72);border:1px solid rgba(255,255,255,.9);border-radius:18px;box-shadow:var(--shadow);padding:20px 22px;margin-bottom:18px;backdrop-filter:blur(16px)}
.panel h2{font-size:14px;margin:0 0 14px;display:flex;align-items:center;gap:8px;color:var(--ink)}
.panel h2 em{font-style:normal;font-size:11.5px;color:var(--ink3);font-weight:400;margin-left:auto}

.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px}
.card{padding:15px 16px;border-radius:14px;background:rgba(255,255,255,.74);border:1px solid var(--line)}
.card small{display:block;font-size:11.5px;color:var(--ink3)}
.card b{display:block;font-size:20px;margin-top:4px;letter-spacing:-.02em}
.card i{color:#a58bf3;font-size:16px;margin-right:4px}

.people{display:flex;flex-direction:column;gap:2px}
.person{display:flex;align-items:center;gap:11px;padding:9px 8px;border-radius:12px}
.person:hover{background:rgba(250,246,255,.9)}
.avatar{width:36px;height:36px;border-radius:12px;display:grid;place-items:center;font-weight:650;color:#fff;flex:none;
  background:linear-gradient(135deg,#ec8bb6,#a58bf3);overflow:hidden}
.avatar img{width:100%;height:100%;object-fit:cover;display:block}
.info{flex:1;min-width:0}
.info b{font-size:13px;display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.info small{display:block;font-size:11px;color:#948aa8;margin-top:1px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.pill{font-size:10.5px;padding:3px 9px;border-radius:99px;background:rgba(178,149,238,.16);color:#7d63b3;white-space:nowrap}
.pill.admin{background:rgba(232,139,182,.18);color:#b3557f}
.del{width:32px;height:32px;border-radius:10px;display:grid;place-items:center;border:0;background:transparent;color:#a89cbb;cursor:pointer;font-size:15px;flex:none}
.del:hover{background:rgba(227,111,140,.12);color:#c94f6d}
.del.reset:hover{background:rgba(165,139,243,.14);color:#7c5bd6}

form.add{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.field{display:flex;flex-direction:column;gap:6px}
.field span{font-size:12px;color:#7a6d92}
.field input,.field select,.field textarea{height:40px;border-radius:10px;border:1px solid #e4dff0;background:#fdfcff;padding:0 12px;font:inherit;color:inherit;outline:none}
.field textarea{height:auto;padding:10px 12px;resize:vertical}
.field input:focus,.field select:focus,.field textarea:focus{border-color:#c3a6e8;box-shadow:0 0 0 3px rgba(180,150,240,.14)}
.actions{grid-column:1/-1;display:flex;gap:10px;margin-top:4px}
.btn{height:40px;padding:0 20px;border-radius:11px;border:0;cursor:pointer;font:inherit;font-weight:600;color:#fff;background:var(--grad)}
.btn:hover{filter:brightness(1.04)}
.btn.ghost{background:rgba(255,255,255,.8);color:var(--ink2);border:1px solid var(--line);font-weight:500}
.btn.small{height:34px;padding:0 14px;font-size:12.5px}

.crumbs{display:flex;align-items:center;gap:6px;flex-wrap:wrap;font-size:12.5px;color:var(--ink2);margin-bottom:12px}
.crumbs a{padding:3px 8px;border-radius:8px}
.crumbs a:hover{background:rgba(255,255,255,.85)}
.crumbs i{color:#c9bfdd;font-size:12px}

.files{display:flex;flex-direction:column;gap:1px}
.frow{display:flex;align-items:center;gap:10px;padding:9px 8px;border-radius:10px}
.frow:hover{background:rgba(250,246,255,.9)}
.frow .ico{width:30px;height:30px;border-radius:9px;display:grid;place-items:center;flex:none;font-size:15px;background:rgba(165,139,243,.12);color:#8b6fd3}
.frow .ico.folder{background:rgba(236,139,182,.14);color:#cf6f9c}
.frow .fname{flex:1;min-width:0;font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.frow .fname a:hover{color:#8a67c9}
.frow .fsize{font-size:11.5px;color:var(--ink3);white-space:nowrap}
.frow .fdate{font-size:11.5px;color:var(--ink3);white-space:nowrap}
.frow .fops{display:flex;gap:2px;opacity:.55}
.frow:hover .fops{opacity:1}
.fops a,.fops button{width:28px;height:28px;border-radius:8px;display:grid;place-items:center;border:0;background:transparent;color:#a89cbb;cursor:pointer;font-size:14px}
.fops a:hover{background:rgba(165,139,243,.14);color:#7c5bd6}
.fops button:hover{background:rgba(227,111,140,.12);color:#c94f6d}
.toolbar{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:14px}
.toolbar form{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.toolbar input[type=text]{height:36px;border-radius:10px;border:1px solid #e4dff0;background:#fdfcff;padding:0 11px;font:inherit;font-size:12.5px;outline:none;min-width:150px}
.toolbar input[type=file]{font-size:12px;color:var(--ink2);max-width:190px}
.note{font-size:11.5px;color:var(--ink3);line-height:1.7;margin:10px 0 0}
.toggle-line{display:flex;align-items:center;gap:8px;font-size:12.5px;color:var(--ink2);cursor:pointer}
.toggle-line input{width:16px;height:16px;accent-color:#a58bf3;cursor:pointer;margin:0}
.toggle-line em{font-style:normal}
.pvc{margin-left:auto;font-size:11.5px;font-weight:400;color:var(--ink3);text-decoration:none;display:inline-flex;align-items:center;gap:3px}
.pvc:hover{color:#8a67c9}
.pvbox{display:flex;justify-content:center;align-items:center;background:#f8f5fc;border-radius:12px;padding:10px;max-height:70vh;overflow:auto}
.pvbox img,.pvbox video{max-width:100%;max-height:66vh;border-radius:8px}
.pvbox audio{width:100%;max-width:460px}
.pvbox iframe{width:100%;height:66vh;border:0;border-radius:8px;background:#fff}
.pvtext{max-height:66vh;overflow:auto;background:#f8f5fc;border-radius:12px;padding:14px;font:12.5px/1.7 ui-monospace,Consolas,monospace;white-space:pre-wrap;word-break:break-word;margin:0}

.ufiles{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:10px}
.ucard{display:flex;align-items:center;gap:11px;padding:12px;border-radius:13px;background:rgba(253,251,255,.75);border:1px solid rgba(160,140,190,.14);color:inherit;text-decoration:none;transition:background .18s,border-color .18s}
.ucard:hover{background:rgba(248,241,255,.95);border-color:rgba(165,139,243,.35)}
.ucard .uavatar{width:38px;height:38px;border-radius:12px;flex:none;display:grid;place-items:center;overflow:hidden;background:linear-gradient(135deg,#f3c9dd,#cdbdf5);color:#fff;font-size:15px;font-weight:600}
.ucard .uavatar img{width:100%;height:100%;object-fit:cover}
.ucard .uinfo{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}
.ucard .uinfo b{font-size:13px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ucard .uinfo small{font-size:11px;color:var(--ink3);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ucard .ustat{font-size:11px;color:var(--ink3);white-space:nowrap}
.ucard i{color:#c9bfdd;font-size:15px}

table.logs{width:100%;border-collapse:collapse;font-size:12.5px}
table.logs th,table.logs td{text-align:left;padding:9px 8px;border-bottom:1px solid rgba(120,90,160,.08);vertical-align:top}
table.logs th{color:var(--ink3);font-weight:500;font-size:11.5px}
table.logs td.t{white-space:nowrap;color:var(--ink3);font-size:11.5px}
.empty{color:#948aa8;font-size:12.5px;padding:10px 0}

@media(max-width:640px){
  body{padding:16px 12px 32px}
  .panel{padding:16px 14px;border-radius:15px}
  form.add{grid-template-columns:1fr}
  .person{padding:8px 4px}
  .frow .fdate{display:none}
  .ufiles{grid-template-columns:1fr}
  .ucard .ustat{display:none}
  .cards{grid-template-columns:repeat(auto-fit,minmax(120px,1fr))}
  .title{font-size:15px}
  table.logs{display:block;overflow-x:auto;white-space:nowrap}
}
</style>
</head>
<body>
<div class="wrap">
  <div class="bar">
    <a class="back" href="../index.php"><i class="ri-arrow-left-line"></i> 返回文件管理</a>
    <div class="title">🌸 <?= htmlspecialchars($siteName, ENT_QUOTES, 'UTF-8') ?> · 后台管理</div>
    <form method="post" class="logout">
      <input type="hidden" name="_csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
      <button type="submit" name="act" value="logout"><i class="ri-logout-box-r-line"></i> 退出登录</button>
    </form>
  </div>

  <?php if (!$isAdmin): ?>
    <div class="flash bad">只有管理员可以访问后台。</div>
  <?php else: ?>
    <?php if ($msgText !== ''): ?>
      <div class="flash ok"><i class="ri-checkbox-circle-line"></i> <?= htmlspecialchars($msgText, ENT_QUOTES, 'UTF-8') ?></div>
    <?php endif; ?>
    <?php if ($err !== ''): ?>
      <div class="flash bad"><i class="ri-error-warning-line"></i> <?= htmlspecialchars($err, ENT_QUOTES, 'UTF-8') ?></div>
    <?php endif; ?>

    <nav class="tabs">
      <a class="<?= $tab === 'overview' ? 'on' : '' ?>" href="?tab=overview"><i class="ri-dashboard-3-line"></i> 概览</a>
      <a class="<?= $tab === 'files' ? 'on' : '' ?>" href="?tab=files"><i class="ri-folder-3-line"></i> 文件</a>
      <a class="<?= $tab === 'users' ? 'on' : '' ?>" href="?tab=users"><i class="ri-team-line"></i> 成员</a>
      <a class="<?= $tab === 'settings' ? 'on' : '' ?>" href="?tab=settings"><i class="ri-settings-4-line"></i> 设置</a>
      <a class="<?= $tab === 'logs' ? 'on' : '' ?>" href="?tab=logs"><i class="ri-file-list-3-line"></i> 日志</a>
    </nav>

    <?php if ($tab === 'overview'): ?>
      <section class="panel">
        <h2><i class="ri-dashboard-3-line"></i> 站点概览 <em><?= htmlspecialchars($rootDisplay, ENT_QUOTES, 'UTF-8') ?></em></h2>
        <div class="cards">
          <div class="card"><small><i class="ri-group-line"></i> 成员</small><b><?= count($users) ?></b></div>
          <div class="card"><small><i class="ri-file-3-line"></i> 文件</small><b><?= $statFiles ?><?= $budget <= 0 ? '+' : '' ?></b></div>
          <div class="card"><small><i class="ri-folder-3-line"></i> 文件夹</small><b><?= $statDirs ?></b></div>
          <div class="card"><small><i class="ri-hard-drive-3-line"></i> 占用</small><b><?= fm_admin_size($statSize) ?></b></div>
          <div class="card"><small><i class="ri-database-2-line"></i> 磁盘剩余</small><b><?= $diskFree === false ? '—' : fm_admin_size((int)$diskFree) ?></b></div>
        </div>
      </section>

      <section class="panel">
        <h2><i class="ri-server-line"></i> 系统信息</h2>
        <div class="cards">
          <div class="card"><small>PHP 版本</small><b style="font-size:15px"><?= htmlspecialchars(PHP_VERSION, ENT_QUOTES, 'UTF-8') ?></b></div>
          <div class="card"><small>压缩支持</small><b style="font-size:15px"><?= class_exists('ZipArchive') ? '已启用' : '未启用' ?></b></div>
          <div class="card"><small>上传限制</small><b style="font-size:15px"><?= htmlspecialchars(ini_get('upload_max_filesize') ?: '—', ENT_QUOTES, 'UTF-8') ?></b></div>
          <div class="card"><small>磁盘总量</small><b style="font-size:15px"><?= $diskTotal === false ? '—' : fm_admin_size((int)$diskTotal) ?></b></div>
        </div>
      </section>

      <section class="panel">
        <h2><i class="ri-history-line"></i> 最近操作 <em><a href="?tab=logs">查看全部</a></em></h2>
        <?php if (!$logRows): ?>
          <div class="empty">暂无日志</div>
        <?php else: ?>
          <table class="logs">
            <thead><tr><th>时间</th><th>成员</th><th>操作</th><th>对象</th></tr></thead>
            <tbody>
              <?php foreach (array_slice($logRows, 0, 8) as $row): ?>
              <tr>
                <td class="t"><?= htmlspecialchars((string)($row['created_at'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                <td><?= htmlspecialchars((string)($row['username'] ?? '-'), ENT_QUOTES, 'UTF-8') ?></td>
                <td><?= htmlspecialchars((string)($row['action'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                <td><?= htmlspecialchars((string)($row['target'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </section>

    <?php elseif ($tab === 'files'): ?>
      <?php if (!$fileUser): ?>
      <section class="panel">
        <h2><i class="ri-folder-user-line"></i> 用户文件 <em>共 <?= count($fileUserCards) ?> 位用户</em></h2>
        <div class="ufiles">
          <?php if (!$fileUserCards): ?>
            <div class="empty">还没有用户</div>
          <?php endif; ?>
          <?php foreach ($fileUserCards as $uc): ?>
            <a class="ucard" href="?tab=files&amp;user=<?= (int)$uc['id'] ?>">
              <span class="uavatar">
                <?php if ($uc['avatar'] !== ''): ?>
                  <img src="<?= htmlspecialchars($uc['avatar'], ENT_QUOTES, 'UTF-8') ?>" alt="">
                <?php else: ?>
                  <?= htmlspecialchars($uc['initial'], ENT_QUOTES, 'UTF-8') ?>
                <?php endif; ?>
              </span>
              <span class="uinfo">
                <b><?= htmlspecialchars($uc['nickname'], ENT_QUOTES, 'UTF-8') ?></b>
                <small>@<?= htmlspecialchars($uc['username'], ENT_QUOTES, 'UTF-8') ?> · <?= $uc['role'] === 'admin' ? '管理员' : '成员' ?></small>
              </span>
              <span class="ustat"><?= (int)$uc['files'] ?> 个文件 · <?= fm_admin_size($uc['size']) ?></span>
              <i class="ri-arrow-right-s-line"></i>
            </a>
          <?php endforeach; ?>
        </div>
        <p class="note">先选择用户，再查看和管理该用户个人目录中的文件。</p>
      </section>
      <?php else: ?>
      <?php if ($previewKind !== ''): ?>
      <section class="panel">
        <h2><i class="ri-eye-2-line"></i> <?= htmlspecialchars($previewName, ENT_QUOTES, 'UTF-8') ?>
          <a class="pvc" href="?tab=files&amp;user=<?= (int)$fileUser['id'] ?>&amp;f=<?= urlencode($curRel) ?>"><i class="ri-close-line"></i> 关闭预览</a>
        </h2>
        <?php if ($previewKind === 'image'): ?>
          <div class="pvbox"><img src="../api.php?action=raw&amp;path=<?= urlencode($previewRaw) ?>" alt=""></div>
        <?php elseif ($previewKind === 'video'): ?>
          <div class="pvbox"><video controls preload="metadata" src="../api.php?action=raw&amp;path=<?= urlencode($previewRaw) ?>"></video></div>
        <?php elseif ($previewKind === 'audio'): ?>
          <div class="pvbox"><audio controls preload="metadata" src="../api.php?action=raw&amp;path=<?= urlencode($previewRaw) ?>"></audio></div>
        <?php elseif ($previewKind === 'pdf'): ?>
          <div class="pvbox"><iframe src="../api.php?action=raw&amp;path=<?= urlencode($previewRaw) ?>" title="PDF 预览"></iframe></div>
        <?php else: ?>
          <pre class="pvtext"><?= htmlspecialchars($previewText, ENT_QUOTES, 'UTF-8') ?></pre>
        <?php endif; ?>
        <p class="note"><a href="../api.php?action=download&amp;path=<?= urlencode($previewRaw) ?>">下载该文件</a></p>
      </section>
      <?php endif; ?>
      <section class="panel">
        <h2><i class="ri-folder-3-line"></i> <?= htmlspecialchars((string)((string)($fileUser['nickname'] ?? '') !== '' ? $fileUser['nickname'] : $fileUser['username']), ENT_QUOTES, 'UTF-8') ?> 的文件 <em>共 <?= count($fileItems) ?> 项</em></h2>

        <div class="crumbs">
          <?php foreach ($crumbs as $i => $c): ?>
            <?php if ($i > 0): ?><i class="ri-arrow-right-s-line"></i><?php endif; ?>
            <?php if (!empty($c['list'])): ?>
              <a href="?tab=files"><?= htmlspecialchars($c['name'], ENT_QUOTES, 'UTF-8') ?></a>
            <?php elseif ($i === 1): ?>
              <a href="?tab=files&amp;user=<?= (int)$fileUser['id'] ?>"><?= htmlspecialchars($c['name'], ENT_QUOTES, 'UTF-8') ?></a>
            <?php else: ?>
              <a href="?tab=files&amp;user=<?= (int)$fileUser['id'] ?>&amp;f=<?= urlencode($c['path']) ?>"><?= htmlspecialchars($c['name'], ENT_QUOTES, 'UTF-8') ?></a>
            <?php endif; ?>
          <?php endforeach; ?>
        </div>

        <div class="toolbar">
          <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="_csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
            <input type="hidden" name="act" value="upload">
            <input type="hidden" name="user" value="<?= (int)$fileUser['id'] ?>">
            <input type="hidden" name="f" value="<?= htmlspecialchars($curRel, ENT_QUOTES, 'UTF-8') ?>">
            <input type="file" name="file" required>
            <button class="btn small" type="submit"><i class="ri-upload-cloud-line"></i> 上传</button>
          </form>
          <form method="post">
            <input type="hidden" name="_csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
            <input type="hidden" name="act" value="mkdir">
            <input type="hidden" name="user" value="<?= (int)$fileUser['id'] ?>">
            <input type="hidden" name="f" value="<?= htmlspecialchars($curRel, ENT_QUOTES, 'UTF-8') ?>">
            <input type="text" name="name" placeholder="新文件夹名称" required>
            <button class="btn small ghost" type="submit"><i class="ri-folder-add-line"></i> 新建</button>
          </form>
        </div>

        <div class="files">
          <?php if (!$fileItems): ?>
            <div class="empty">此文件夹为空</div>
          <?php endif; ?>
          <?php foreach ($fileItems as $fi): ?>
            <?php $dlPath = fm_user_dir_name((string)$fileUser['username']) . ($curRel !== '' ? '/' . $curRel : '') . '/' . $fi['name']; ?>
            <div class="frow">
              <span class="ico<?= $fi['dir'] ? ' folder' : '' ?>"><i class="ri-<?= $fi['dir'] ? 'folder-3-fill' : 'file-3-line' ?>"></i></span>
              <span class="fname">
                <?php if ($fi['dir']): ?>
                  <a href="?tab=files&amp;user=<?= (int)$fileUser['id'] ?>&amp;f=<?= urlencode($fi['rel']) ?>"><?= htmlspecialchars($fi['name'], ENT_QUOTES, 'UTF-8') ?></a>
                <?php elseif ($fi['kind'] !== ''): ?>
                  <a href="?tab=files&amp;user=<?= (int)$fileUser['id'] ?>&amp;f=<?= urlencode($curRel) ?>&amp;view=<?= urlencode($fi['name']) ?>"><?= htmlspecialchars($fi['name'], ENT_QUOTES, 'UTF-8') ?></a>
                <?php else: ?>
                  <?= htmlspecialchars($fi['name'], ENT_QUOTES, 'UTF-8') ?>
                <?php endif; ?>
              </span>
              <span class="fsize"><?= $fi['dir'] ? '—' : fm_admin_size($fi['size']) ?></span>
              <span class="fdate"><?= $fi['mtime'] > 0 ? date('Y-m-d H:i', $fi['mtime']) : '—' ?></span>
              <span class="fops">
                <?php if (!$fi['dir']): ?>
                  <a href="../api.php?action=download&amp;path=<?= urlencode($dlPath) ?>" title="下载"><i class="ri-download-2-line"></i></a>
                <?php endif; ?>
                <form method="post" onsubmit="return confirm('确定删除 <?= htmlspecialchars($fi['name'], ENT_QUOTES, 'UTF-8') ?> 吗？');" style="margin:0">
                  <input type="hidden" name="_csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
                  <input type="hidden" name="act" value="fdelete">
                  <input type="hidden" name="user" value="<?= (int)$fileUser['id'] ?>">
                  <input type="hidden" name="f" value="<?= htmlspecialchars($curRel, ENT_QUOTES, 'UTF-8') ?>">
                  <input type="hidden" name="target" value="<?= htmlspecialchars($fi['name'], ENT_QUOTES, 'UTF-8') ?>">
                  <button type="submit" title="删除"><i class="ri-delete-bin-6-line"></i></button>
                </form>
              </span>
            </div>
          <?php endforeach; ?>
        </div>
        <p class="note">当前操作仅作用于该用户的个人目录，删除不可恢复。</p>
      </section>
      <?php endif; ?>

    <?php elseif ($tab === 'users'): ?>
      <section class="panel">
        <h2><i class="ri-team-line"></i> 成员列表 <em>共 <?= count($users) ?> 人</em></h2>
        <div class="people">
          <?php if (!$users): ?>
            <div class="empty">暂无成员</div>
          <?php endif; ?>
          <?php foreach ($users as $u):
              $name = (string)($u['nickname'] !== '' ? $u['nickname'] : $u['username']);
              $self = (int)$u['id'] === (int)$user['id'];
              $isAdminRow = ($u['role'] ?? '') === 'admin';
              $av = fm_avatar_url_for((string)$u['username'], '../api.php');
          ?>
            <div class="person">
              <div class="avatar">
                <?php if ($av !== ''): ?>
                <img src="<?= htmlspecialchars($av, ENT_QUOTES, 'UTF-8') ?>" alt="头像">
                <?php else: ?>
                <?= htmlspecialchars(mb_substr($name, 0, 1), ENT_QUOTES, 'UTF-8') ?>
                <?php endif; ?>
              </div>
              <div class="info">
                <b><?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?><?= $self ? '（当前登录）' : '' ?></b>
                <small>@<?= htmlspecialchars((string)$u['username'], ENT_QUOTES, 'UTF-8') ?> ·
                  <?= $u['last_login'] ? '最近登录 ' . htmlspecialchars((string)$u['last_login'], ENT_QUOTES, 'UTF-8') : '从未登录' ?>
                </small>
              </div>
              <span class="pill<?= $isAdminRow ? ' admin' : '' ?>"><?= $isAdminRow ? '管理员' : '成员' ?></span>
              <form method="post" onsubmit="var p=prompt('为 <?= htmlspecialchars((string)$u['username'], ENT_QUOTES, 'UTF-8') ?> 设置新密码（至少 6 位）'); if(!p){return false;} if(p.length<6){alert('密码至少 6 位');return false;} this.querySelector('[name=password]').value=p; return true;">
                <input type="hidden" name="_csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
                <input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
                <input type="hidden" name="password" value="">
                <button class="del reset" type="submit" name="act" value="reset_pass" title="重置密码"><i class="ri-key-2-line"></i></button>
              </form>
              <?php if (!$self): ?>
                <form method="post" onsubmit="return confirm('确定要删除该成员及其头像、个人文件夹吗？');">
                  <input type="hidden" name="_csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
                  <input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
                  <button class="del" type="submit" name="act" value="delete" title="删除"><i class="ri-delete-bin-6-line"></i></button>
                </form>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>
        </div>
      </section>

      <section class="panel">
        <h2><i class="ri-user-add-line"></i> 添加成员</h2>
        <form method="post" class="add">
          <input type="hidden" name="_csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
          <input type="hidden" name="act" value="add">
          <label class="field">
            <span>账号</span>
            <input type="text" name="username" placeholder="2-32 位中文、字母、数字或下划线" autocomplete="off" required>
          </label>
          <label class="field">
            <span>昵称（可选）</span>
            <input type="text" name="nickname" placeholder="显示名称" autocomplete="off">
          </label>
          <label class="field">
            <span>初始密码</span>
            <input type="password" name="password" placeholder="至少 6 位" autocomplete="new-password" required>
          </label>
          <label class="field">
            <span>角色</span>
            <select name="role">
              <option value="user">成员</option>
              <option value="admin">管理员</option>
            </select>
          </label>
          <div class="actions">
            <button class="btn" type="submit"><i class="ri-user-add-line"></i> 添加成员</button>
          </div>
        </form>
      </section>

    <?php elseif ($tab === 'settings'): ?>
      <section class="panel">
        <h2><i class="ri-settings-4-line"></i> 站点设置</h2>
        <form method="post" class="add">
          <input type="hidden" name="_csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
          <input type="hidden" name="act" value="settings_save">
          <label class="field">
            <span>站点名称</span>
            <input type="text" name="site_name" maxlength="40" value="<?= htmlspecialchars($siteName, ENT_QUOTES, 'UTF-8') ?>" required>
          </label>
          <label class="field">
            <span>站点标语</span>
            <input type="text" name="site_tagline" maxlength="80" value="<?= htmlspecialchars(fm_site_tagline(), ENT_QUOTES, 'UTF-8') ?>">
          </label>
          <label class="field" style="grid-column:1/-1">
            <span>文件根目录（服务器绝对路径）</span>
            <input type="text" name="root_dir" value="<?= htmlspecialchars($rootDisplay, ENT_QUOTES, 'UTF-8') ?>" required>
          </label>
          <div class="field" style="grid-column:1/-1">
            <span>注册开关</span>
            <label class="toggle-line">
              <input type="checkbox" name="allow_register" value="1" <?= fm_setting('allow_register', '1') === '1' ? 'checked' : '' ?>>
              <em>允许访客在登录页自行注册账号</em>
            </label>
          </div>
          <div class="actions">
            <button class="btn" type="submit"><i class="ri-save-3-line"></i> 保存设置</button>
          </div>
        </form>
        <p class="note">修改根目录会改变文件管理器的可访问范围，请确保该目录存在且 PHP 有读写权限。</p>
      </section>

    <?php elseif ($tab === 'logs'): ?>
      <section class="panel">
        <h2><i class="ri-file-list-3-line"></i> 操作日志 <em>最近 50 条</em></h2>
        <?php if (!$logRows): ?>
          <div class="empty">暂无日志</div>
        <?php else: ?>
          <table class="logs">
            <thead><tr><th>时间</th><th>成员</th><th>操作</th><th>对象</th><th>IP</th></tr></thead>
            <tbody>
              <?php foreach ($logRows as $row): ?>
              <tr>
                <td class="t"><?= htmlspecialchars((string)($row['created_at'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                <td><?= htmlspecialchars((string)($row['username'] ?? '-'), ENT_QUOTES, 'UTF-8') ?></td>
                <td><?= htmlspecialchars((string)($row['action'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                <td><?= htmlspecialchars((string)($row['target'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                <td class="t"><?= htmlspecialchars((string)($row['ip'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </section>
    <?php endif; ?>
  <?php endif; ?>
</div>
</body>
</html>
