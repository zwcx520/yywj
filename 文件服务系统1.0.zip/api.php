<?php
/**
 * 樱屿文件管理器 · 接口层
 * 所有文件操作均限制在配置的文件根目录之内
 */
declare(strict_types=1);

require __DIR__ . '/core.php';

if (!fm_is_installed()) {
    fm_fail('数据目录 storage/data 无法写入，请检查目录权限', 503);
}

set_exception_handler(function (Throwable $e): void {
    fm_json(['ok' => false, 'error' => $e->getMessage()], 500);
});

$action = (string)($_GET['action'] ?? $_POST['action'] ?? '');

/* ------------------------------------------------------------------ *
 *  登录 / 登出
 * ------------------------------------------------------------------ */

if ($action === 'login') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        fm_fail('请求方式不正确', 405);
    }
    fm_verify_csrf();

    $loginInput = fm_input();
    $username = trim((string)($loginInput['username'] ?? ''));
    $password = (string)($loginInput['password'] ?? '');

    $db = fm_db();
    if (!$db) {
        fm_fail('数据库连接失败，请检查 config.php 中的配置', 500);
    }
    $st = $db->prepare('SELECT * FROM fm_user WHERE username = ? LIMIT 1');
    $st->execute([$username]);
    $row = $st->fetch();

    if (!$row || !password_verify($password, (string)$row['password_hash'])) {
        fm_fail('账号或密码不正确', 401);
    }

    session_regenerate_id(true);
    $_SESSION['uid'] = (int)$row['id'];
    $_SESSION['csrf'] = bin2hex(random_bytes(24));

    // 登录时可选上传/更换头像（仅作用于刚登录成功的账号）
    if (isset($_FILES['avatar']) && (int)($_FILES['avatar']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK) {
        $avatarErr = null;
        fm_save_avatar((int)$row['id'], $_FILES['avatar'], $avatarErr);
    }
    fm_ensure_user_dir((string)$row['username']);

    try {
        $db->prepare('UPDATE fm_user SET last_login = NOW() WHERE id = ?')->execute([(int)$row['id']]);
    } catch (Throwable $e) {
        // 忽略
    }

    fm_log('登录', '');

    fm_ok([
        'csrf' => $_SESSION['csrf'],
        'user' => [
            'id'       => (int)$row['id'],
            'username' => $row['username'],
            'nickname' => $row['nickname'] !== '' ? $row['nickname'] : $row['username'],
            'role'     => $row['role'],
            'avatar'   => fm_avatar_url($row),
        ],
    ]);
}

if ($action === 'logout') {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        fm_verify_csrf();
    }
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'] ?? '/', $p['domain'] ?? '', (bool)($p['secure'] ?? false), (bool)($p['httponly'] ?? true));
    }
    session_destroy();
    fm_ok();
}

/* ------------------------------------------------------------------ *
 *  注册（开放注册，新用户默认为普通成员）
 * ------------------------------------------------------------------ */

if ($action === 'register') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        fm_fail('请求方式不正确', 405);
    }
    fm_verify_csrf();
    if (fm_setting('allow_register', '1') !== '1') {
        fm_fail('站点暂未开放注册，请联系管理员');
    }

    $in = fm_input();
    $username = trim((string)($in['username'] ?? ''));
    $password = (string)($in['password'] ?? '');
    $password2 = (string)($in['password2'] ?? '');
    $nickname = trim((string)($in['nickname'] ?? ''));

    if (!preg_match('/^[A-Za-z0-9_\x{4e00}-\x{9fa5}]{2,32}$/u', $username)) {
        fm_fail('账号需为 2-32 位的中文、字母、数字或下划线');
    }
    if (mb_strlen($password) < 6) {
        fm_fail('密码至少 6 位');
    }
    if ($password !== $password2) {
        fm_fail('两次输入的密码不一致');
    }

    $db = fm_db();
    if (!$db) {
        fm_fail('数据库连接失败，请检查 config.php', 500);
    }

    try {
        $st = $db->prepare('INSERT INTO fm_user (username, password_hash, nickname, role, created_at) VALUES (?, ?, ?, ?, NOW())');
        $st->execute([
            $username,
            password_hash($password, PASSWORD_DEFAULT),
            $nickname !== '' ? $nickname : $username,
            'user',
        ]);
    } catch (PDOException $e) {
        if ((string)$e->getCode() === '23000') {
            fm_fail('该账号已被注册');
        }
        fm_fail('注册失败，请稍后再试', 500);
    }

    $uid = (int)$db->lastInsertId();
    session_regenerate_id(true);
    $_SESSION['uid'] = $uid;
    $_SESSION['csrf'] = bin2hex(random_bytes(24));

    if (isset($_FILES['avatar']) && (int)($_FILES['avatar']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK) {
        $avatarErr = null;
        fm_save_avatar($uid, $_FILES['avatar'], $avatarErr);
    }
    fm_ensure_user_dir($username);

    fm_log('注册', $username);

    fm_ok([
        'csrf' => $_SESSION['csrf'],
        'user' => [
            'id'       => $uid,
            'username' => $username,
            'nickname' => $nickname !== '' ? $nickname : $username,
            'role'     => 'user',
            'avatar'   => fm_avatar_url(['id' => $uid]),
        ],
    ]);
}

/* ------------------------------------------------------------------ *
 *  按账号获取头像（登录页使用，无需登录）
 * ------------------------------------------------------------------ */

if ($action === 'avatar_name') {
    $uname = trim((string)($_GET['username'] ?? ''));
    $path = $uname !== '' ? fm_avatar_path_for($uname) : null;
    if (!$path) {
        http_response_code(404);
        header('Content-Type: text/plain; charset=utf-8');
        header('Cache-Control: no-store');
        exit;
    }
    $ext = strtolower((string)pathinfo($path, PATHINFO_EXTENSION));
    $mimes = ['png' => 'image/png', 'gif' => 'image/gif', 'webp' => 'image/webp'];
    $mime = $mimes[$ext] ?? 'image/jpeg';
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    header('Content-Type: ' . $mime);
    header('Content-Length: ' . (int)@filesize($path));
    header('Cache-Control: private, max-age=60');
    header('X-Content-Type-Options: nosniff');
    readfile($path);
    exit;
}

$user = fm_require_login();

/* ------------------------------------------------------------------ *
 *  头像输出
 * ------------------------------------------------------------------ */

if ($action === 'avatar') {
    $uid = (int)($_GET['uid'] ?? 0);
    $path = fm_avatar_path($uid);
    if (!$path) {
        http_response_code(404);
        header('Content-Type: text/plain; charset=utf-8');
        echo '头像不存在';
        exit;
    }
    $ext = strtolower((string)pathinfo($path, PATHINFO_EXTENSION));
    $mimes = ['png' => 'image/png', 'gif' => 'image/gif', 'webp' => 'image/webp'];
    $mime = $mimes[$ext] ?? 'image/jpeg';
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    header('Content-Type: ' . $mime);
    header('Content-Length: ' . (int)@filesize($path));
    header('Cache-Control: private, max-age=86400');
    header('X-Content-Type-Options: nosniff');
    readfile($path);
    exit;
}

/* ------------------------------------------------------------------ *
 *  二进制输出：下载 / 预览
 * ------------------------------------------------------------------ */

if ($action === 'download' || $action === 'raw') {
    $rel = (string)($_GET['path'] ?? '');
    try {
        $abs = fm_abs($rel, true);
    } catch (Throwable $e) {
        http_response_code(404);
        header('Content-Type: text/plain; charset=utf-8');
        echo $e->getMessage();
        exit;
    }
    if (is_dir($abs)) {
        http_response_code(400);
        header('Content-Type: text/plain; charset=utf-8');
        echo '不能直接下载文件夹';
        exit;
    }

    // 释放 session 锁，避免大文件传输阻塞同一用户的其他请求
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }

    $inline = $action === 'raw';
    $name = fm_from_sys(basename($abs));
    $ext = fm_ext($name);
    $size = (int)@filesize($abs);
    $mime = fm_mime($ext);
    if ($inline && $mime === 'application/octet-stream') {
        $inline = false;
    }

    while (ob_get_level() > 1) {
        ob_end_clean();
    }
    if (ob_get_level() > 0) {
        ob_end_clean();
    }

    header('Content-Type: ' . $mime);
    header('Content-Length: ' . $size);
    header('Accept-Ranges: bytes');
    header('Content-Disposition: ' . ($inline ? 'inline' : 'attachment') . '; filename="' . preg_replace('/[^\x20-\x7E]/', '_', $name) . '"; filename*=UTF-8\'\'' . rawurlencode($name));
    header('Cache-Control: private, max-age=600');
    header('X-Content-Type-Options: nosniff');
    header('Content-Security-Policy: sandbox');

    $fp = @fopen($abs, 'rb');
    if (!$fp) {
        http_response_code(500);
        exit;
    }

    $start = 0;
    $end = $size > 0 ? $size - 1 : 0;
    if ($size > 0 && isset($_SERVER['HTTP_RANGE']) && preg_match('/bytes=(\d*)-(\d*)/', (string)$_SERVER['HTTP_RANGE'], $m)) {
        if ($m[1] !== '') {
            $start = (int)$m[1];
        }
        if ($m[2] !== '') {
            $end = (int)$m[2];
        }
        if ($start > $end || $start >= $size) {
            http_response_code(416);
            header('Content-Range: bytes */' . $size);
            fclose($fp);
            exit;
        }
        $end = min($end, $size - 1);
        http_response_code(206);
        header('Content-Range: bytes ' . $start . '-' . $end . '/' . $size);
        header('Content-Length: ' . ($end - $start + 1));
    }

    fseek($fp, $start);
    $remain = $end - $start + 1;
    $chunk = 1024 * 128;
    while ($remain > 0 && !feof($fp)) {
        $read = fread($fp, (int)min($chunk, $remain));
        if ($read === false) {
            break;
        }
        echo $read;
        $remain -= strlen($read);
        flush();
    }
    fclose($fp);
    exit;
}

/* ------------------------------------------------------------------ *
 *  其余接口均为 JSON，写操作需 CSRF
 * ------------------------------------------------------------------ */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    fm_verify_csrf();
}

$input = fm_input();

/**
 * 从输入中提取路径数组
 */
function fm_paths(array $input): array
{
    $v = $input['paths'] ?? [];
    if (is_string($v)) {
        $decoded = json_decode($v, true);
        $v = is_array($decoded) ? $decoded : [$v];
    }
    $out = [];
    foreach ((array)$v as $p) {
        if (is_string($p) && $p !== '') {
            $out[] = $p;
        }
    }
    return array_values(array_unique($out));
}

function fm_sort_items(array $items, string $sort, string $order): array
{
    usort($items, function (array $a, array $b) use ($sort, $order): int {
        if ($a['type'] !== $b['type']) {
            return $a['type'] === 'dir' ? -1 : 1;
        }
        switch ($sort) {
            case 'size':
                $r = $a['size'] <=> $b['size'];
                break;
            case 'mtime':
                $r = $a['mtime'] <=> $b['mtime'];
                break;
            case 'type':
                $r = strcasecmp($a['ext'], $b['ext']);
                break;
            default:
                $r = strnatcasecmp($a['name'], $b['name']);
                break;
        }
        return $order === 'desc' ? -$r : $r;
    });
    return $items;
}

function fm_zip_add_path(ZipArchive $zip, string $abs, string $local, int &$count): void
{
    if (is_dir($abs) && !is_link($abs)) {
        $zip->addEmptyDir($local);
        foreach (@scandir($abs) ?: [] as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }
            fm_zip_add_path($zip, $abs . DIRECTORY_SEPARATOR . $item, $local . '/' . fm_from_sys($item), $count);
        }
    } elseif (is_file($abs)) {
        $zip->addFile($abs, $local);
        $count++;
    }
}

switch ($action) {
    /* ------------------------------ 头像上传 ------------------------------ */
    case 'avatar_upload':
        if (!isset($_FILES['avatar'])) {
            fm_fail('请选择头像图片');
        }
        $avatarErr = null;
        if (!fm_save_avatar((int)$user['id'], $_FILES['avatar'], $avatarErr)) {
            fm_fail((string)$avatarErr);
        }
        fm_ok(['avatar' => fm_avatar_url($user)]);
        break;

    /* ------------------------------ 编辑个人资料 ------------------------------ */
    case 'profile_save': {
        $nickname = trim((string)($input['nickname'] ?? ''));
        $oldPass = (string)($input['old_password'] ?? '');
        $newPass = (string)($input['new_password'] ?? '');
        $db = fm_db();
        if (!$db) {
            fm_fail('数据库连接失败', 500);
        }
        if (mb_strlen($nickname) > 32) {
            fm_fail('昵称最多 32 个字符');
        }
        if ($newPass !== '') {
            if (mb_strlen($newPass) < 6) {
                fm_fail('新密码至少 6 位');
            }
            $st = $db->prepare('SELECT password_hash FROM fm_user WHERE id = ? LIMIT 1');
            $st->execute([(int)$user['id']]);
            $hash = (string)($st->fetchColumn() ?: '');
            if ($hash === '' || !password_verify($oldPass, $hash)) {
                fm_fail('原密码不正确');
            }
            $db->prepare('UPDATE fm_user SET password_hash = ? WHERE id = ?')
                ->execute([password_hash($newPass, PASSWORD_DEFAULT), (int)$user['id']]);
        }
        $db->prepare('UPDATE fm_user SET nickname = ? WHERE id = ?')
            ->execute([$nickname, (int)$user['id']]);

        if (isset($_FILES['avatar']) && (int)($_FILES['avatar']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK) {
            $avatarErr = null;
            if (!fm_save_avatar((int)$user['id'], $_FILES['avatar'], $avatarErr)) {
                fm_fail((string)$avatarErr);
            }
        }
        fm_log('更新资料', '');
        fm_ok([
            'user' => [
                'id'       => (int)$user['id'],
                'username' => $user['username'],
                'nickname' => $nickname !== '' ? $nickname : $user['username'],
                'role'     => $user['role'],
            ],
            'avatar' => fm_avatar_url($user),
        ]);
        break;
    }

    /* ------------------------------ 当前用户 ------------------------------ */
    case 'me':
        fm_ok([
            'user' => [
                'id'       => (int)$user['id'],
                'username' => $user['username'],
                'nickname' => $user['nickname'] !== '' ? $user['nickname'] : $user['username'],
                'role'     => $user['role'],
            ],
            'csrf' => fm_csrf(),
            'site' => [
                'name'    => fm_site_name(),
                'tagline' => fm_site_tagline(),
            ],
        ]);
        break;

    /* ------------------------------ 目录列表 ------------------------------ */
    case 'list': {
        $rel = fm_normalize_rel((string)($_GET['path'] ?? ''));
        $sort = (string)($_GET['sort'] ?? 'name');
        $order = (string)($_GET['order'] ?? 'asc') === 'desc' ? 'desc' : 'asc';
        if (!in_array($sort, ['name', 'size', 'mtime', 'type'], true)) {
            $sort = 'name';
        }

        $abs = fm_abs($rel, true);
        if (!is_dir($abs)) {
            fm_fail('目标不是文件夹');
        }
        $items = [];
        $dh = @opendir($abs);
        if ($dh === false) {
            fm_fail('没有权限读取该文件夹', 403);
        }
        while (($entry = readdir($dh)) !== false) {
            if ($entry === '.' || $entry === '..') {
                continue;
            }
            $full = $abs . DIRECTORY_SEPARATOR . $entry;
            $display = fm_from_sys($entry);
            if ($display === '' || strpos($display, "\0") !== false) {
                continue;
            }
            if (fm_is_system_entry($display, $rel)) {
                continue;
            }
            $isDir = is_dir($full);
            $items[] = [
                'name'  => $display,
                'path'  => fm_join_rel($rel, $display),
                'type'  => $isDir ? 'dir' : 'file',
                'size'  => $isDir ? 0 : (int)@filesize($full),
                'mtime' => (int)@filemtime($full),
                'ext'   => $isDir ? '' : fm_ext($display),
            ];
        }
        closedir($dh);

        $items = fm_sort_items($items, $sort, $order);

        $crumbs = [['name' => '全部文件', 'path' => '']];
        if ($rel !== '') {
            $acc = [];
            foreach (explode('/', $rel) as $seg) {
                $acc[] = $seg;
                $crumbs[] = ['name' => $seg, 'path' => implode('/', $acc)];
            }
        }

        $free = @disk_free_space(fm_root_dir());
        $total = @disk_total_space(fm_root_dir());

        fm_ok([
            'path'       => $rel,
            'items'      => $items,
            'breadcrumb' => $crumbs,
            'disk'       => [
                'free'  => $free === false ? 0 : (int)$free,
                'total' => $total === false ? 0 : (int)$total,
            ],
        ]);
        break;
    }

    /* ------------------------------ 搜索 ------------------------------ */
    case 'search': {
        $base = fm_normalize_rel((string)($_GET['path'] ?? ''));
        $q = trim((string)($_GET['q'] ?? ''));
        if ($q === '' || mb_strlen($q) < 1) {
            fm_fail('请输入搜索关键词');
        }
        $abs = fm_abs($base, true);
        if (!is_dir($abs)) {
            fm_fail('搜索起点不是文件夹');
        }
        $needle = mb_strtolower($q);
        $results = [];
        $queue = [[$abs, $base, 0]];
        $visited = 0;
        while ($queue && count($results) < 400) {
            [$cur, $curRel, $depth] = array_shift($queue);
            if ($depth > 8) {
                continue;
            }
            $items = @scandir($cur);
            if ($items === false) {
                continue;
            }
            foreach ($items as $entry) {
                if ($entry === '.' || $entry === '..') {
                    continue;
                }
                if (++$visited > 20000) {
                    break 2;
                }
                $full = $cur . DIRECTORY_SEPARATOR . $entry;
                $display = fm_from_sys($entry);
                if (fm_is_system_entry($display, $curRel)) {
                    continue;
                }
                $relPath = fm_join_rel($curRel, $display);
                $isDir = is_dir($full);
                if (mb_stripos($display, $needle) !== false) {
                    $results[] = [
                        'name'  => $display,
                        'path'  => $relPath,
                        'type'  => $isDir ? 'dir' : 'file',
                        'size'  => $isDir ? 0 : (int)@filesize($full),
                        'mtime' => (int)@filemtime($full),
                        'ext'   => $isDir ? '' : fm_ext($display),
                    ];
                }
                if ($isDir && !is_link($full)) {
                    $queue[] = [$full, $relPath, $depth + 1];
                }
            }
        }
        fm_ok(['items' => $results, 'query' => $q, 'path' => $base]);
        break;
    }

    /* ------------------------------ 批量打包下载 ------------------------------ */
    case 'download_zip': {
        if (!class_exists('ZipArchive')) {
            fm_fail('服务器未启用 ZipArchive 扩展');
        }
        $paths = fm_paths($input);
        if (!$paths) {
            fm_fail('没有选择要下载的内容');
        }
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_write_close();
        }
        $tmp = tempnam(sys_get_temp_dir(), 'fmzip');
        if ($tmp === false) {
            fm_fail('无法创建临时文件');
        }
        $zip = new ZipArchive();
        if ($zip->open($tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            @unlink($tmp);
            fm_fail('创建压缩包失败');
        }
        $count = 0;
        foreach ($paths as $rel) {
            $rel = fm_normalize_rel($rel);
            if ($rel === '') {
                continue;
            }
            $abs = fm_abs($rel, true);
            fm_zip_add_path($zip, $abs, fm_from_sys(basename($abs)), $count);
        }
        $zip->close();
        if ($count === 0) {
            @unlink($tmp);
            fm_fail('没有可下载的文件');
        }

        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        $stamp = date('Ymd_His');
        $fileName = '樱屿文件_' . $stamp . '.zip';
        header('Content-Type: application/zip');
        header('Content-Length: ' . (string)filesize($tmp));
        header('Content-Disposition: attachment; filename="files_' . $stamp . '.zip"; filename*=UTF-8\'\'' . rawurlencode($fileName));
        header('Cache-Control: no-store');
        readfile($tmp);
        @unlink($tmp);
        exit;
    }

    /* ------------------------------ 上传 ------------------------------ */
    case 'upload': {
        $dirRel = fm_normalize_rel((string)($input['path'] ?? ''));
        $dirAbs = fm_abs($dirRel, true);
        if (!is_dir($dirAbs)) {
            fm_fail('上传目标不是文件夹');
        }
        $overwrite = fm_bool($input['overwrite'] ?? false);
        if (empty($_FILES['files'])) {
            fm_fail('没有接收到文件');
        }

        $names = $_FILES['files']['name'] ?? [];
        $tmpNames = $_FILES['files']['tmp_name'] ?? [];
        $errorsCodes = $_FILES['files']['error'] ?? [];
        if (!is_array($names)) {
            $names = [$names];
            $tmpNames = [$tmpNames];
            $errorsCodes = [$errorsCodes];
        }

        $done = [];
        $failed = [];
        foreach ($names as $i => $rawName) {
            $errCode = (int)($errorsCodes[$i] ?? UPLOAD_ERR_NO_FILE);
            $tmp = (string)($tmpNames[$i] ?? '');
            if ($errCode !== UPLOAD_ERR_OK || $tmp === '') {
                $failed[] = ['name' => (string)$rawName, 'error' => '上传失败（错误码 ' . $errCode . '）'];
                continue;
            }
            try {
                $clean = fm_safe_name(basename((string)$rawName));
                $sysName = fm_to_sys($clean);
                $target = $dirAbs . DIRECTORY_SEPARATOR . $sysName;
                if (file_exists($target) && !$overwrite) {
                    $target = fm_unique_path($dirAbs, $sysName);
                }
                if (!@move_uploaded_file($tmp, $target)) {
                    throw new RuntimeException('无法写入目标文件');
                }
                $done[] = fm_from_sys(basename($target));
            } catch (Throwable $e) {
                $failed[] = ['name' => (string)$rawName, 'error' => $e->getMessage()];
            }
        }

        if ($done) {
            fm_log('上传', $dirRel . ' / ' . implode(', ', array_slice($done, 0, 5)));
        }
        fm_ok(['done' => $done, 'failed' => $failed]);
        break;
    }

    /* ------------------------------ 新建文件夹 / 文件 ------------------------------ */
    case 'mkdir':
    case 'touch': {
        $dirRel = fm_normalize_rel((string)($input['path'] ?? ''));
        $dirAbs = fm_abs($dirRel, true);
        if (!is_dir($dirAbs)) {
            fm_fail('当前目录不存在');
        }
        $name = fm_safe_name((string)($input['name'] ?? ''));
        $target = $dirAbs . DIRECTORY_SEPARATOR . fm_to_sys($name);
        if (file_exists($target)) {
            fm_fail('同名文件或文件夹已经存在');
        }
        if ($action === 'mkdir') {
            if (!@mkdir($target, 0775, true)) {
                fm_fail('创建文件夹失败，请检查写入权限');
            }
            fm_log('新建文件夹', fm_join_rel($dirRel, $name));
        } else {
            if (@file_put_contents($target, '') === false) {
                fm_fail('创建文件失败，请检查写入权限');
            }
            fm_log('新建文件', fm_join_rel($dirRel, $name));
        }
        fm_ok(['name' => $name, 'path' => fm_join_rel($dirRel, $name)]);
        break;
    }

    /* ------------------------------ 重命名 ------------------------------ */
    case 'rename': {
        $rel = fm_normalize_rel((string)($input['path'] ?? ''));
        if ($rel === '') {
            fm_fail('不能重命名根目录');
        }
        $abs = fm_abs($rel, true);
        $newName = fm_safe_name((string)($input['name'] ?? ''));
        $target = dirname($abs) . DIRECTORY_SEPARATOR . fm_to_sys($newName);
        if (strcasecmp($target, $abs) !== 0 && file_exists($target)) {
            fm_fail('目标名称已存在');
        }
        if (!@rename($abs, $target)) {
            fm_fail('重命名失败，请检查权限');
        }
        $parentRel = pathinfo($rel, PATHINFO_DIRNAME);
        $parentRel = $parentRel === '.' ? '' : $parentRel;
        fm_log('重命名', $rel . ' → ' . fm_join_rel($parentRel, $newName));
        fm_ok(['name' => $newName, 'path' => fm_join_rel($parentRel, $newName)]);
        break;
    }

    /* ------------------------------ 删除 ------------------------------ */
    case 'delete': {
        $paths = fm_paths($input);
        if (!$paths) {
            fm_fail('没有选择要删除的内容');
        }
        $done = [];
        $failed = [];
        foreach ($paths as $rel) {
            try {
                $rel = fm_normalize_rel($rel);
                if ($rel === '') {
                    throw new RuntimeException('不能删除根目录');
                }
                $abs = fm_abs($rel, true);
                if (is_dir($abs) && !is_link($abs)) {
                    if (!fm_rmdir_recursive($abs)) {
                        throw new RuntimeException('文件夹删除失败，可能包含只读文件');
                    }
                } elseif (!@unlink($abs)) {
                    throw new RuntimeException('文件删除失败，请检查权限');
                }
                $done[] = $rel;
            } catch (Throwable $e) {
                $failed[] = ['path' => $rel, 'error' => $e->getMessage()];
            }
        }
        if ($done) {
            fm_log('删除', implode('、', array_slice($done, 0, 6)));
        }
        fm_ok(['done' => $done, 'failed' => $failed]);
        break;
    }

    /* ------------------------------ 复制 / 移动 ------------------------------ */
    case 'copy':
    case 'move': {
        $paths = fm_paths($input);
        $destRel = fm_normalize_rel((string)($input['dest'] ?? ''));
        if (!$paths) {
            fm_fail('没有选择要操作的内容');
        }
        $destAbs = fm_abs($destRel, true);
        if (!is_dir($destAbs)) {
            fm_fail('目标位置不是文件夹');
        }
        $done = [];
        $failed = [];
        foreach ($paths as $rel) {
            try {
                $relN = fm_normalize_rel($rel);
                if ($relN === '') {
                    throw new RuntimeException('不能移动或复制根目录');
                }
                $srcAbs = fm_abs($relN, true);
                $srcNorm = rtrim(str_replace('\\', '/', $srcAbs), '/');
                $destNorm = rtrim(str_replace('\\', '/', $destAbs), '/');
                if ($destNorm === $srcNorm || str_starts_with($destNorm . '/', $srcNorm . '/')) {
                    throw new RuntimeException('不能放入自身或其子目录');
                }
                if ($action === 'move' && $destNorm === rtrim(str_replace('\\', '/', dirname($srcAbs)), '/')) {
                    throw new RuntimeException('已经在目标目录中');
                }
                $target = fm_unique_path($destAbs, basename($srcAbs));
                $ok = $action === 'move' ? @rename($srcAbs, $target) : fm_copy_recursive($srcAbs, $target);
                if (!$ok) {
                    throw new RuntimeException(($action === 'move' ? '移动' : '复制') . '失败，请检查权限');
                }
                $done[] = $relN . ' → ' . $destRel;
            } catch (Throwable $e) {
                $failed[] = ['path' => $rel, 'error' => $e->getMessage()];
            }
        }
        if ($done) {
            fm_log($action === 'move' ? '移动' : '复制', implode('、', array_slice($done, 0, 5)));
        }
        fm_ok(['done' => $done, 'failed' => $failed]);
        break;
    }

    /* ------------------------------ 压缩 ------------------------------ */
    case 'zip': {
        if (!class_exists('ZipArchive')) {
            fm_fail('服务器未启用 ZipArchive 扩展，无法压缩');
        }
        $paths = fm_paths($input);
        $destRel = fm_normalize_rel((string)($input['dest'] ?? ''));
        if (!$paths) {
            fm_fail('没有选择要压缩的内容');
        }
        $destAbs = fm_abs($destRel, true);
        if (!is_dir($destAbs)) {
            fm_fail('目标位置不是文件夹');
        }
        $name = trim((string)($input['name'] ?? ''));
        if ($name === '') {
            $name = '归档_' . date('Ymd_His') . '.zip';
        }
        $name = fm_safe_name($name);
        if (!str_ends_with(strtolower($name), '.zip')) {
            $name .= '.zip';
        }
        $zipPath = fm_unique_path($destAbs, fm_to_sys($name));
        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            fm_fail('无法创建压缩包');
        }
        $added = 0;
        foreach ($paths as $rel) {
            $rel = fm_normalize_rel($rel);
            if ($rel === '') {
                continue;
            }
            $abs = fm_abs($rel, true);
            fm_zip_add_path($zip, $abs, fm_from_sys(basename($abs)), $added);
        }
        $zip->close();

        if ($added === 0) {
            @unlink($zipPath);
            fm_fail('没有可压缩的文件');
        }
        fm_log('压缩', $destRel . ' / ' . fm_from_sys(basename($zipPath)));
        fm_ok(['name' => fm_from_sys(basename($zipPath))]);
        break;
    }

    /* ------------------------------ 文件属性 ------------------------------ */
    case 'detail': {
        $rel = fm_normalize_rel((string)($_GET['path'] ?? $input['path'] ?? ''));
        $abs = fm_abs($rel, true);
        $isDir = is_dir($abs);
        $parentRel = pathinfo($rel, PATHINFO_DIRNAME);
        $parentRel = $parentRel === '.' ? '' : $parentRel;
        $items = 0;
        if ($isDir) {
            $items = max(0, count(@scandir($abs) ?: []) - 2);
        }
        $name = fm_from_sys(basename($abs));
        fm_ok([
            'name'     => $name,
            'path'     => $rel,
            'parent'   => $parentRel,
            'type'     => $isDir ? 'dir' : 'file',
            'size'     => $isDir ? fm_dir_size($abs) : (int)@filesize($abs),
            'items'    => $items,
            'mtime'    => (int)@filemtime($abs),
            'readable' => is_readable($abs),
            'writable' => is_writable($abs),
            'ext'      => $isDir ? '' : fm_ext($name),
        ]);
        break;
    }

    /* ------------------------------ 查看压缩包内容 ------------------------------ */
    case 'archive_list': {
        $rel = fm_normalize_rel((string)($_GET['path'] ?? ''));
        $abs = fm_abs($rel, true);
        if (!is_file($abs)) {
            fm_fail('文件不存在');
        }
        if (fm_ext($abs) !== 'zip' || !class_exists('ZipArchive')) {
            fm_fail('目前仅支持查看 zip 压缩包的内容');
        }
        $zip = new ZipArchive();
        if ($zip->open($abs) !== true) {
            fm_fail('无法读取压缩包');
        }
        $items = [];
        $limit = 1000;
        $total = $zip->numFiles;
        $n = min($total, $limit);
        for ($i = 0; $i < $n; $i++) {
            $entry = (string)$zip->getNameIndex($i);
            $stat = $zip->statIndex($i) ?: [];
            $items[] = [
                'name'  => fm_from_sys(str_replace('\\', '/', $entry)),
                'size'  => (int)($stat['size'] ?? 0),
                'mtime' => (int)($stat['mtime'] ?? 0),
                'dir'   => str_ends_with($entry, '/'),
            ];
        }
        $zip->close();
        fm_ok(['items' => $items, 'total' => $total, 'truncated' => $total > $limit]);
        break;
    }

    /* ------------------------------ 读取 / 保存文本 ------------------------------ */
    case 'read_text': {
        $rel = fm_normalize_rel((string)($_GET['path'] ?? $input['path'] ?? ''));
        $abs = fm_abs($rel, true);
        if (!is_file($abs)) {
            fm_fail('文件不存在');
        }
        $size = (int)@filesize($abs);
        if ($size > 5 * 1024 * 1024) {
            fm_fail('文件超过 5MB，暂不支持在线编辑');
        }
        $content = (string)@file_get_contents($abs);
        if (strpos(substr($content, 0, 8192), "\0") !== false) {
            fm_fail('这是二进制文件，无法以文本方式编辑');
        }
        if (!mb_check_encoding($content, 'UTF-8')) {
            $content = mb_convert_encoding($content, 'UTF-8', 'GB18030');
        }
        fm_ok(['content' => $content, 'name' => fm_from_sys(basename($abs)), 'size' => $size]);
        break;
    }

    case 'save_text': {
        $rel = fm_normalize_rel((string)($input['path'] ?? ''));
        $abs = fm_abs($rel, true);
        if (!is_file($abs)) {
            fm_fail('文件不存在');
        }
        $content = (string)($input['content'] ?? '');
        if (strlen($content) > 5 * 1024 * 1024) {
            fm_fail('内容超过 5MB，无法保存');
        }
        if (strpos(substr($content, 0, 8192), "\0") !== false) {
            fm_fail('内容包含二进制字符，已拒绝保存');
        }
        if (@file_put_contents($abs, $content, LOCK_EX) === false) {
            fm_fail('保存失败，请检查文件写入权限');
        }
        fm_log('编辑文件', $rel);
        fm_ok(['size' => strlen($content)]);
        break;
    }

    /* ------------------------------ 站点设置 ------------------------------ */
    case 'settings_get': {
        fm_require_admin();
        fm_ok([
            'site_name'    => fm_site_name(),
            'site_tagline' => fm_site_tagline(),
            'root_dir'     => fm_setting('root_dir', fm_from_sys(FM_ROOT)),
            'version'      => FM_VERSION,
            'php'          => PHP_VERSION,
            'zip'          => class_exists('ZipArchive'),
        ]);
        break;
    }

    case 'settings_save': {
        fm_require_admin();
        $rootInput = trim((string)($input['root_dir'] ?? ''));
        if ($rootInput !== '') {
            $rootSys = fm_to_sys(str_replace('\\', '/', $rootInput));
            if (!is_dir($rootSys)) {
                @mkdir($rootSys, 0775, true);
            }
            if (!is_dir($rootSys) || !is_writable($rootSys)) {
                fm_fail('新的根目录不存在或不可写');
            }
            $real = realpath($rootSys) ?: $rootSys;
            fm_set('root_dir', fm_from_sys($real));
        }

        $siteName = trim((string)($input['site_name'] ?? ''));
        $tagline = trim((string)($input['site_tagline'] ?? ''));
        if ($siteName !== '') {
            fm_set('site_name', mb_substr($siteName, 0, 60));
        }
        fm_set('site_tagline', mb_substr($tagline, 0, 120));

        fm_log('修改设置', '站点设置');
        fm_ok(['site_name' => fm_site_name(), 'site_tagline' => fm_site_tagline(), 'root_dir' => fm_setting('root_dir', '')]);
        break;
    }

    /* ------------------------------ 修改密码 ------------------------------ */
    case 'password': {
        $old = (string)($input['old'] ?? '');
        $new = (string)($input['new'] ?? '');
        if (mb_strlen($new) < 6) {
            fm_fail('新密码至少 6 位');
        }
        $db = fm_db();
        if (!$db) {
            fm_fail('数据库连接失败', 500);
        }
        $st = $db->prepare('SELECT password_hash FROM fm_user WHERE id = ? LIMIT 1');
        $st->execute([(int)$user['id']]);
        $hash = (string)($st->fetchColumn() ?: '');
        if ($hash === '' || !password_verify($old, $hash)) {
            fm_fail('原密码不正确');
        }
        $st = $db->prepare('UPDATE fm_user SET password_hash = ? WHERE id = ?');
        $st->execute([password_hash($new, PASSWORD_DEFAULT), (int)$user['id']]);
        session_regenerate_id(true);
        fm_log('修改密码', '');
        fm_ok();
        break;
    }

    /* ------------------------------ 用户管理 ------------------------------ */
    case 'users_list': {
        fm_require_admin();
        $db = fm_db();
        if (!$db) {
            fm_fail('数据库连接失败', 500);
        }
        $rows = [];
        foreach ($db->query('SELECT id, username, nickname, role, created_at, last_login FROM fm_user ORDER BY id ASC') as $u) {
            $rows[] = [
                'id'         => (int)$u['id'],
                'username'   => (string)$u['username'],
                'nickname'   => (string)($u['nickname'] ?? ''),
                'role'       => (string)($u['role'] ?? 'user'),
                'created_at' => (string)($u['created_at'] ?? ''),
                'last_login' => $u['last_login'] ?? null,
            ];
        }
        fm_ok(['users' => $rows]);
        break;
    }

    case 'user_add': {
        fm_require_admin();
        $username = trim((string)($input['username'] ?? ''));
        $password = (string)($input['password'] ?? '');
        $nickname = trim((string)($input['nickname'] ?? ''));
        $role = ($input['role'] ?? 'user') === 'admin' ? 'admin' : 'user';
        if (!preg_match('/^[A-Za-z0-9_\x{4e00}-\x{9fa5}]{2,32}$/u', $username)) {
            fm_fail('账号需为 2-32 位的中文、字母、数字或下划线');
        }
        if (mb_strlen($password) < 6) {
            fm_fail('密码至少 6 位');
        }
        $db = fm_db();
        if (!$db) {
            fm_fail('数据库连接失败', 500);
        }
        $st = $db->prepare('SELECT id FROM fm_user WHERE username = ? LIMIT 1');
        $st->execute([$username]);
        if ($st->fetchColumn()) {
            fm_fail('该账号已存在');
        }
        $st = $db->prepare('INSERT INTO fm_user (username, password_hash, nickname, role, created_at) VALUES (?, ?, ?, ?, NOW())');
        $st->execute([
            $username,
            password_hash($password, PASSWORD_DEFAULT),
            $nickname !== '' ? $nickname : $username,
            $role,
        ]);
        fm_log('新增用户', $username);
        fm_ok(['id' => (int)$db->lastInsertId()]);
        break;
    }

    case 'user_delete': {
        fm_require_admin();
        $id = (int)($input['id'] ?? 0);
        if ($id === (int)$user['id']) {
            fm_fail('不能删除当前登录的账号');
        }
        $db = fm_db();
        if (!$db) {
            fm_fail('数据库连接失败', 500);
        }
        $st = $db->prepare('SELECT id, username, role FROM fm_user WHERE id = ? LIMIT 1');
        $st->execute([$id]);
        $target = $st->fetch();
        if (!$target) {
            fm_fail('用户不存在');
        }
        if (($target['role'] ?? '') === 'admin') {
            $admins = (int)$db->query("SELECT COUNT(*) FROM fm_user WHERE role = 'admin'")->fetchColumn();
            if ($admins <= 1) {
                fm_fail('至少需要保留一个管理员账号');
            }
        }
        fm_purge_user_files($id, (string)$target['username']);
        $db->prepare('DELETE FROM fm_user WHERE id = ?')->execute([$id]);
        fm_log('删除用户', 'ID ' . $id);
        fm_ok();
        break;
    }

    /* ------------------------------ 操作日志 ------------------------------ */
    case 'logs': {
        $page = max(1, (int)($_GET['page'] ?? 1));
        $limit = 40;
        $offset = ($page - 1) * $limit;
        $isAdmin = ($user['role'] ?? '') === 'admin';
        $db = fm_db();
        if (!$db) {
            fm_fail('数据库连接失败', 500);
        }
        if ($isAdmin) {
            $total = (int)$db->query('SELECT COUNT(*) FROM fm_log')->fetchColumn();
            $st = $db->prepare('SELECT id, user_id, username, action, target, ip, created_at FROM fm_log ORDER BY id DESC LIMIT ' . $limit . ' OFFSET ' . $offset);
            $st->execute();
        } else {
            $uid = (int)$user['id'];
            $c = $db->prepare('SELECT COUNT(*) FROM fm_log WHERE user_id = ?');
            $c->execute([$uid]);
            $total = (int)$c->fetchColumn();
            $st = $db->prepare('SELECT id, user_id, username, action, target, ip, created_at FROM fm_log WHERE user_id = ? ORDER BY id DESC LIMIT ' . $limit . ' OFFSET ' . $offset);
            $st->execute([$uid]);
        }
        $items = [];
        foreach ($st->fetchAll() as $r) {
            $items[] = [
                'id'         => (int)$r['id'],
                'user_id'    => $r['user_id'] === null ? null : (int)$r['user_id'],
                'username'   => (string)$r['username'],
                'action'     => (string)$r['action'],
                'target'     => (string)$r['target'],
                'ip'         => (string)$r['ip'],
                'created_at' => (string)$r['created_at'],
            ];
        }
        fm_ok([
            'items' => $items,
            'total' => $total,
            'page'  => $page,
            'pages' => max(1, (int)ceil($total / $limit)),
        ]);
        break;
    }

    default:
        fm_fail('未知的操作：' . $action, 404);
}
