<?php
/**
 * 樱屿文件系统 · 数据库配置
 * 如 MySQL 账号密码与下方不同，直接修改对应值即可。
 */
return [
    'db' => [
        'host'    => '127.0.0.1',
        'port'    => 3306,
        'name'    => 'web',
        'user'    => 'root',
        'pass'    => 'lcy',
        'charset' => 'utf8mb4',
    ],
    'installed_at' => '2026-11-24 00:00:00',
    'version'      => '1.0.0',
];
