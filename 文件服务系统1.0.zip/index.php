<?php
/**
 * 樱屿文件系统 · 界面入口
 */
declare(strict_types=1);

require __DIR__ . '/core.php';

if (!fm_is_installed()) {
    header('Location: install.php');
    exit;
}

$user = fm_user();
$csrf = fm_csrf();
$siteName = fm_site_name();
$tagline = fm_site_tagline();
$isAdmin = $user && ($user['role'] ?? '') === 'admin';
$displayName = $user ? ($user['nickname'] !== '' ? $user['nickname'] : $user['username']) : '';
$avatarUrl = $user ? fm_avatar_url($user) : '';
if ($user && !$isAdmin) {
    // 普通用户只显示自己的目录路径，不暴露服务器绝对路径
    $rootPath = '/' . fm_user_dir_name((string)$user['username']);
} else {
    $rootPath = fm_from_sys(fm_root_dir());
}

$boot = [
    'loggedIn' => (bool)$user,
    'csrf'     => $csrf,
    'site'     => ['name' => $siteName, 'tagline' => $tagline],
    'user'     => $user ? [
        'id'       => (int)$user['id'],
        'username' => $user['username'],
        'nickname' => $displayName,
        'role'     => $user['role'],
        'initial'  => mb_substr($displayName, 0, 1),
        'avatar'   => $avatarUrl,
    ] : null,
    'isAdmin'  => (bool)$isAdmin,
    'allowRegister' => fm_setting('allow_register', '1') === '1',
    'root'     => $rootPath,
    'zip'      => class_exists('ZipArchive'),
    'version'  => FM_VERSION,
];
$bootJson = json_encode($boot, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
if (!is_string($bootJson) || $bootJson === '') {
    $bootJson = '{}';
}
?>
<!DOCTYPE html>
<html lang="zh-CN" data-theme="sakura">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#f9f1fb">
<title><?= htmlspecialchars($siteName) ?></title>
<link rel="icon" href="data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'></text></svg>">
<link rel="stylesheet" href="assets/vendor/remixicon/remixicon.css">
<script src="assets/vendor/tailwind/tailwind-3.4.16.min.js"></script>
<script>window.tailwind && (tailwind.config = { corePlugins: { preflight: false } });</script>
<script>
try {
  var savedTheme = localStorage.getItem('fm-theme');
  if (savedTheme === 'yoru' || savedTheme === 'sakura') {
    document.documentElement.dataset.theme = savedTheme;
  }
} catch (e) {}
</script>
<link rel="stylesheet" href="assets/app.css?v=<?= @filemtime(__DIR__ . '/assets/app.css') ?: FM_VERSION ?>">
</head>
<body class="<?= $user ? 'is-app' : 'is-login' ?>">

<div class="aurora" aria-hidden="true">
  <span class="aurora-1"></span>
  <span class="aurora-2"></span>
  <span class="aurora-3"></span>
  <span class="aurora-4"></span>
</div>

<?php if (!$user): ?>
<!-- ====================== 登录 ====================== -->
<div class="login-screen">
  <div class="login-art">
    <div class="login-art-content">
      <div class="art-mark" id="artAvatar"><i class="ri-user-smile-line"></i><img alt="" hidden></div>
      <h1 class="art-title"><?= htmlspecialchars($siteName) ?></h1>
      <p class="art-sub"><?= htmlspecialchars($tagline) ?></p>
      <div class="art-tags">
        <span><i class="ri-cloud-line"></i> 随处访问</span>
        <span><i class="ri-shield-star-line"></i> 私有空间</span>
        <span><i class="ri-brush-4-line"></i> 浪漫轻盈</span>
      </div>
    </div>
    <div class="art-figures" aria-hidden="true">
      <span class="orb orb-a"></span>
      <span class="orb orb-b"></span>
      <span class="orb orb-c"></span>
      <span class="petal p1"></span>
      <span class="petal p2"></span>
      <span class="petal p3"></span>
      <span class="petal p4"></span>
    </div>
  </div>

  <div class="login-panel">
    <div class="login-panel-inner">
      <div class="login-brand-mobile">
        <span class="mini-mark" id="miniAvatar"><i class="ri-user-smile-line"></i><img alt="" hidden></span>
        <span><?= htmlspecialchars($siteName) ?></span>
      </div>
      <div class="auth-avatar">
        <button type="button" class="auth-avatar-btn" id="avatarPick" title="选择头像">
          <span id="avatarTip"><i class="ri-camera-line"></i></span>
          <img id="avatarPreview" alt="" hidden>
        </button>
        <small id="avatarHint">点击选择头像（可选）</small>
        <input type="file" id="avatarInput" accept="image/jpeg,image/png,image/webp,image/gif" hidden>
      </div>
      <h2 id="authHeading">欢迎回来</h2>
      <p class="login-sub" id="authSub">登录后继续整理你的文件空间</p>
      <?php if (fm_default_admin_exists()): ?>
      <p class="login-default">默认账号 <b>admin</b> · 密码 <b>admin123</b><br>登录后请在「设置」中修改密码</p>
      <?php endif; ?>
      <form id="loginForm" autocomplete="on">
        <label class="input-line">
          <i class="ri-user-3-line"></i>
          <input type="text" name="username" placeholder="账号" autocomplete="username" required>
        </label>
        <label class="input-line">
          <i class="ri-lock-password-line"></i>
          <input type="password" name="password" placeholder="密码" autocomplete="current-password" required>
        </label>
        <div class="login-error" id="loginError"></div>
        <button class="btn-primary btn-block" type="submit" id="loginBtn">
          <span>进入樱屿</span>
          <i class="ri-arrow-right-line"></i>
        </button>
        <button type="button" class="auth-switch" id="switchToRegister"<?= fm_setting('allow_register', '1') === '1' ? '' : ' hidden' ?>>还没有账号？立即注册</button>
      </form>
      <form id="registerForm" hidden autocomplete="on">
        <label class="input-line">
          <i class="ri-user-add-line"></i>
          <input type="text" name="username" placeholder="账号（2-32 位）" autocomplete="username" required>
        </label>
        <label class="input-line">
          <i class="ri-user-smile-line"></i>
          <input type="text" name="nickname" placeholder="昵称（可选）" autocomplete="nickname">
        </label>
        <label class="input-line">
          <i class="ri-lock-password-line"></i>
          <input type="password" name="password" placeholder="密码（至少 6 位）" autocomplete="new-password" required>
        </label>
        <label class="input-line">
          <i class="ri-lock-password-line"></i>
          <input type="password" name="password2" placeholder="确认密码" autocomplete="new-password" required>
        </label>
        <div class="login-error" id="registerError"></div>
        <button class="btn-primary btn-block" type="submit" id="registerBtn">
          <span>创建账号</span>
          <i class="ri-arrow-right-line"></i>
        </button>
        <button type="button" class="auth-switch" id="switchToLogin">已有账号？返回登录</button>
      </form>
      <div class="login-foot">SAKURA ISLE · v<?= FM_VERSION ?></div>
    </div>
  </div>
</div>

<?php else: ?>
<!-- ====================== 应用主体 ====================== -->
<div class="app">
  <aside class="sidebar" id="sidebar">
    <div class="side-brand">
      <span class="brand-mark"><img src="assets/appIcon.png" alt="樱屿"></span>
      <div class="brand-text">
        <b><?= htmlspecialchars($siteName) ?></b>
        <small>SAKURA ISLE</small>
      </div>
      <button class="icon-btn side-close mobile-only" id="sideClose" aria-label="关闭菜单">
        <i class="ri-close-line"></i>
      </button>
    </div>

    <nav class="nav">
      <a class="nav-item active" href="#/files" data-nav="files">
        <i class="ri-folders-line"></i><span>全部文件</span>
      </a>
      <a class="nav-item" href="#/recent" data-nav="recent">
        <i class="ri-history-line"></i><span>最近动态</span>
      </a>
      <?php if ($isAdmin): ?>
      <a class="nav-item" href="admin/index.php" data-nav="admin">
        <i class="ri-dashboard-3-line"></i><span>后台管理</span>
      </a>
      <a class="nav-item" href="#/settings" data-nav="settings">
        <i class="ri-settings-4-line"></i><span>站点设置</span>
      </a>
      <?php endif; ?>
    </nav>

    <div class="side-divider"></div>

    <div class="quick-links">
      <button class="quick-item" data-quick="upload">
        <i class="ri-upload-cloud-2-line"></i><span>上传文件</span>
      </button>
      <button class="quick-item" data-quick="mkdir">
        <i class="ri-folder-add-line"></i><span>新建文件夹</span>
      </button>
    </div>

    <div class="side-spacer"></div>

    <div class="storage-box">
      <div class="storage-head">
        <span>存储空间</span>
        <span id="diskText">—</span>
      </div>
      <div class="storage-bar"><i id="diskBar" style="width:0%"></i></div>
      <div class="storage-path" title="<?= htmlspecialchars($rootPath) ?>">
        <i class="ri-hard-drive-2-line"></i><span><?= htmlspecialchars($rootPath) ?></span>
      </div>
    </div>

    <div class="user-box">
      <button type="button" class="avatar" id="avatarBtn" title="点击更换头像">
        <?php if ($avatarUrl !== ''): ?>
        <img src="<?= htmlspecialchars($avatarUrl, ENT_QUOTES, 'UTF-8') ?>" alt="头像">
        <?php else: ?>
        <?= htmlspecialchars(mb_substr($displayName, 0, 1)) ?>
        <?php endif; ?>
      </button>
      <div class="user-meta">
        <b><?= htmlspecialchars($displayName) ?></b>
        <small><?= $isAdmin ? '管理员' : '成员' ?></small>
      </div>
      <button class="icon-btn" id="logoutBtn" title="退出登录"><i class="ri-logout-box-r-line"></i></button>
    </div>
  </aside>
  <div class="sidebar-scrim" id="sidebarScrim"></div>

  <main class="main">
    <header class="topbar">
      <button class="icon-btn mobile-only" id="menuBtn" aria-label="打开菜单"><i class="ri-menu-4-line"></i></button>
      <div class="crumbs" id="crumbs">
        <a href="#/files" class="crumb current"><i class="ri-home-smile-2-line"></i><span>全部文件</span></a>
      </div>
      <div class="top-actions">
        <label class="search-pill" id="searchPill">
          <i class="ri-search-line"></i>
          <input type="text" id="searchInput" placeholder="搜索当前目录，回车全站搜索" autocomplete="off">
          <kbd>/</kbd>
        </label>
        <button class="icon-btn" id="viewBtn" title="切换布局"><i class="ri-grid-fill"></i></button>
        <button class="icon-btn" id="themeBtn" title="切换主题"><i class="ri-moon-clear-line"></i></button>
        <button class="btn-primary btn-upload" id="uploadBtn">
          <i class="ri-upload-cloud-2-line"></i><span>上传</span>
        </button>
      </div>
    </header>

    <div class="page" id="page">
      <!-- 文件视图 -->
      <section class="view" id="filesView">
        <div class="view-head">
          <div class="view-title-wrap">
            <h2 id="viewTitle">全部文件</h2>
            <p class="view-meta" id="viewMeta">正在读取…</p>
          </div>
          <div class="view-actions">
            <button class="ghost-btn" id="newFolderBtn"><i class="ri-folder-add-line"></i><span>新建文件夹</span></button>
            <button class="ghost-btn" id="newFileBtn"><i class="ri-file-add-line"></i><span>新建文件</span></button>
            <button class="ghost-btn paste-btn" id="pasteBtn" hidden><i class="ri-clipboard-line"></i><span>粘贴</span><em id="pasteCount"></em></button>
            <button class="ghost-btn sort-btn" id="sortBtn" title="排序方式">
              <i class="ri-sort-desc"></i><span id="sortLabel">名称</span>
            </button>
            <button class="ghost-btn" id="selectAllBtn" title="全选（Ctrl+A）"><i class="ri-checkbox-multiple-line"></i><span>全选</span></button>
            <button class="ghost-btn" id="invertBtn" title="反向选择"><i class="ri-check-double-line"></i><span>反选</span></button>
            <button class="icon-btn" id="hiddenBtn" title="隐藏 . 开头的文件"><i class="ri-eye-line"></i></button>
            <button class="icon-btn" id="refreshBtn" title="刷新"><i class="ri-refresh-line"></i></button>
          </div>
        </div>

        <div class="selbar" id="selBar" hidden>
          <div class="selbar-info"><i class="ri-checkbox-multiple-line"></i><span id="selText">已选择 0 项</span></div>
          <div class="selbar-actions">
            <button data-batch="copyclip"><i class="ri-file-copy-line"></i>复制</button>
            <button data-batch="cut"><i class="ri-scissors-cut-line"></i>剪切</button>
            <button data-batch="paste"><i class="ri-clipboard-line"></i>粘贴</button>
            <button data-batch="download"><i class="ri-download-2-line"></i>下载</button>
            <button data-batch="share"><i class="ri-share-forward-line"></i>分享</button>
            <button data-batch="copy"><i class="ri-file-copy-2-line"></i>复制到</button>
            <button data-batch="move"><i class="ri-drag-move-2-line"></i>移动</button>
            <button data-batch="zip"><i class="ri-file-zip-line"></i>压缩</button>
            <button data-batch="delete" class="danger"><i class="ri-delete-bin-6-line"></i>删除</button>
            <button data-batch="clear"><i class="ri-close-line"></i>取消</button>
          </div>
        </div>

        <div id="fileContainer">
          <div class="skeleton-wrap" id="skeleton">
            <div class="skeleton-row"></div>
            <div class="skeleton-row"></div>
            <div class="skeleton-row"></div>
            <div class="skeleton-row"></div>
            <div class="skeleton-row"></div>
          </div>
          <div class="file-list grid" id="fileList" hidden></div>
          <div class="empty-state" id="emptyState" hidden>
            <div class="empty-orb"><i class="ri-folder-open-line"></i></div>
            <h3>这里还是一张白纸</h3>
            <p>上传文件，或新建一个文件夹开始整理吧</p>
            <div class="empty-actions">
              <button class="btn-primary" data-empty="upload"><i class="ri-upload-cloud-2-line"></i>上传文件</button>
              <button class="ghost-btn" data-empty="mkdir"><i class="ri-folder-add-line"></i>新建文件夹</button>
            </div>
          </div>
        </div>
      </section>

      <!-- 最近动态 -->
      <section class="view" id="recentView" hidden>
        <div class="view-head">
          <div class="view-title-wrap">
            <h2>最近动态</h2>
            <p class="view-meta">记录每一次温柔的操作</p>
          </div>
          <div class="view-actions">
            <button class="icon-btn" id="recentRefresh" title="刷新"><i class="ri-refresh-line"></i></button>
          </div>
        </div>
        <div class="log-list" id="logList"></div>
        <div class="pager" id="logPager"></div>
      </section>

      <!-- 设置 -->
      <?php if ($isAdmin): ?>
      <section class="view" id="settingsView" hidden>
        <div class="view-head">
          <div class="view-title-wrap">
            <h2>站点设置</h2>
            <p class="view-meta">让这里更贴合你的喜好</p>
          </div>
        </div>

        <div class="setting-block">
          <div class="setting-head">
            <i class="ri-palette-line"></i>
            <div><h3>站点信息</h3><p>名称与标语会展示在登录页和侧边栏</p></div>
          </div>
          <div class="setting-grid">
            <label class="field-block">
              <span>站点名称</span>
              <input type="text" id="setSiteName" placeholder="樱屿文件系统">
            </label>
            <label class="field-block">
              <span>站点标语</span>
              <input type="text" id="setTagline" placeholder="把每一份文件，安放在温柔的地方">
            </label>
            <label class="field-block field-wide">
              <span>文件根目录</span>
              <input type="text" id="setRoot" placeholder="/www/wwwroot/files">
              <em>所有文件操作都被限制在此目录内，修改后立即生效</em>
            </label>
          </div>
          <div class="setting-foot">
            <button class="btn-primary" id="saveSiteBtn"><i class="ri-save-3-line"></i>保存设置</button>
          </div>
        </div>

        <div class="setting-block">
          <div class="setting-head">
            <i class="ri-lock-password-line"></i>
            <div><h3>账户安全</h3><p>修改当前账号的登录密码</p></div>
          </div>
          <div class="setting-grid">
            <label class="field-block">
              <span>原密码</span>
              <input type="password" id="oldPassword" placeholder="当前密码" autocomplete="current-password">
            </label>
            <label class="field-block">
              <span>新密码</span>
              <input type="password" id="newPassword" placeholder="至少 6 位" autocomplete="new-password">
            </label>
          </div>
          <div class="setting-foot">
            <button class="btn-primary" id="savePasswordBtn"><i class="ri-shield-keyhole-line"></i>更新密码</button>
          </div>
        </div>

        <div class="setting-block about-block">
          <div class="setting-head">
            <i class="ri-information-line"></i>
            <div><h3>关于樱屿</h3><p>轻量、直达、无需任何框架</p></div>
          </div>
          <div class="about-grid">
            <div><span>程序版本</span><b>v<?= FM_VERSION ?></b></div>
            <div><span>运行环境</span><b>PHP <?= htmlspecialchars(PHP_VERSION) ?></b></div>
            <div><span>压缩支持</span><b><?= class_exists('ZipArchive') ? '已启用' : '未启用' ?></b></div>
            <div><span>数据存储</span><b>MySQL 数据库</b></div>
          </div>
        </div>
      </section>
      <?php endif; ?>
    </div>
  </main>
</div>

<!-- 悬浮上传队列 -->
<div class="upload-dock" id="uploadDock" hidden>
  <div class="dock-head">
    <span><i class="ri-upload-cloud-2-line"></i> 上传队列</span>
    <button class="icon-btn" id="dockClose"><i class="ri-close-line"></i></button>
  </div>
  <div class="dock-body" id="dockBody"></div>
</div>

<!-- 拖拽遮罩 -->
<div class="drop-mask" id="dropMask">
  <div class="drop-inner"><i class="ri-upload-cloud-2-line"></i><b>松开鼠标，上传到当前目录</b></div>
</div>

<!-- 预览层 -->
<div class="preview-mask" id="previewMask" hidden>
  <div class="preview-shell">
    <div class="preview-head">
      <div class="preview-title" id="previewTitle"></div>
      <div class="preview-tools">
        <a class="icon-btn" id="previewDownload" title="下载"><i class="ri-download-2-line"></i></a>
        <button class="icon-btn" id="previewClose" title="关闭"><i class="ri-close-line"></i></button>
      </div>
    </div>
    <div class="preview-body" id="previewBody"></div>
  </div>
</div>

<!-- 模态框 -->
<div class="modal-mask" id="modalMask" hidden>
  <div class="modal" id="modal">
    <div class="modal-head">
      <h3 id="modalTitle"></h3>
      <button class="icon-btn" id="modalClose"><i class="ri-close-line"></i></button>
    </div>
    <div class="modal-body" id="modalBody"></div>
    <div class="modal-foot" id="modalFoot"></div>
  </div>
</div>

<!-- 右键菜单 -->
<div class="ctx-menu" id="ctxMenu" hidden></div>

<!-- 提示 -->
<div class="toast-root" id="toastRoot"></div>

<input type="file" id="filePicker" multiple hidden>
<?php endif; ?>

<script>window.FM_BOOT = <?= $bootJson ?>;</script>
<script src="assets/app.js?v=<?= @filemtime(__DIR__ . '/assets/app.js') ?: FM_VERSION ?>"></script>
</body>
</html>
