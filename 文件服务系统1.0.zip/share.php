<?php
/**
 * 樱屿文件系统 · 文件分享页
 * 公开访问：通过令牌预览 / 下载，无需登录
 */
declare(strict_types=1);

require __DIR__ . '/core.php';

/* ------------------------------------------------------------------ *
 *  工具函数
 * ------------------------------------------------------------------ */

function share_size(int $bytes): string
{
    if ($bytes <= 0) {
        return '0 B';
    }
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = 0;
    $n = (float)$bytes;
    while ($n >= 1024 && $i < 4) {
        $n /= 1024;
        $i++;
    }
    return ($i === 0 ? (string)(int)$n : number_format($n, $n < 10 ? 1 : 0)) . ' ' . $units[$i];
}

/**
 * 分享路径始终按“站点全局根目录”解析，
 * 与当前是否登录、登录的是谁无关，避免普通用户的个人目录被重复拼接。
 */
function share_abs(string $rel): ?string
{
    try {
        $rel = fm_normalize_rel($rel);
    } catch (Throwable $e) {
        return null;
    }
    if ($rel === '') {
        return null;
    }
    $base = fm_base_root();
    $sysRel = str_replace('/', DIRECTORY_SEPARATOR, fm_to_sys($rel));
    $abs = rtrim($base, '/\\') . DIRECTORY_SEPARATOR . $sysRel;
    $real = realpath($abs);
    if ($real === false) {
        return null;
    }
    $baseNorm = rtrim(str_replace('\\', '/', $base), '/');
    $realNorm = str_replace('\\', '/', $real);
    if ($realNorm !== $baseNorm && !str_starts_with($realNorm . '/', $baseNorm . '/')) {
        return null;
    }
    return $real;
}

/* ------------------------------------------------------------------ *
 *  页面渲染
 * ------------------------------------------------------------------ */

function share_render(string $title, string $inner, int $code = 200, string $token = ''): void
{
    http_response_code($code);
    header('Content-Type: text/html; charset=utf-8');
    header('X-Robots-Tag: noindex, nofollow');
    header('Cache-Control: no-store');
    header('Referrer-Policy: no-referrer');
    header('X-Content-Type-Options: nosniff');

    $site = fm_site_name();
    $tokenJs = json_encode($token, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    if (!is_string($tokenJs)) {
        $tokenJs = '""';
    }

    echo '<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#fbf6ff">
<title>' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</title>
<link rel="icon" href="assets/appIcon.png">
<link rel="stylesheet" href="assets/vendor/remixicon/remixicon.css">
<style>
:root{
  --pink:#ec8bb6;--violet:#a58bf3;--ink:#3d3550;--ink2:#6a5f82;--muted:#9a90ad;
  --line:rgba(140,115,185,.14);
}
*{box-sizing:border-box}
body{
  margin:0;min-height:100vh;display:flex;flex-direction:column;
  font-family:system-ui,-apple-system,"Segoe UI","Microsoft YaHei","PingFang SC",sans-serif;
  color:var(--ink);line-height:1.7;overflow-x:hidden;
  background:
    radial-gradient(1200px 600px at 12% -10%,#fdeef6 0%,transparent 60%),
    radial-gradient(1000px 620px at 96% 4%,#efe9ff 0%,transparent 62%),
    linear-gradient(180deg,#fdfaff 0%,#f7f3ff 100%);
}
a{color:inherit;text-decoration:none}

/* 极光与花瓣 */
.aurora{position:fixed;inset:0;z-index:-2;overflow:hidden;pointer-events:none}
.aurora i{position:absolute;border-radius:50%;filter:blur(80px);opacity:.55}
.aurora i:nth-child(1){width:560px;height:560px;left:-190px;top:-190px;background:radial-gradient(circle,#f6c9de,#f6c9de00 70%)}
.aurora i:nth-child(2){width:620px;height:620px;right:-220px;top:0;background:radial-gradient(circle,#d9ccfb,#d9ccfb00 70%)}
.aurora i:nth-child(3){width:480px;height:480px;left:26%;bottom:-190px;background:radial-gradient(circle,#c8e6f6,#c8e6f600 70%)}
.petals{position:fixed;inset:0;z-index:-1;pointer-events:none;overflow:hidden}
.petals span{
  position:absolute;top:-40px;width:16px;height:13px;opacity:.55;
  background:linear-gradient(135deg,#f9d3e4,#eec0f2);
  border-radius:80% 0 80% 0;animation:fall linear infinite;
}
.petals span:nth-child(1){left:8%;animation-duration:16s;animation-delay:-2s}
.petals span:nth-child(2){left:24%;width:12px;height:10px;animation-duration:21s;animation-delay:-9s}
.petals span:nth-child(3){left:47%;animation-duration:18s;animation-delay:-5s}
.petals span:nth-child(4){left:66%;width:13px;height:11px;animation-duration:23s;animation-delay:-13s}
.petals span:nth-child(5){left:82%;animation-duration:19s;animation-delay:-7s}
.petals span:nth-child(6){left:93%;width:11px;height:9px;animation-duration:25s;animation-delay:-16s}
@keyframes fall{
  0%{transform:translate3d(0,-40px,0) rotate(0deg)}
  50%{transform:translate3d(40px,50vh,0) rotate(200deg)}
  100%{transform:translate3d(-20px,105vh,0) rotate(420deg)}
}
@media (prefers-reduced-motion:reduce){.petals{display:none}}

/* 顶栏 */
.top{
  width:min(920px,100%);margin:0 auto;padding:26px 22px 0;
  display:flex;align-items:center;gap:12px;
}
.logo{
  display:flex;align-items:center;gap:10px;font-weight:700;font-size:15px;letter-spacing:.2px;
}
.logo img{width:38px;height:38px;border-radius:12px;object-fit:cover;box-shadow:0 10px 24px -12px rgba(170,120,200,.7)}
.logo small{display:block;font-size:9px;letter-spacing:2.2px;color:var(--muted);font-weight:500;line-height:1.2}
.top .home{
  margin-left:auto;font-size:12px;color:var(--ink2);display:inline-flex;align-items:center;gap:6px;
  padding:8px 14px;border-radius:99px;background:rgba(255,255,255,.6);border:1px solid var(--line);
  transition:.2s;backdrop-filter:blur(10px);
}
.top .home:hover{background:#fff;transform:translateY(-1px)}
.top .home i{color:#a07ac9}

/* 主体 */
main{flex:1;display:grid;place-items:center;width:min(920px,100%);margin:0 auto;padding:34px 22px 20px}
.card{
  width:100%;border-radius:28px;overflow:hidden;position:relative;
  background:rgba(255,255,255,.78);backdrop-filter:blur(22px);
  border:1px solid rgba(255,255,255,.95);
  box-shadow:0 40px 90px -40px rgba(108,80,160,.45);
}
.card::before{
  content:"";position:absolute;inset:0 0 auto;height:120px;pointer-events:none;
  background:linear-gradient(120deg,rgba(247,200,220,.35),rgba(217,204,251,.35),rgba(200,230,246,.3));
}
.card-inner{position:relative;padding:34px 38px 30px}

.badge{
  display:inline-flex;align-items:center;gap:6px;font-size:11px;letter-spacing:1.6px;
  color:#a07ac9;background:rgba(165,139,243,.12);border-radius:99px;padding:5px 13px;font-weight:600;
}
.file-title{font-size:clamp(19px,2.6vw,25px);line-height:1.4;margin:16px 0 6px;word-break:break-all;letter-spacing:-.4px}
.file-sub{font-size:12.5px;color:var(--muted);margin:0 0 22px}
.file-sub b{color:#8f6be0;font-weight:600}

/* 预览与信息 */
.layout{display:grid;grid-template-columns:1.05fr 1fr;gap:26px;align-items:start}
.stage{
  border-radius:20px;min-height:230px;display:grid;place-items:center;overflow:hidden;
  background:linear-gradient(140deg,rgba(252,244,250,.9),rgba(243,238,255,.9));
  border:1px solid rgba(160,135,200,.12);padding:18px;
}
.stage .ficon{
  width:92px;height:92px;border-radius:28px;display:grid;place-items:center;font-size:44px;color:#8f6be0;
  background:linear-gradient(135deg,rgba(247,200,220,.85),rgba(217,204,251,.9));
  box-shadow:0 22px 44px -22px rgba(160,110,200,.8);
}
.stage img{width:100%;max-height:320px;object-fit:contain;border-radius:12px;display:block}
.stage video{width:100%;max-height:320px;border-radius:12px;background:#000;display:block}
.stage audio{width:100%}
.stage iframe{width:100%;height:330px;border:0;border-radius:12px;background:#fff}
.stage-note{margin-top:12px;font-size:10.5px;color:var(--muted);text-align:center;width:100%}

.meta-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:20px}
.meta-item{
  border-radius:13px;padding:11px 13px;background:rgba(250,247,255,.85);
  border:1px solid rgba(160,135,200,.12);
}
.meta-item span{display:flex;align-items:center;gap:5px;font-size:10.5px;color:var(--muted);margin-bottom:3px}
.meta-item span i{color:#b394e2;font-size:12px}
.meta-item b{font-size:12.5px;font-weight:600;color:var(--ink2);word-break:break-all;line-height:1.5}

.actions{display:grid;gap:9px}
.btn{
  display:inline-flex;align-items:center;justify-content:center;gap:9px;width:100%;
  font-size:14.5px;font-weight:600;padding:14px 20px;border-radius:15px;border:1px solid transparent;
  cursor:pointer;transition:transform .2s,box-shadow .2s,background .2s;font-family:inherit;
}
.btn-main{
  color:#fff;background:linear-gradient(135deg,#ee9ac0,#a58bf3);
  box-shadow:0 18px 38px -18px rgba(190,110,180,.9);
}
.btn-main:hover{transform:translateY(-2px);box-shadow:0 24px 46px -18px rgba(190,110,180,.95)}
.btn-ghost{
  color:var(--ink2);background:rgba(255,255,255,.7);border-color:var(--line);font-weight:500;font-size:13px;padding:11px 18px;
}
.btn-ghost:hover{background:#fff;transform:translateY(-1px)}
.btn-ghost.copied{color:#3f9d7c;border-color:rgba(63,157,124,.35)}
.tip{
  display:flex;gap:8px;align-items:flex-start;font-size:11px;color:var(--muted);
  margin:16px 0 0;line-height:1.8;
}
.tip i{color:#b394e2;margin-top:3px;flex:none}

/* 错误页 */
.notice{text-align:center;padding:14px 0 4px}
.notice .ficon{
  width:84px;height:84px;margin:6px auto 18px;border-radius:26px;display:grid;place-items:center;
  font-size:38px;color:#a58bf3;background:linear-gradient(135deg,rgba(247,200,220,.7),rgba(217,204,251,.8));
}
.notice h1{font-size:21px;margin:0 0 10px}
.notice p{font-size:13px;color:var(--muted);margin:0 auto 24px;max-width:340px}
.notice .btn{max-width:260px;margin:0 auto}

/* 页脚 */
footer{
  width:min(920px,100%);margin:0 auto;padding:0 22px 30px;text-align:center;
  font-size:11px;color:var(--muted);
}
footer b{color:#8f6be0;font-weight:600}
footer .links{margin-top:6px;display:flex;justify-content:center;gap:16px;font-size:10.5px}
footer .links a:hover{color:var(--ink2)}

/* 提示气泡 */
.toast{
  position:fixed;left:50%;bottom:34px;transform:translate(-50%,16px);
  background:rgba(48,38,66,.94);color:#fff;font-size:12.5px;padding:11px 20px;border-radius:12px;
  box-shadow:0 18px 40px -18px rgba(0,0,0,.5);opacity:0;pointer-events:none;transition:.28s;z-index:99;
  display:flex;align-items:center;gap:8px;
}
.toast.on{opacity:1;transform:translate(-50%,0)}
.toast i{color:#a8e6c4}

@media (max-width:760px){
  .layout{grid-template-columns:1fr;gap:20px}
  .card-inner{padding:28px 24px 24px}
  .stage{min-height:180px}
  main{padding:24px 16px 14px}
  .top{padding:20px 16px 0}
  footer{padding:0 16px 24px}
}
@media (max-width:420px){
  .meta-grid{grid-template-columns:1fr 1fr;gap:8px}
  .meta-item{padding:9px 11px}
  .top .home{font-size:11px;padding:7px 11px}
  .logo{font-size:14px}
  .logo img{width:34px;height:34px}
}
</style>
</head>
<body>
<div class="aurora" aria-hidden="true"><i></i><i></i><i></i></div>
<div class="petals" aria-hidden="true"><span></span><span></span><span></span><span></span><span></span><span></span></div>

<header class="top">
  <a class="logo" href="./">
    <img src="assets/appIcon.png" alt="">
    <span>' . htmlspecialchars($site, ENT_QUOTES, 'UTF-8') . '<small>FILE SHARING</small></span>
  </a>
  <a class="home" href="./"><i class="ri-home-4-line"></i> 文件管理器</a>
</header>

<main><div class="card"><div class="card-inner">' . $inner . '</div></div></main>

<footer>
  <div>由 <b>' . htmlspecialchars($site, ENT_QUOTES, 'UTF-8') . '</b> 提供文件分享服务</div>
  <div class="links"><span>无需登录</span><span>令牌加密</span><span>到期自动失效</span></div>
</footer>

<div class="toast" id="toast"><i class="ri-checkbox-circle-fill"></i><span>链接已复制</span></div>
<script>
(function () {
  var token = ' . $tokenJs . ';
  var toast = document.getElementById("toast");
  var timer = null;
  function show(msg) {
    if (!toast) return;
    toast.querySelector("span").textContent = msg;
    toast.classList.add("on");
    clearTimeout(timer);
    timer = setTimeout(function () { toast.classList.remove("on"); }, 2400);
  }
  window.shareCopy = function (btn) {
    var url = location.origin + location.pathname + (token ? "?t=" + token : "");
    function done(ok) {
      if (ok) {
        show("分享链接已复制");
        if (btn) {
          btn.classList.add("copied");
          var old = btn.innerHTML;
          btn.innerHTML = "<i class=\'ri-check-line\'></i> 已复制";
          setTimeout(function () { btn.innerHTML = old; btn.classList.remove("copied"); }, 2000);
        }
      } else {
        show("复制失败，请手动复制地址栏链接");
      }
    }
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(url).then(function () { done(true); }, function () { fallback(); });
    } else {
      fallback();
    }
    function fallback() {
      var ta = document.createElement("textarea");
      ta.value = url;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      var ok = false;
      try { ok = document.execCommand("copy"); } catch (e) {}
      ta.remove();
      done(ok);
    }
  };
})();
</script>
</body>
</html>';
    exit;
}

function share_notice(string $title, string $desc): string
{
    return '<div class="notice">'
        . '<span class="badge"><i class="ri-error-warning-line"></i> 无法访问</span>'
        . '<div class="ficon"><i class="ri-emotion-sad-line"></i></div>'
        . '<h1>' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</h1>'
        . '<p>' . htmlspecialchars($desc, ENT_QUOTES, 'UTF-8') . '</p>'
        . '<a class="btn btn-ghost" href="./"><i class="ri-home-4-line"></i> 返回文件管理器</a>'
        . '</div>';
}

/* ------------------------------------------------------------------ *
 *  校验令牌与文件
 * ------------------------------------------------------------------ */

if (!fm_is_installed()) {
    share_render('系统尚未安装', share_notice('系统尚未就绪', '请先完成文件服务系统的安装。'), 503);
}

$token = (string)($_GET['t'] ?? '');
if ($token === '' || !preg_match('/^[a-f0-9]{32}$/i', $token)) {
    share_render('分享不存在', share_notice('链接无效', '请确认链接是否完整，或向分享者重新获取。'), 404);
}

$db = fm_db();
$row = null;
if ($db) {
    try {
        $st = $db->prepare('SELECT * FROM fm_share WHERE token = ? LIMIT 1');
        $st->execute([$token]);
        $row = $st->fetch() ?: null;
    } catch (Throwable $e) {
        $row = null;
    }
}

if (!$row) {
    share_render('分享不存在', share_notice('分享不存在', '该分享可能已被取消，或链接有误。'), 404);
}

$expired = false;
if ((string)$row['expires_at'] !== '') {
    $exp = strtotime((string)$row['expires_at']);
    if ($exp !== false && $exp < time()) {
        $expired = true;
    }
}
if ($expired) {
    share_render('分享已过期', share_notice('分享链接已过期', '请联系分享者重新生成链接。'), 410);
}

$firstRel = explode('/', str_replace('\\', '/', (string)$row['rel_path']))[0] ?? '';
if ($firstRel !== '' && in_array(strtolower($firstRel), fm_system_entries(), true)) {
    share_render('无法访问', share_notice('该文件不可分享', '此分享指向系统文件，已被拒绝。'), 403);
}

$abs = share_abs((string)$row['rel_path']);
if ($abs === null || !is_file($abs)) {
    share_render('文件不存在', share_notice('文件已被移除', '分享的文件可能已被删除或移动。'), 404);
}

/* ------------------------------------------------------------------ *
 *  下载 / 预览输出（支持 Range）
 * ------------------------------------------------------------------ */

$isDownload = (string)($_GET['download'] ?? '') === '1';
$isRaw = (string)($_GET['raw'] ?? '') === '1';

if ($isDownload || $isRaw) {
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }
    while (ob_get_level() > 0) {
        ob_end_clean();
    }

    if ($isDownload && (!isset($_SERVER['HTTP_RANGE']) || $_SERVER['HTTP_RANGE'] === '')) {
        try {
            $db->prepare('UPDATE fm_share SET downloads = downloads + 1 WHERE id = ?')->execute([(int)$row['id']]);
        } catch (Throwable $e) {
            // 计数失败不影响下载
        }
    }

    $name = (string)$row['file_name'];
    $size = (int)@filesize($abs);
    $mime = fm_mime(fm_ext($name));

    header('Content-Type: ' . $mime);
    header('Content-Length: ' . $size);
    header('Accept-Ranges: bytes');
    header('Content-Disposition: ' . ($isRaw ? 'inline' : 'attachment') . '; filename="' . preg_replace('/[^\x20-\x7E]/', '_', $name) . '"; filename*=UTF-8\'\'' . rawurlencode($name));
    header('Cache-Control: private, max-age=600');
    header('X-Content-Type-Options: nosniff');

    $fp = @fopen($abs, 'rb');
    if (!$fp) {
        http_response_code(500);
        exit;
    }

    $start = 0;
    $end = $size > 0 ? $size - 1 : 0;
    if ($size > 0 && isset($_SERVER['HTTP_RANGE']) && preg_match('/bytes=(\d*)-(\d*)/', (string)$_SERVER['HTTP_RANGE'], $m)) {
        if ($m[1] !== '') {
            $start = (int)$m[1];
        }
        if ($m[2] !== '') {
            $end = (int)$m[2];
        }
        if ($start > $end || $start >= $size) {
            http_response_code(416);
            header('Content-Range: bytes */' . $size);
            fclose($fp);
            exit;
        }
        $end = min($end, $size - 1);
        http_response_code(206);
        header('Content-Range: bytes ' . $start . '-' . $end . '/' . $size);
        header('Content-Length: ' . ($end - $start + 1));
    }

    fseek($fp, $start);
    $remain = $end - $start + 1;
    $chunk = 1024 * 128;
    while ($remain > 0 && !feof($fp)) {
        $read = fread($fp, (int)min($chunk, $remain));
        if ($read === false) {
            break;
        }
        echo $read;
        $remain -= strlen($read);
        flush();
    }
    fclose($fp);
    exit;
}

/* ------------------------------------------------------------------ *
 *  分享页面
 * ------------------------------------------------------------------ */

$name = (string)$row['file_name'];
$size = (int)$row['file_size'];
$downloads = (int)$row['downloads'];

$expText = '长期有效';
$expSub = '';
if ((string)$row['expires_at'] !== '') {
    $expTs = (int)strtotime((string)$row['expires_at']);
    if ($expTs > 0) {
        $expText = date('Y-m-d H:i', $expTs);
        $left = $expTs - time();
        if ($left > 86400) {
            $expSub = '（还剩 ' . (int)ceil($left / 86400) . ' 天）';
        } elseif ($left > 3600) {
            $expSub = '（还剩 ' . (int)ceil($left / 3600) . ' 小时）';
        } elseif ($left > 0) {
            $expSub = '（即将到期）';
        }
    }
}
$createdText = '';
if ((string)$row['created_at'] !== '') {
    $cts = (int)strtotime((string)$row['created_at']);
    if ($cts > 0) {
        $createdText = date('Y-m-d H:i', $cts);
    }
}

$owner = '匿名分享';
if ((int)$row['user_id'] > 0) {
    try {
        $st = $db->prepare('SELECT username, nickname FROM fm_user WHERE id = ? LIMIT 1');
        $st->execute([(int)$row['user_id']]);
        $u = $st->fetch();
        if ($u) {
            $owner = ((string)$u['nickname'] !== '') ? (string)$u['nickname'] : (string)$u['username'];
        }
    } catch (Throwable $e) {
        // 忽略
    }
}

$ext = strtolower(fm_ext($name));
$kindText = $ext !== '' ? strtoupper($ext) . ' 文件' : '文件';
$icon = 'ri-file-3-fill';
if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg', 'ico', 'avif'], true)) {
    $icon = 'ri-image-2-fill';
    $kindText = strtoupper($ext) . ' 图片';
} elseif (in_array($ext, ['mp4', 'webm', 'mov', 'mkv', 'm4v', 'avi'], true)) {
    $icon = 'ri-video-fill';
    $kindText = strtoupper($ext) . ' 视频';
} elseif (in_array($ext, ['mp3', 'wav', 'ogg', 'flac', 'm4a', 'aac'], true)) {
    $icon = 'ri-music-2-fill';
    $kindText = strtoupper($ext) . ' 音频';
} elseif ($ext === 'pdf') {
    $icon = 'ri-file-pdf-2-fill';
    $kindText = 'PDF 文档';
} elseif (in_array($ext, ['zip', 'rar', '7z', 'gz', 'tar'], true)) {
    $icon = 'ri-file-zip-fill';
    $kindText = strtoupper($ext) . ' 压缩包';
} elseif (in_array($ext, ['doc', 'docx'], true)) {
    $icon = 'ri-file-word-2-fill';
    $kindText = 'Word 文档';
} elseif (in_array($ext, ['xls', 'xlsx', 'csv'], true)) {
    $icon = 'ri-file-excel-2-fill';
    $kindText = '表格文件';
} elseif (in_array($ext, ['ppt', 'pptx'], true)) {
    $icon = 'ri-file-ppt-2-fill';
    $kindText = '演示文稿';
} elseif (in_array($ext, ['txt', 'md', 'log', 'json', 'js', 'css', 'html', 'php', 'py', 'sql'], true)) {
    $icon = 'ri-file-code-line';
    $kindText = '文本 / 代码';
}

$tokenOut = htmlspecialchars($token, ENT_QUOTES, 'UTF-8');
$rawUrl = '?t=' . $tokenOut . '&amp;raw=1';

$stage = '';
if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'ico', 'avif'], true)) {
    $stage = '<img src="' . $rawUrl . '" alt="' . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . '">';
} elseif (in_array($ext, ['mp4', 'webm', 'mov', 'm4v'], true)) {
    $stage = '<video controls playsinline preload="metadata" src="' . $rawUrl . '"></video>';
} elseif (in_array($ext, ['mp3', 'wav', 'ogg', 'flac', 'm4a', 'aac'], true)) {
    $stage = '<div class="ficon"><i class="' . $icon . '"></i></div>'
        . '<audio controls preload="metadata" src="' . $rawUrl . '"></audio>';
} elseif ($ext === 'pdf') {
    $stage = '<iframe src="' . $rawUrl . '" title="PDF 预览"></iframe>';
} else {
    $stage = '<div class="ficon"><i class="' . $icon . '"></i></div>'
        . '<div class="stage-note">该格式暂不支持在线预览，请下载后查看</div>';
}

$inner = '<span class="badge"><i class="ri-share-forward-line"></i> 文件分享</span>'
    . '<h1 class="file-title">' . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . '</h1>'
    . '<p class="file-sub"><b>' . htmlspecialchars($owner, ENT_QUOTES, 'UTF-8') . '</b> 向你分享了一个文件，无需登录即可下载</p>'
    . '<div class="layout">'
    . '<div class="stage">' . $stage . '</div>'
    . '<div>'
    . '<div class="meta-grid">'
    . '<div class="meta-item"><span><i class="ri-hard-drive-2-line"></i> 文件大小</span><b>' . share_size($size) . '</b></div>'
    . '<div class="meta-item"><span><i class="ri-file-list-3-line"></i> 文件类型</span><b>' . htmlspecialchars($kindText, ENT_QUOTES, 'UTF-8') . '</b></div>'
    . '<div class="meta-item"><span><i class="ri-user-3-line"></i> 分享者</span><b>' . htmlspecialchars($owner, ENT_QUOTES, 'UTF-8') . '</b></div>'
    . '<div class="meta-item"><span><i class="ri-download-2-line"></i> 下载次数</span><b>' . $downloads . ' 次</b></div>'
    . '<div class="meta-item"><span><i class="ri-time-line"></i> 有效期</span><b>' . htmlspecialchars($expText . $expSub, ENT_QUOTES, 'UTF-8') . '</b></div>'
    . '<div class="meta-item"><span><i class="ri-calendar-line"></i> 分享时间</span><b>' . htmlspecialchars($createdText !== '' ? $createdText : '—', ENT_QUOTES, 'UTF-8') . '</b></div>'
    . '</div>'
    . '<div class="actions">'
    . '<a class="btn btn-main" href="?t=' . $tokenOut . '&amp;download=1"><i class="ri-download-cloud-2-line"></i> 下载文件 · ' . share_size($size) . '</a>'
    . '<button class="btn btn-ghost" type="button" onclick="shareCopy(this)"><i class="ri-link"></i> 复制分享链接</button>'
    . '</div>'
    . '<p class="tip"><i class="ri-shield-check-line"></i> 任何拿到链接的人都可以下载此文件，请只分享给信任的人；链接到期或被取消后将自动失效。</p>'
    . '</div>'
    . '</div>';

share_render($name . ' · 文件分享', $inner, 200, $token);
