/* ==========================================================================
   樱屿 · 前端交互
   ========================================================================== */
(function () {
  'use strict';

  var boot = window.FM_BOOT || {};
  var $ = function (sel, root) { return (root || document).querySelector(sel); };
  var $$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };
  var esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  var isTouch = !!(window.matchMedia && window.matchMedia('(hover: none)').matches);

  function api(action, options) {
    options = options || {};
    var method = options.method || 'GET';
    var url = new URL('api.php', location.href);
    url.searchParams.set('action', action);
    if (options.params) {
      Object.keys(options.params).forEach(function (k) {
        var v = options.params[k];
        if (v !== undefined && v !== null) url.searchParams.set(k, String(v));
      });
    }
    var opts = { method: method, headers: {} };
    if (method === 'POST') {
      opts.headers['X-CSRF-Token'] = boot.csrf;
      if (options.data instanceof FormData) {
        opts.body = options.data;
      } else {
        opts.headers['Content-Type'] = 'application/json';
        opts.body = JSON.stringify(options.data || {});
      }
    }
    return fetch(url.toString(), opts).then(function (res) {
      return res.text().then(function (text) {
        var data = null;
        try { data = text ? JSON.parse(text) : {}; } catch (e) { data = null; }
        if (!res.ok || !data || data.ok !== true) {
          var msg = (data && data.error) ? data.error : ('请求失败（' + res.status + '）');
          if (res.status === 401 && boot.loggedIn) {
            setTimeout(function () { location.reload(); }, 800);
          }
          throw new Error(msg);
        }
        return data;
      });
    }, function () {
      throw new Error('网络连接失败，请确认服务是否正常');
    });
  }

  function toast(message, type) {
    var root = $('#toastRoot');
    if (!root) return;
    var el = document.createElement('div');
    el.className = 'toast ' + (type === 'err' ? 'err' : 'ok');
    el.innerHTML = '<i class="ri-' + (type === 'err' ? 'error-warning-line' : 'checkbox-circle-line') + '"></i><span>' + esc(message) + '</span>';
    root.appendChild(el);
    setTimeout(function () {
      el.classList.add('out');
      setTimeout(function () { el.remove(); }, 300);
    }, 2600);
  }

  function fmtSize(bytes) {
    bytes = Number(bytes) || 0;
    if (bytes <= 0) return '0 B';
    var units = ['B', 'KB', 'MB', 'GB', 'TB'];
    var i = 0;
    var n = bytes;
    while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; }
    return (i === 0 ? String(Math.round(n)) : n.toFixed(n < 10 ? 1 : 0)) + ' ' + units[i];
  }

  var pad2 = function (n) { return (n < 10 ? '0' : '') + n; };

  function toDate(value) {
    if (value == null || value === '') return null;
    if (typeof value === 'number') return new Date(value * 1000);
    var d = new Date(String(value).replace(' ', 'T'));
    return isNaN(d.getTime()) ? null : d;
  }

  function fmtTime(value) {
    var d = toDate(value);
    if (!d) return '';
    var now = new Date();
    var hm = pad2(d.getHours()) + ':' + pad2(d.getMinutes());
    if (d.toDateString() === now.toDateString()) return '今天 ' + hm;
    var yesterday = new Date(now.getTime() - 86400000);
    if (d.toDateString() === yesterday.toDateString()) return '昨天 ' + hm;
    if (d.getFullYear() === now.getFullYear()) return (d.getMonth() + 1) + '月' + d.getDate() + '日 ' + hm;
    return d.getFullYear() + '/' + (d.getMonth() + 1) + '/' + d.getDate();
  }

  /* ====================================================================== *
   *  登录页
   * ====================================================================== */
  if (!boot.loggedIn) {
    initLogin();
    return;
  }

  function initLogin() {
    var form = $('#loginForm');
    var errEl = $('#loginError');
    var btn = $('#loginBtn');
    if (!form) return;

    var userInput = form.querySelector('input[name="username"]');
    if (userInput) setTimeout(function () { userInput.focus(); }, 200);

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      errEl.textContent = '';
      var username = String((form.querySelector('input[name="username"]') || {}).value || '').trim();
      var password = String((form.querySelector('input[name="password"]') || {}).value || '');
      if (!username || !password) {
        errEl.textContent = '请输入账号和密码';
        return;
      }
      var original = btn.innerHTML;
      btn.disabled = true;
      btn.innerHTML = '<i class="ri-loader-4-line spin"></i> 正在进入…';
      api('login', { method: 'POST', data: withAvatar({ username: username, password: password }) })
        .then(function (res) {
          if (res && res.csrf) boot.csrf = res.csrf;
          btn.innerHTML = '<i class="ri-checkbox-circle-line"></i> 欢迎回来';
          setTimeout(function () { location.reload(); }, 260);
        })
        .catch(function (err) {
          errEl.textContent = err.message;
          btn.disabled = false;
          btn.innerHTML = original;
          var pw = form.querySelector('input[name="password"]');
          if (pw) pw.focus();
        });
    });

    /* ---------- 头像选择 ---------- */
    var avatarFile = null;
    var avatarBox = $('.auth-avatar');
    var avatarPick = $('#avatarPick');
    var avatarInput = $('#avatarInput');
    var avatarPreview = $('#avatarPreview');
    var avatarTip = $('#avatarTip');
    var avatarHint = $('#avatarHint');

    function paintLoginAvatar(src, blank) {
      if (avatarPreview) {
        if (src) {
          avatarPreview.src = src;
          avatarPreview.hidden = false;
        } else {
          avatarPreview.removeAttribute('src');
          avatarPreview.hidden = true;
        }
      }
      if (avatarTip) avatarTip.hidden = !!src;
      ['#artAvatar', '#miniAvatar'].forEach(function (sel) {
        var box = $(sel);
        if (!box) return;
        var img = box.querySelector('img');
        var icon = box.querySelector('i');
        if (img) {
          if (src) {
            img.src = src;
            img.hidden = false;
          } else {
            img.removeAttribute('src');
            img.hidden = true;
          }
        }
        if (icon) icon.hidden = !!src || !!blank;
      });
    }

    if (avatarPick && avatarInput) {
      avatarPick.addEventListener('click', function () { avatarInput.click(); });
      ['#artAvatar', '#miniAvatar'].forEach(function (sel) {
        var box = $(sel);
        if (!box) return;
        box.style.cursor = 'pointer';
        box.title = '点击选择头像';
        box.addEventListener('click', function () {
          if (avatarBox && avatarBox.hidden) return;
          avatarInput.click();
        });
      });
    }
    if (avatarInput) {
      avatarInput.addEventListener('change', function () {
        var f = avatarInput.files && avatarInput.files[0];
        if (!f) return;
        if (avatarHint) avatarHint.textContent = '点击选择头像（可选）';
        if (!/^image\/(jpeg|png|webp|gif)$/.test(f.type)) {
          if (avatarHint) avatarHint.textContent = '仅支持 JPG、PNG、WEBP、GIF';
          avatarInput.value = '';
          return;
        }
        if (f.size > 3 * 1024 * 1024) {
          if (avatarHint) avatarHint.textContent = '头像不能超过 3MB';
          avatarInput.value = '';
          return;
        }
        avatarFile = f;
        if (avatarPreview) {
          avatarPreview.src = URL.createObjectURL(f);
          avatarPreview.hidden = false;
        }
        if (avatarPreview) paintLoginAvatar(avatarPreview.src, false);
        if (avatarTip) avatarTip.hidden = true;
        if (avatarHint) avatarHint.textContent = '已选择，登录/注册后生效';
      });
    }

    /* ---------- 根据账号自动显示头像 ---------- */
    var lookupTimer = null;
    var lookupSeq = 0;

    function lookupAvatar() {
      if (!userInput || avatarFile) return;
      var name = String(userInput.value || '').trim();
      clearTimeout(lookupTimer);
      if (!name) {
        lookupSeq++;
        paintLoginAvatar('', false);
        if (avatarHint) avatarHint.textContent = '点击选择头像（可选）';
        return;
      }
      lookupTimer = setTimeout(function () {
        var seq = ++lookupSeq;
        var url = 'api.php?action=avatar_name&username=' + encodeURIComponent(name);
        var probe = new Image();
        probe.onload = function () {
          if (seq === lookupSeq && !avatarFile) {
            paintLoginAvatar(url, false);
            if (avatarHint) avatarHint.textContent = '已找到该账号头像';
          }
        };
        probe.onerror = function () {
          if (seq === lookupSeq && !avatarFile) {
            paintLoginAvatar('', true);
            if (avatarHint) avatarHint.textContent = '该账号还没有头像';
          }
        };
        probe.src = url;
      }, 450);
    }

    if (userInput) {
      userInput.addEventListener('input', lookupAvatar);
      userInput.addEventListener('blur', lookupAvatar);
    }

    function withAvatar(obj) {
      if (!avatarFile) return obj;
      var fd = new FormData();
      Object.keys(obj).forEach(function (k) { fd.append(k, obj[k]); });
      fd.append('avatar', avatarFile);
      return fd;
    }

    /* ---------- 注册 ---------- */
    var regForm = $('#registerForm');
    var toReg = $('#switchToRegister');
    var toLogin = $('#switchToLogin');
    var heading = $('#authHeading');
    var sub = $('#authSub');

    function showAuth(name) {
      if (name === 'register' && boot.allowRegister === false) name = 'login';
      form.hidden = name !== 'login';
      if (regForm) regForm.hidden = name !== 'register';
      if (heading) heading.textContent = name === 'register' ? '创建账号' : '欢迎回来';
      if (sub) sub.textContent = name === 'register' ? '注册后即可一起管理文件' : '登录后继续整理你的文件空间';
      // 头像选择框只在注册时显示
      if (avatarBox) avatarBox.hidden = name !== 'register';
      if (name !== 'register' && avatarFile) {
        avatarFile = null;
        if (avatarInput) avatarInput.value = '';
        paintLoginAvatar('', false);
        if (avatarHint) avatarHint.textContent = '点击选择头像（可选）';
        lookupAvatar();
      }
      var box = name === 'register' ? regForm : form;
      if (box) {
        var first = box.querySelector('input');
        if (first) first.focus();
      }
    }

    if (toReg) toReg.addEventListener('click', function () { showAuth('register'); });
    if (toLogin) toLogin.addEventListener('click', function () { showAuth('login'); });

    showAuth('login');

    if (regForm) {
      var regErr = $('#registerError');
      var regBtn = $('#registerBtn');
      regForm.addEventListener('submit', function (e) {
        e.preventDefault();
        if (regErr) regErr.textContent = '';
        var username = String((regForm.querySelector('input[name="username"]') || {}).value || '').trim();
        var nickname = String((regForm.querySelector('input[name="nickname"]') || {}).value || '').trim();
        var p1 = String((regForm.querySelector('input[name="password"]') || {}).value || '');
        var p2 = String((regForm.querySelector('input[name="password2"]') || {}).value || '');
        if (!username || !p1) {
          if (regErr) regErr.textContent = '请填写账号和密码';
          return;
        }
        if (p1.length < 6) {
          if (regErr) regErr.textContent = '密码至少 6 位';
          return;
        }
        if (p1 !== p2) {
          if (regErr) regErr.textContent = '两次输入的密码不一致';
          return;
        }
        var original = regBtn.innerHTML;
        regBtn.disabled = true;
        regBtn.innerHTML = '<i class="ri-loader-4-line spin"></i> 正在创建…';
        api('register', { method: 'POST', data: withAvatar({ username: username, nickname: nickname, password: p1, password2: p2 }) })
          .then(function (res) {
            if (res && res.csrf) boot.csrf = res.csrf;
            regBtn.innerHTML = '<i class="ri-checkbox-circle-line"></i> 注册成功';
            setTimeout(function () { location.reload(); }, 300);
          })
          .catch(function (err) {
            if (regErr) regErr.textContent = err.message;
            regBtn.disabled = false;
            regBtn.innerHTML = original;
          });
      });
    }
  }

  /* ====================================================================== *
   *  应用
   * ====================================================================== */

  var KIND_ICON = {
    folder: 'ri-folder-3-fill',
    image: 'ri-image-2-fill',
    video: 'ri-video-fill',
    audio: 'ri-music-2-fill',
    pdf: 'ri-file-pdf-2-fill',
    doc: 'ri-file-word-2-fill',
    sheet: 'ri-file-excel-2-fill',
    ppt: 'ri-file-ppt-2-fill',
    zip: 'ri-file-zip-fill',
    code: 'ri-code-s-slash-fill',
    text: 'ri-file-text-fill',
    file: 'ri-file-3-fill'
  };

  var KIND_GROUP = {
    image: ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg', 'ico', 'avif', 'heic'],
    video: ['mp4', 'webm', 'mov', 'mkv', 'm4v', 'avi', 'flv', 'wmv'],
    audio: ['mp3', 'wav', 'ogg', 'flac', 'm4a', 'aac', 'wma', 'opus'],
    doc: ['doc', 'docx', 'rtf', 'odt', 'pages'],
    sheet: ['xls', 'xlsx', 'csv', 'ods', 'numbers'],
    ppt: ['ppt', 'pptx', 'odp', 'key'],
    zip: ['zip', 'rar', '7z', 'gz', 'tar', 'bz2', 'xz']
  };

  var TEXT_EXT = ['txt', 'md', 'markdown', 'log', 'json', 'xml', 'yml', 'yaml', 'ini', 'conf', 'cfg',
    'css', 'scss', 'less', 'js', 'mjs', 'cjs', 'ts', 'jsx', 'tsx', 'vue', 'php', 'py', 'rb', 'java',
    'c', 'h', 'cpp', 'hpp', 'go', 'rs', 'sh', 'bash', 'bat', 'ps1', 'sql', 'html', 'htm', 'svg',
    'csv', 'rtf', 'env', 'gitignore', 'htaccess', 'properties'];

  function kindOf(item) {
    if (item.type === 'dir') return 'folder';
    var ext = (item.ext || '').toLowerCase();
    if (KIND_GROUP.image.indexOf(ext) >= 0) return 'image';
    if (KIND_GROUP.video.indexOf(ext) >= 0) return 'video';
    if (KIND_GROUP.audio.indexOf(ext) >= 0) return 'audio';
    if (KIND_GROUP.doc.indexOf(ext) >= 0) return 'doc';
    if (KIND_GROUP.sheet.indexOf(ext) >= 0) return 'sheet';
    if (KIND_GROUP.ppt.indexOf(ext) >= 0) return 'ppt';
    if (KIND_GROUP.zip.indexOf(ext) >= 0) return 'zip';
    if (ext === 'pdf') return 'pdf';
    if (TEXT_EXT.indexOf(ext) >= 0) return 'code';
    if (['txt', 'md', 'log'].indexOf(ext) >= 0) return 'text';
    return 'file';
  }

  function isTextFile(item) {
    if (!item || item.type === 'dir') return false;
    var name = (item.name || '').toLowerCase();
    var ext = (item.ext || '').toLowerCase();
    if (name === '.htaccess' || name === '.env' || name.indexOf('.') === -1 || name.charAt(0) === '.') {
      return true;
    }
    return TEXT_EXT.indexOf(ext) >= 0;
  }

  function lsGet(key, fallback) {
    try {
      var v = localStorage.getItem(key);
      return v === null ? fallback : v;
    } catch (e) {
      return fallback;
    }
  }

  function lsSet(key, value) {
    try { localStorage.setItem(key, value); } catch (e) {}
  }

  function loadClipboard() {
    try {
      var raw = sessionStorage.getItem('fm-clipboard');
      if (!raw) return null;
      var data = JSON.parse(raw);
      if (data && (data.mode === 'copy' || data.mode === 'cut') && Array.isArray(data.paths)) {
        var paths = data.paths.filter(function (p) { return typeof p === 'string' && p !== ''; });
        return paths.length ? { mode: data.mode, paths: paths } : null;
      }
    } catch (e) {}
    return null;
  }

  function saveClipboard() {
    try {
      if (state.clipboard && state.clipboard.paths.length) {
        sessionStorage.setItem('fm-clipboard', JSON.stringify(state.clipboard));
      } else {
        sessionStorage.removeItem('fm-clipboard');
      }
    } catch (e) {}
  }

  var state = {
    path: '',
    items: [],
    breadcrumb: [{ name: '全部文件', path: '' }],
    selected: new Set(),
    lastIndex: -1,
    filter: '',
    searchMode: false,
    searchQuery: '',
    view: lsGet('fm-view', 'grid') === 'list' ? 'list' : 'grid',
    sort: lsGet('fm-sort', 'name'),
    order: lsGet('fm-order', 'asc') === 'desc' ? 'desc' : 'asc',
    clipboard: loadClipboard(),
    hideHidden: lsGet('fm-hide-hidden', '0') === '1',
    selecting: false,
    logsPage: 1,
    logsPages: 1,
    preview: null
  };

  var el = {
    sidebar: $('#sidebar'),
    scrim: $('#sidebarScrim'),
    fileList: $('#fileList'),
    skeleton: $('#skeleton'),
    empty: $('#emptyState'),
    crumbs: $('#crumbs'),
    viewTitle: $('#viewTitle'),
    viewMeta: $('#viewMeta'),
    selBar: $('#selBar'),
    selText: $('#selText'),
    search: $('#searchInput'),
    filePicker: $('#filePicker'),
    previewMask: $('#previewMask'),
    previewBody: $('#previewBody'),
    previewTitle: $('#previewTitle'),
    previewDownload: $('#previewDownload'),
    previewTools: $('.preview-tools'),
    modalMask: $('#modalMask'),
    modal: $('#modal'),
    modalTitle: $('#modalTitle'),
    modalBody: $('#modalBody'),
    modalFoot: $('#modalFoot'),
    ctxMenu: $('#ctxMenu'),
    dock: $('#uploadDock'),
    dockBody: $('#dockBody'),
    dropMask: $('#dropMask'),
    toastRoot: $('#toastRoot')
  };

  var menuItems = [];
  var modalResolve = null;
  var pickerSeq = 0;
  var loadSeq = 0;

  /* ------------------------------ 路由 ------------------------------ */

  function showView(name) {
    var map = { files: '#filesView', recent: '#recentView', settings: '#settingsView' };
    Object.keys(map).forEach(function (k) {
      var node = $(map[k]);
      if (node) node.hidden = (k !== name);
    });
    $$('.nav-item').forEach(function (a) {
      a.classList.toggle('active', a.getAttribute('data-nav') === name);
    });
  }

  function hashPath() {
    var h = location.hash || '';
    if (h.indexOf('#/files') !== 0) return null;
    var rest = h.slice(7);
    if (rest.charAt(0) === '/') rest = rest.slice(1);
    if (!rest) return '';
    try { return decodeURIComponent(rest); } catch (e) { return ''; }
  }

  function goTo(path) {
    var target = '#/files' + (path ? '/' + encodeURIComponent(path) : '');
    if (location.hash === target) {
      loadDir(path);
    } else {
      location.hash = target;
    }
  }

  function route() {
    var h = location.hash || '';
    if (!h || h === '#' || h === '#/') {
      location.hash = '#/files';
      return;
    }
    if (h.indexOf('#/files') === 0) {
      var p = hashPath() || '';
      showView('files');
      if (p !== state.path || !state.loaded) loadDir(p);
      else renderFiles();
      return;
    }
    if (h.indexOf('#/recent') === 0) {
      showView('recent');
      loadLogs(1);
      return;
    }
    if (h.indexOf('#/settings') === 0 && $('#settingsView')) {
      showView('settings');
      loadSettings();
      return;
    }
    location.hash = '#/files';
  }

  /* ------------------------------ 目录 ------------------------------ */

  function loadDir(path) {
    var seq = ++loadSeq;
    state.path = path;
    state.selected.clear();
    state.lastIndex = -1;
    state.filter = '';
    state.searchMode = false;
    state.searchQuery = '';
    state.loaded = true;
    if (el.search) el.search.value = '';
    updateSelBar();
    if (el.skeleton) el.skeleton.hidden = false;
    if (el.fileList) el.fileList.hidden = true;
    if (el.empty) el.empty.hidden = true;

    return api('list', { params: { path: path, sort: state.sort, order: state.order } })
      .then(function (res) {
        if (seq !== loadSeq) return;
        state.items = res.items || [];
        state.breadcrumb = res.breadcrumb || [{ name: '全部文件', path: '' }];
        renderCrumbs();
        updateStorage(res.disk);
        renderFiles();
      })
      .catch(function (err) {
        if (seq !== loadSeq) return;
        state.items = [];
        state.breadcrumb = [{ name: '全部文件', path: '' }];
        renderCrumbs();
        renderFiles();
        toast(err.message, 'err');
      })
      .then(function () {
        if (seq !== loadSeq) return;
        if (el.skeleton) el.skeleton.hidden = true;
      });
  }

  function reloadCurrent() {
    if (state.searchMode && state.searchQuery) {
      return doSearch(state.searchQuery);
    }
    return loadDir(state.path);
  }

  function doSearch(q) {
    var seq = ++loadSeq;
    state.searchQuery = q;
    state.searchMode = true;
    state.selected.clear();
    updateSelBar();
    if (location.hash.indexOf('#/files') !== 0) {
      try { history.replaceState(null, '', '#/files'); } catch (e) { location.hash = '#/files'; }
    }
    if (el.skeleton) el.skeleton.hidden = false;
    if (el.fileList) el.fileList.hidden = true;
    if (el.empty) el.empty.hidden = true;
    showView('files');

    return api('search', { params: { path: state.path, q: q } })
      .then(function (res) {
        if (seq !== loadSeq) return;
        state.items = res.items || [];
        renderFiles();
        if (!state.items.length) toast('没有找到匹配的内容', 'err');
      })
      .catch(function (err) {
        if (seq !== loadSeq) return;
        toast(err.message, 'err');
        state.items = [];
        renderFiles();
      })
      .then(function () {
        if (seq !== loadSeq) return;
        if (el.skeleton) el.skeleton.hidden = true;
      });
  }

  function clearSearch() {
    if (!state.searchMode) return;
    state.searchMode = false;
    state.searchQuery = '';
    if (el.search) el.search.value = '';
    loadDir(state.path);
  }

  /* ------------------------------ 渲染 ------------------------------ */

  function renderCrumbs() {
    var crumbs = state.breadcrumb || [];
    var html = crumbs.map(function (c, i) {
      var last = i === crumbs.length - 1;
      var icon = i === 0 ? '<i class="ri-home-smile-2-line"></i>' : '';
      var href = '#/files' + (c.path ? '/' + encodeURIComponent(c.path) : '');
      return '<a class="crumb' + (last ? ' current' : '') + '" href="' + href + '">' + icon + '<span>' + esc(c.name) + '</span></a>' +
        (last ? '' : '<i class="ri-arrow-right-s-line crumb-sep"></i>');
    }).join('');
    el.crumbs.innerHTML = html;
  }

  function filteredItems() {
    var items = state.items;
    if (state.hideHidden) {
      items = items.filter(function (i) { return String(i.name).charAt(0) !== '.'; });
    }
    if (!state.filter) return items;
    var q = state.filter.toLowerCase();
    return items.filter(function (i) {
      return String(i.name).toLowerCase().indexOf(q) >= 0;
    });
  }

  function rawUrl(path) {
    return 'api.php?action=raw&path=' + encodeURIComponent(path);
  }

  function downloadUrl(path) {
    return 'api.php?action=download&path=' + encodeURIComponent(path);
  }

  function tileHtml(item, index) {
    var kind = kindOf(item);
    var icon = KIND_ICON[kind] || KIND_ICON.file;
    var selected = state.selected.has(item.path) ? ' selected' : '';
    var thumb = '';
    if (kind === 'image') {
      thumb = '<img src="' + rawUrl(item.path) + '" alt="" loading="lazy" onerror="this.remove()">';
    }
    var meta = item.type === 'dir' ? '文件夹' : fmtSize(item.size);
    return '<div class="tile' + selected + '" data-path="' + esc(item.path) + '" data-type="' + item.type + '" style="animation-delay:' + Math.min(index * 16, 320) + 'ms">' +
      '<span class="tile-check"><i class="ri-check-line"></i></span>' +
      '<button class="tile-more" title="更多操作"><i class="ri-more-2-fill"></i></button>' +
      '<div class="tile-top"><div class="tile-icon' + (kind === 'image' ? ' thumb' : '') + '" data-kind="' + kind + '">' + thumb + '<i class="' + icon + '"></i></div></div>' +
      '<div class="tile-name">' + esc(item.name) + '</div>' +
      '<div class="tile-meta"><span>' + esc(meta) + '</span><span class="tile-time">' + esc(fmtTime(item.mtime)) + '</span></div>' +
      '</div>';
  }

  function rowHtml(item, index) {
    var kind = kindOf(item);
    var icon = KIND_ICON[kind] || KIND_ICON.file;
    var selected = state.selected.has(item.path) ? ' selected' : '';
    return '<div class="row' + selected + '" data-path="' + esc(item.path) + '" data-type="' + item.type + '" style="animation-delay:' + Math.min(index * 10, 240) + 'ms">' +
      '<span class="row-check"><i class="ri-check-line"></i></span>' +
      '<div class="row-icon" data-kind="' + kind + '"><i class="' + icon + '"></i></div>' +
      '<div class="row-name"><b>' + esc(item.name) + '</b></div>' +
      '<div class="row-size">' + (item.type === 'dir' ? '—' : esc(fmtSize(item.size))) + '</div>' +
      '<div class="row-time">' + esc(fmtTime(item.mtime)) + '</div>' +
      '<button class="row-more" title="更多操作"><i class="ri-more-2-fill"></i></button>' +
      '</div>';
  }

  function renderFiles() {
    var items = filteredItems();
    if (el.fileList) {
      el.fileList.className = 'file-list ' + state.view;
      el.fileList.innerHTML = items.map(function (it, i) {
        return state.view === 'grid' ? tileHtml(it, i) : rowHtml(it, i);
      }).join('');
      el.fileList.hidden = items.length === 0;
    }
    if (el.empty) el.empty.hidden = items.length > 0;

    var dirCount = state.items.filter(function (i) { return i.type === 'dir'; }).length;
    var fileCount = state.items.length - dirCount;

    if (state.searchMode) {
      el.viewTitle.textContent = '搜索结果';
      el.viewMeta.innerHTML = '在 ' + esc(state.path ? '/' + state.path : '根目录') + ' 中找到 <b>' + state.items.length + '</b> 项 · <a href="javascript:void(0)" data-clear-search>清除搜索</a>';
    } else if (state.filter) {
      el.viewTitle.textContent = state.path ? state.path.split('/').pop() : '全部文件';
      el.viewMeta.textContent = '筛选出 ' + items.length + ' 项 / 共 ' + state.items.length + ' 项';
    } else {
      el.viewTitle.textContent = state.path ? state.path.split('/').pop() : '全部文件';
      el.viewMeta.textContent = dirCount + ' 个文件夹 · ' + fileCount + ' 个文件' + (isTouch ? '' : ' · 双击打开');
    }

    if (el.empty) {
      var h3 = el.empty.querySelector('h3');
      var p = el.empty.querySelector('p');
      if (h3) h3.textContent = state.searchMode || state.filter ? '没有找到相关文件' : '这里还是一张白纸';
      if (p) p.textContent = state.searchMode || state.filter ? '换个关键词再试试吧' : '上传文件，或新建一个文件夹开始整理吧';
    }
    applyClipMarks();
  }

  /* ------------------------------ 剪贴板 ------------------------------ */

  function parentOf(path) {
    var parts = String(path).split('/');
    parts.pop();
    return parts.join('/');
  }

  function setClipboard(mode, paths) {
    paths = (paths || []).filter(Boolean);
    if (!paths.length) {
      toast('请先选择文件或文件夹', 'err');
      return;
    }
    state.clipboard = { mode: mode, paths: paths.slice() };
    saveClipboard();
    updatePasteUI();
    applyClipMarks();
    toast((mode === 'cut' ? '已剪切 ' : '已复制 ') + paths.length + ' 项，可到目标文件夹粘贴');
  }

  function updatePasteUI() {
    var btn = $('#pasteBtn');
    if (!btn) return;
    var clip = state.clipboard;
    var has = !!(clip && clip.paths && clip.paths.length);
    btn.hidden = !has;
    if (has) {
      var cnt = $('#pasteCount');
      if (cnt) cnt.textContent = String(clip.paths.length);
      btn.title = (clip.mode === 'cut' ? '移动到当前文件夹' : '复制到当前文件夹') + '（' + clip.paths.length + ' 项）';
    }
  }

  function applyClipMarks() {
    if (!el.fileList) return;
    var cutMap = {};
    if (state.clipboard && state.clipboard.mode === 'cut') {
      state.clipboard.paths.forEach(function (p) { cutMap[p] = true; });
    }
    $$('[data-path]', el.fileList).forEach(function (node) {
      node.classList.toggle('cut', !!cutMap[node.getAttribute('data-path')]);
    });
  }

  function pasteClipboard() {
    var clip = state.clipboard;
    if (!clip || !clip.paths.length) {
      toast('剪贴板是空的', 'err');
      return Promise.resolve();
    }
    var dest = state.path;
    var paths = clip.paths.slice();
    var isMove = clip.mode === 'cut';
    if (isMove) {
      paths = paths.filter(function (p) { return parentOf(p) !== dest; });
      if (!paths.length) {
        toast('这些项目已经位于当前文件夹', 'err');
        return Promise.resolve();
      }
    }
    return api(isMove ? 'move' : 'copy', { method: 'POST', data: { paths: paths, dest: dest } })
      .then(function (res) {
        var failed = (res.failed && res.failed.length) ? res.failed : [];
        if (failed.length) {
          toast(failed[0].error || '部分项目未能完成', 'err');
        } else {
          toast(isMove ? '已移动到当前文件夹' : '已复制到当前文件夹');
        }
        // 全部成功才清空剪切板，失败的项目保留以便重试
        if (isMove && !failed.length) {
          state.clipboard = null;
          saveClipboard();
          updatePasteUI();
        }
        applyClipMarks();
        reloadCurrent();
      })
      .catch(function (err) { toast(err.message, 'err'); });
  }

  function toggleHidden() {
    state.hideHidden = !state.hideHidden;
    lsSet('fm-hide-hidden', state.hideHidden ? '1' : '0');
    updateHiddenBtn();
    renderFiles();
  }

  function updateHiddenBtn() {
    var btn = $('#hiddenBtn');
    if (!btn) return;
    btn.innerHTML = '<i class="' + (state.hideHidden ? 'ri-eye-off-line' : 'ri-eye-line') + '"></i>';
    btn.title = state.hideHidden ? '已隐藏 . 开头的文件，点击显示' : '隐藏 . 开头的文件';
    btn.classList.toggle('active', state.hideHidden);
  }

  function updateStorage(disk) {
    if (!disk || !disk.total) {
      var t = $('#diskText');
      if (t) t.textContent = '—';
      return;
    }
    var used = Math.max(0, disk.total - disk.free);
    var pct = Math.min(100, Math.round(used / disk.total * 100));
    var txt = $('#diskText');
    var bar = $('#diskBar');
    if (txt) txt.textContent = fmtSize(used) + ' / ' + fmtSize(disk.total);
    if (bar) bar.style.width = pct + '%';
  }

  /* ------------------------------ 选择 ------------------------------ */

  function findItem(path) {
    for (var i = 0; i < state.items.length; i++) {
      if (state.items[i].path === path) return state.items[i];
    }
    return null;
  }

  function syncSelection() {
    var nodes = $$('[data-path]', el.fileList);
    nodes.forEach(function (n) {
      n.classList.toggle('selected', state.selected.has(n.getAttribute('data-path')));
    });
    updateSelBar();
  }

  function updateSelBar() {
    if (!el.selBar) return;
    var n = state.selected.size;
    el.selBar.hidden = !state.selecting || n === 0;
    if (el.selText) el.selText.textContent = '已选择 ' + n + ' 项';
    if (el.fileList) el.fileList.classList.toggle('selecting', state.selecting && n > 0);
  }

  function selectOnly(path, selecting) {
    state.selected.clear();
    state.selected.add(path);
    state.selecting = !!selecting;
    var idx = filteredItems().findIndex(function (i) { return i.path === path; });
    state.lastIndex = idx;
    syncSelection();
  }

  function toggleSelect(path) {
    state.selecting = true;
    if (state.selected.has(path)) state.selected.delete(path);
    else state.selected.add(path);
    syncSelection();
  }

  function selectRange(path) {
    var items = filteredItems();
    var idx = items.findIndex(function (i) { return i.path === path; });
    if (idx < 0) return;
    if (state.lastIndex < 0 || state.lastIndex >= items.length) {
      state.lastIndex = idx;
    }
    var a = Math.min(state.lastIndex, idx);
    var b = Math.max(state.lastIndex, idx);
    for (var i = a; i <= b; i++) state.selected.add(items[i].path);
    state.lastIndex = idx;
    state.selecting = true;
    syncSelection();
  }

  function clearSelection() {
    state.selected.clear();
    state.selecting = false;
    syncSelection();
  }

  function selectAllVisible() {
    state.selected.clear();
    filteredItems().forEach(function (i) { state.selected.add(i.path); });
    state.selecting = true;
    syncSelection();
  }

  function invertSelection() {
    var next = new Set();
    filteredItems().forEach(function (i) {
      if (!state.selected.has(i.path)) next.add(i.path);
    });
    state.selected = next;
    state.selecting = true;
    syncSelection();
  }

  function selectedPaths() {
    return Array.from(state.selected);
  }

  function openItem(item) {
    if (!item) return;
    if (item.type === 'dir') {
      goTo(item.path);
      return;
    }
    if (item.ext === 'zip') {
      showArchive(item);
      return;
    }
    openPreview(item);
  }

  /* ------------------------------ 文件交互 ------------------------------ */

  function bindFileEvents() {
    var pressTimer = null;
    var ignoreClickUntil = 0;

    function cancelPress() {
      if (pressTimer) {
        clearTimeout(pressTimer);
        pressTimer = null;
      }
    }

    // 触屏长按：进入选择状态，显示复选框
    el.fileList.addEventListener('touchstart', function (e) {
      if (e.touches.length > 1) return;
      var node = e.target.closest('[data-path]');
      if (!node || e.target.closest('.tile-more, .row-more, .tile-check, .row-check')) return;
      cancelPress();
      pressTimer = setTimeout(function () {
        pressTimer = null;
        var item = findItem(node.getAttribute('data-path'));
        if (!item) return;
        ignoreClickUntil = Date.now() + 800;
        selectOnly(item.path, true);
        if (navigator.vibrate) navigator.vibrate(12);
      }, 480);
    }, { passive: true });
    el.fileList.addEventListener('touchend', cancelPress);
    el.fileList.addEventListener('touchmove', cancelPress);
    el.fileList.addEventListener('touchcancel', cancelPress);

    el.fileList.addEventListener('click', function (e) {
      if (Date.now() < ignoreClickUntil) {
        ignoreClickUntil = 0;
        e.preventDefault();
        return;
      }
      var more = e.target.closest('.tile-more, .row-more');
      var check = e.target.closest('.tile-check, .row-check');
      var node = e.target.closest('[data-path]');

      if (check && node) {
        e.stopPropagation();
        toggleSelect(node.getAttribute('data-path'));
        return;
      }
      if (more && node) {
        e.stopPropagation();
        var item = findItem(node.getAttribute('data-path'));
        if (item) {
          if (state.selected.has(item.path)) {
            var r = more.getBoundingClientRect();
            showItemMenu(item, r.right - 190, r.bottom + 6);
          } else {
            selectOnly(item.path);
            var r2 = more.getBoundingClientRect();
            showItemMenu(item, r2.right - 190, r2.bottom + 6);
          }
        }
        return;
      }
      if (!node) {
        if (!isTouch) clearSelection();
        return;
      }
      var it = findItem(node.getAttribute('data-path'));
      if (!it) return;

      if (isTouch) {
        // 处于选择状态时，点击用于多选而不是打开
        if (state.selecting) {
          toggleSelect(it.path);
        } else {
          openItem(it);
        }
        return;
      }
      if (e.metaKey || e.ctrlKey) {
        toggleSelect(it.path);
        return;
      }
      if (e.shiftKey) {
        selectRange(it.path);
        return;
      }
      selectOnly(it.path);
    });

    el.fileList.addEventListener('dblclick', function (e) {
      var node = e.target.closest('[data-path]');
      if (!node) return;
      if (e.target.closest('.tile-more, .row-more, .tile-check, .row-check')) return;
      openItem(findItem(node.getAttribute('data-path')));
    });

    el.fileList.addEventListener('contextmenu', function (e) {
      var node = e.target.closest('[data-path]');
      if (!node) return;
      e.preventDefault();
      var item = findItem(node.getAttribute('data-path'));
      if (!item) return;
      if (!state.selected.has(item.path)) selectOnly(item.path);
      showItemMenu(item, e.clientX, e.clientY);
    });

    el.viewMeta.addEventListener('click', function (e) {
      if (e.target.closest('[data-clear-search]')) clearSearch();
    });

    $$('[data-batch]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var act = btn.getAttribute('data-batch');
        if (act === 'clear') { clearSelection(); return; }
        if (act === 'paste') { pasteClipboard(); return; }
        var paths = selectedPaths();
        if (!paths.length) return;
        if (act === 'copyclip') setClipboard('copy', paths);
        else if (act === 'cut') setClipboard('cut', paths);
        else if (act === 'delete') deleteItems(paths);
        else if (act === 'download') downloadItems(paths);
        else if (act === 'copy') moveOrCopy(paths, 'copy');
        else if (act === 'move') moveOrCopy(paths, 'move');
        else if (act === 'zip') zipItems(paths);
      });
    });

    $$('[data-empty]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var act = btn.getAttribute('data-empty');
        if (act === 'upload') el.filePicker.click();
        else if (act === 'mkdir') createFolder();
      });
    });
  }

  /* ------------------------------ 菜单 ------------------------------ */

  function hideMenu() {
    if (!el.ctxMenu) return;
    el.ctxMenu.hidden = true;
    menuItems = [];
  }

  function showMenu(x, y, items) {
    menuItems = items;
    el.ctxMenu.innerHTML = items.map(function (it, i) {
      if (it.sep) return '<div class="ctx-sep"></div>';
      return '<div class="ctx-item' + (it.danger ? ' danger' : '') + (it.disabled ? ' disabled' : '') + '" data-index="' + i + '"><i class="' + (it.icon || 'ri-record-circle-line') + '"></i><span>' + esc(it.label) + '</span></div>';
    }).join('');
    el.ctxMenu.hidden = false;
    el.ctxMenu.style.left = '0px';
    el.ctxMenu.style.top = '0px';
    var rect = el.ctxMenu.getBoundingClientRect();
    var left = Math.min(x, window.innerWidth - rect.width - 12);
    var top = Math.min(y, window.innerHeight - rect.height - 12);
    el.ctxMenu.style.left = Math.max(8, left) + 'px';
    el.ctxMenu.style.top = Math.max(8, top) + 'px';
  }

  function showItemMenu(item, x, y) {
    var targets = (state.selected.has(item.path) && state.selected.size > 1) ? selectedPaths() : [item.path];
    var many = targets.length > 1;
    var hasClip = !!(state.clipboard && state.clipboard.paths && state.clipboard.paths.length);
    var items = [];

    if (!many) {
      items.push({ label: '打开', icon: item.type === 'dir' ? 'ri-folder-open-line' : 'ri-eye-line', action: function () { openItem(item); } });
      if (item.type === 'file') {
        items.push({ label: '下载', icon: 'ri-download-2-line', action: function () { triggerDownload(downloadUrl(item.path)); } });
      }
      items.push({ sep: true });
      items.push({ label: '复制', icon: 'ri-file-copy-line', action: function () { setClipboard('copy', targets); } });
      items.push({ label: '剪切', icon: 'ri-scissors-cut-line', action: function () { setClipboard('cut', targets); } });
      items.push({ label: '粘贴到此处', icon: 'ri-clipboard-line', disabled: !hasClip, action: function () { pasteClipboard(); } });
      items.push({ sep: true });
      items.push({ label: '重命名', icon: 'ri-edit-2-line', action: function () { renameItem(item); } });
      items.push({ label: '复制路径', icon: 'ri-link', action: function () { copyToSystem('/' + item.path); } });
      items.push({ label: '属性', icon: 'ri-information-line', action: function () { showDetail(item); } });
    } else {
      items.push({ label: '复制所选 ' + targets.length + ' 项', icon: 'ri-file-copy-line', action: function () { setClipboard('copy', targets); } });
      items.push({ label: '剪切所选 ' + targets.length + ' 项', icon: 'ri-scissors-cut-line', action: function () { setClipboard('cut', targets); } });
      items.push({ label: '粘贴到此处', icon: 'ri-clipboard-line', disabled: !hasClip, action: function () { pasteClipboard(); } });
      items.push({ sep: true });
      items.push({ label: '下载所选 ' + targets.length + ' 项', icon: 'ri-download-2-line', action: function () { downloadItems(targets); } });
    }

    items.push({ label: '复制到…', icon: 'ri-file-copy-2-line', action: function () { moveOrCopy(targets, 'copy'); } });
    items.push({ label: '移动到…', icon: 'ri-drag-move-2-line', action: function () { moveOrCopy(targets, 'move'); } });
    items.push({ label: '压缩为 ZIP', icon: 'ri-file-zip-line', action: function () { zipItems(targets); } });

    if (!many && item.ext === 'zip') {
      items.push({ sep: true });
      items.push({ label: '查看压缩包内容', icon: 'ri-list-unordered', action: function () { showArchive(item); } });
    }

    items.push({ sep: true });
    items.push({ label: '删除' + (many ? '所选' : ''), icon: 'ri-delete-bin-6-line', danger: true, action: function () { deleteItems(targets); } });
    showMenu(x, y, items);
  }

  if (el.ctxMenu) {
    el.ctxMenu.addEventListener('click', function (e) {
      var node = e.target.closest('[data-index]');
      if (!node) return;
      var item = menuItems[Number(node.getAttribute('data-index'))];
      if (!item || item.disabled) return;
      hideMenu();
      if (typeof item.action === 'function') {
        try { item.action(); } catch (err) { toast(err.message, 'err'); }
      }
    });
  }
  document.addEventListener('click', function (e) {
    if (el.ctxMenu && !el.ctxMenu.hidden && !e.target.closest('#ctxMenu')) hideMenu();
  });
  window.addEventListener('resize', hideMenu);
  window.addEventListener('scroll', hideMenu, true);

  /* ------------------------------ 模态框 ------------------------------ */

  function openModal(opts) {
    opts = opts || {};
    return new Promise(function (resolve) {
      modalResolve = resolve;
      el.modalTitle.textContent = opts.title || '';
      el.modalBody.innerHTML = opts.html || '';
      el.modalFoot.innerHTML = '';
      el.modal.style.width = opts.wide ? 'min(560px, 100%)' : 'min(460px, 100%)';
      el.modalMask.hidden = false;
      document.body.style.overflow = 'hidden';

      if (!opts.hideCancel) {
        var cancel = document.createElement('button');
        cancel.className = 'ghost-btn';
        cancel.textContent = opts.cancelText || '取消';
        cancel.addEventListener('click', function () { closeModal(null); });
        el.modalFoot.appendChild(cancel);
      }
      var ok = document.createElement('button');
      ok.className = 'btn-primary' + (opts.danger ? ' modal-danger' : '');
      ok.textContent = opts.okText || '确定';
      ok.addEventListener('click', function () {
        var result;
        try { result = opts.onOk ? opts.onOk() : true; } catch (err) { toast(err.message, 'err'); return; }
        Promise.resolve(result).then(function (val) {
          if (val === false) return;
          closeModal(val === undefined ? true : val);
        }).catch(function (err) { toast(err.message, 'err'); });
      });
      el.modalFoot.appendChild(ok);

      var focusEl = el.modalBody.querySelector('input, textarea');
      if (focusEl) {
        setTimeout(function () {
          focusEl.focus();
          if (focusEl.select) focusEl.select();
        }, 60);
        focusEl.addEventListener('keydown', function (e) {
          if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            ok.click();
          }
        });
      }
    });
  }

  function closeModal(value) {
    el.modalMask.hidden = true;
    document.body.style.overflow = (el.previewMask && !el.previewMask.hidden) ? 'hidden' : '';
    var fn = modalResolve;
    modalResolve = null;
    if (fn) fn(value);
  }

  function confirmDialog(title, message, options) {
    options = options || {};
    return openModal({
      title: title,
      html: '<p>' + esc(message) + '</p>',
      okText: options.okText || '确定',
      danger: !!options.danger,
      onOk: function () { return true; }
    }).then(function (v) { return v === true; });
  }

  function promptDialog(title, options) {
    options = options || {};
    var html = '<div class="modal-field"><span>' + esc(options.label || '名称') + '</span>' +
      '<input type="text" id="modalInput" value="' + esc(options.value || '') + '" placeholder="' + esc(options.placeholder || '') + '"></div>';
    if (options.hint) html += '<p class="modal-hint">' + esc(options.hint) + '</p>';
    return openModal({
      title: title,
      html: html,
      okText: options.okText || '确定',
      onOk: function () {
        var v = ($('#modalInput') || {}).value || '';
        v = v.trim();
        if (!v) { toast('名称不能为空', 'err'); return false; }
        return v;
      }
    });
  }

  if ($('#modalClose')) $('#modalClose').addEventListener('click', function () { closeModal(null); });
  if (el.modalMask) {
    el.modalMask.addEventListener('mousedown', function (e) {
      if (e.target === el.modalMask) closeModal(null);
    });
  }

  /* ------------------------------ 目录选择器 ------------------------------ */

  function pickFolder(startPath, title) {
    var cur = startPath || '';
    var promise = openModal({
      title: title || '选择文件夹',
      html: '<div class="picker"><div class="picker-path" id="pickerPath"></div><div class="picker-list" id="pickerList"></div></div>',
      okText: '选择此文件夹',
      wide: true,
      onOk: function () { return cur; }
    });

    var listEl = $('#pickerList');
    var pathEl = $('#pickerPath');
    if (!listEl) return promise;

    function load(p) {
      cur = p;
      pathEl.textContent = p === '' ? '根目录 /' : '/ ' + p.replace(/\//g, ' / ');
      var seq = ++pickerSeq;
      listEl.innerHTML = '<div class="picker-empty">加载中…</div>';
      api('list', { params: { path: p } }).then(function (res) {
        if (seq !== pickerSeq) return;
        var dirs = (res.items || []).filter(function (i) { return i.type === 'dir'; });
        var html = '';
        if (p !== '') {
          html += '<button class="picker-item" data-picker-up="1"><i class="ri-arrow-go-back-line"></i><span>返回上一级</span></button>';
        }
        html += dirs.map(function (d) {
          return '<button class="picker-item" data-picker-dir="' + esc(d.name) + '"><i class="ri-folder-3-fill pk-folder"></i><span>' + esc(d.name) + '</span><i class="ri-arrow-right-s-line picker-arrow"></i></button>';
        }).join('');
        if (!dirs.length && p === '') html += '<div class="picker-empty">根目录下没有子文件夹</div>';
        listEl.innerHTML = html;
      }).catch(function (err) {
        if (seq !== pickerSeq) return;
        listEl.innerHTML = '<div class="picker-empty">' + esc(err.message) + '</div>';
      });
    }

    listEl.addEventListener('click', function (e) {
      var up = e.target.closest('[data-picker-up]');
      if (up) {
        var parts = cur.split('/').filter(Boolean);
        parts.pop();
        load(parts.join('/'));
        return;
      }
      var dir = e.target.closest('[data-picker-dir]');
      if (dir) {
        var name = dir.getAttribute('data-picker-dir');
        load(cur ? cur + '/' + name : name);
      }
    });

    load(cur);
    return promise;
  }

  /* ------------------------------ 文件操作 ------------------------------ */

  function createFolder() {
    promptDialog('新建文件夹', { label: '文件夹名称', placeholder: '例如：旅行照片', okText: '创建' }).then(function (name) {
      if (!name) return;
      return api('mkdir', { method: 'POST', data: { path: state.path, name: name } })
        .then(function () { toast('文件夹已创建'); reloadCurrent(); })
        .catch(function (err) { toast(err.message, 'err'); });
    });
  }

  function createFile() {
    promptDialog('新建文件', { label: '文件名', value: '未命名.txt', placeholder: '例如：备忘.txt', okText: '创建' }).then(function (name) {
      if (!name) return;
      return api('touch', { method: 'POST', data: { path: state.path, name: name } })
        .then(function () { toast('文件已创建'); reloadCurrent(); })
        .catch(function (err) { toast(err.message, 'err'); });
    });
  }

  function renameItem(item) {
    promptDialog('重命名', { label: '新名称', value: item.name, okText: '保存' }).then(function (name) {
      if (!name || name === item.name) return;
      return api('rename', { method: 'POST', data: { path: item.path, name: name } })
        .then(function () { toast('已重命名'); clearSelection(); reloadCurrent(); })
        .catch(function (err) { toast(err.message, 'err'); });
    });
  }

  function deleteItems(paths) {
    var item = findItem(paths[0]);
    var label = paths.length > 1
      ? ('选中的 ' + paths.length + ' 项')
      : ('「' + (item ? item.name : String(paths[0]).split('/').pop()) + '」');
    confirmDialog('删除确认', '确定要删除 ' + label + ' 吗？此操作不可恢复。', { danger: true, okText: '删除' })
      .then(function (ok) {
        if (!ok) return;
        return api('delete', { method: 'POST', data: { paths: paths } })
          .then(function (res) {
            if (res.failed && res.failed.length) {
              toast(res.failed[0].error || '部分项目删除失败', 'err');
            } else {
              toast('已删除');
            }
            clearSelection();
            reloadCurrent();
          })
          .catch(function (err) { toast(err.message, 'err'); });
      });
  }

  function moveOrCopy(paths, mode) {
    var isMove = mode === 'move';
    pickFolder(state.path, isMove ? '移动所选到…' : '复制所选到…').then(function (dest) {
      if (dest === null) return;
      return api(isMove ? 'move' : 'copy', { method: 'POST', data: { paths: paths, dest: dest } })
        .then(function (res) {
          if (res.failed && res.failed.length) toast(res.failed[0].error || '部分项目操作失败', 'err');
          else toast(isMove ? '已移动' : '已复制');
          clearSelection();
          reloadCurrent();
        })
        .catch(function (err) { toast(err.message, 'err'); });
    });
  }

  function zipItems(paths) {
    var defaultName = paths.length === 1
      ? ((findItem(paths[0]) || {}).name ? String(findItem(paths[0]).name).replace(/\.[^.]+$/, '') : '归档')
      : (state.path ? state.path.split('/').pop() : '归档');
    promptDialog('压缩为 ZIP', { label: '压缩包名称', value: defaultName + '.zip', hint: '压缩包将保存在当前目录', okText: '开始压缩' })
      .then(function (name) {
        if (!name) return;
        return api('zip', { method: 'POST', data: { paths: paths, dest: state.path, name: name } })
          .then(function () { toast('压缩完成'); clearSelection(); reloadCurrent(); })
          .catch(function (err) { toast(err.message, 'err'); });
      });
  }

  function showArchive(item) {
    api('archive_list', { params: { path: item.path } }).then(function (res) {
      var rows = (res.items || []).map(function (it) {
        return '<div class="arc-row' + (it.dir ? ' dir' : '') + '">' +
          '<i class="' + (it.dir ? 'ri-folder-3-fill' : 'ri-file-3-line') + '"></i>' +
          '<span>' + esc(it.name) + '</span>' +
          '<em>' + (it.dir ? '' : esc(fmtSize(it.size))) + '</em></div>';
      }).join('');
      var head = '<div class="arc-head">共 ' + res.total + ' 个条目' + (res.truncated ? '，仅显示前 1000 条' : '') + '</div>';
      openModal({
        title: '压缩包内容',
        html: head + '<div class="arc-list">' + rows + '</div>',
        wide: true,
        hideCancel: true,
        okText: '关闭',
        onOk: function () { return true; }
      });
    }).catch(function (err) { toast(err.message, 'err'); });
  }

  function showDetail(item) {
    api('detail', { params: { path: item.path } }).then(function (d) {
      var rows = [
        ['名称', d.name],
        ['类型', d.type === 'dir' ? '文件夹' : (d.ext ? d.ext.toUpperCase() + ' 文件' : '文件')],
        ['大小', fmtSize(d.size) + (d.type === 'dir' ? '（递归统计）' : '')]
      ];
      if (d.type === 'dir') rows.push(['子项', d.items + ' 项']);
      rows.push(['修改时间', fmtTime(d.mtime)]);
      rows.push(['权限', (d.readable ? '可读' : '不可读') + ' · ' + (d.writable ? '可写' : '不可写')]);
      rows.push(['所在位置', '/' + (d.parent || '')]);
      rows.push(['完整路径', '/' + d.path]);
      var html = '<div class="detail-list">' + rows.map(function (r) {
        return '<div class="detail-row"><span>' + esc(r[0]) + '</span><b>' + esc(r[1]) + '</b></div>';
      }).join('') + '</div>';
      openModal({ title: '属性', html: html, hideCancel: true, okText: '关闭', onOk: function () { return true; } });
    }).catch(function (err) { toast(err.message, 'err'); });
  }

  function fallbackCopy(text) {
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    var ok = false;
    try { ok = document.execCommand('copy'); } catch (e) {}
    ta.remove();
    toast(ok ? '路径已复制' : '复制失败，请手动选择', ok ? 'ok' : 'err');
  }

  function copyToSystem(text) {
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(function () {
        toast('路径已复制');
      }, function () {
        fallbackCopy(text);
      });
    } else {
      fallbackCopy(text);
    }
  }

  function triggerDownload(url, fileName) {
    var a = document.createElement('a');
    a.href = url;
    if (fileName) a.download = fileName;
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { a.remove(); }, 1000);
  }

  function downloadItems(paths) {
    if (paths.length === 1) {
      triggerDownload(downloadUrl(paths[0]));
      return;
    }
    toast('正在打包 ' + paths.length + ' 个项目…');
    fetch('api.php?action=download_zip', {
      method: 'POST',
      headers: { 'X-CSRF-Token': boot.csrf, 'Content-Type': 'application/json' },
      body: JSON.stringify({ paths: paths })
    }).then(function (res) {
      if (!res.ok) {
        return res.text().then(function (t) {
          var msg = '打包下载失败';
          try { var j = JSON.parse(t); if (j && j.error) msg = j.error; } catch (e) {}
          throw new Error(msg);
        });
      }
      return res.blob();
    }).then(function (blob) {
      var url = URL.createObjectURL(blob);
      triggerDownload(url, '樱屿文件_' + Date.now() + '.zip');
      setTimeout(function () { URL.revokeObjectURL(url); }, 20000);
    }).catch(function (err) { toast(err.message, 'err'); });
  }

  /* ------------------------------ 上传 ------------------------------ */

  function ensureDock() {
    if (el.dock) el.dock.hidden = false;
  }

  function dockItem(name) {
    var wrap = document.createElement('div');
    wrap.className = 'dock-item';
    wrap.innerHTML = '<div class="dock-file"><span>' + esc(name) + '</span><em>等待中</em></div><div class="dock-progress"><i></i></div>';
    el.dockBody.appendChild(wrap);
    el.dockBody.scrollTop = el.dockBody.scrollHeight;
    var bar = wrap.querySelector('.dock-progress i');
    var info = wrap.querySelector('em');
    return {
      pct: function (p) {
        bar.style.width = p + '%';
        info.textContent = p + '%';
      },
      done: function () {
        wrap.classList.add('done');
        bar.style.width = '100%';
        info.textContent = '完成';
      },
      err: function (msg) {
        wrap.classList.add('err');
        bar.style.width = '100%';
        info.textContent = '失败';
        wrap.title = msg || '';
      }
    };
  }

  function uploadFiles(files) {
    var list = Array.prototype.slice.call(files).filter(Boolean);
    if (!list.length) return;
    ensureDock();
    var target = state.path;
    var chain = Promise.resolve();
    list.forEach(function (file) {
      chain = chain.then(function () {
        var ui = dockItem(file.name);
        return uploadOne(file, target, ui).catch(function (err) {
          ui.err(err.message);
          toast(file.name + '：' + err.message, 'err');
        });
      });
    });
    chain.then(function () {
      toast('上传任务已完成');
      if (target === state.path) reloadCurrent();
    });
  }

  function uploadOne(file, dirPath, ui) {
    return new Promise(function (resolve, reject) {
      var xhr = new XMLHttpRequest();
      xhr.open('POST', 'api.php?action=upload');
      xhr.setRequestHeader('X-CSRF-Token', boot.csrf);
      ui.pct(1);
      xhr.upload.onprogress = function (e) {
        if (e.lengthComputable) {
          ui.pct(Math.max(1, Math.min(99, Math.round(e.loaded / e.total * 100))));
        }
      };
      xhr.onload = function () {
        var data = null;
        try { data = JSON.parse(xhr.responseText); } catch (e) {}
        if (xhr.status >= 200 && xhr.status < 300 && data && data.ok) {
          if (data.failed && data.failed.length) {
            reject(new Error((data.failed[0] && data.failed[0].error) || '上传失败'));
            return;
          }
          ui.done();
          resolve(data);
        } else {
          reject(new Error((data && data.error) || '上传失败（' + xhr.status + '）'));
        }
      };
      xhr.onerror = function () { reject(new Error('网络中断')); };
      xhr.ontimeout = function () { reject(new Error('请求超时')); };
      var fd = new FormData();
      fd.append('path', dirPath);
      fd.append('files[]', file, file.name);
      xhr.send(fd);
    });
  }

  /* ------------------------------ 预览 ------------------------------ */

  function closePreview() {
    if (!el.previewMask) return;
    el.previewMask.hidden = true;
    el.previewBody.innerHTML = '';
    document.body.style.overflow = '';
    state.preview = null;
    var editBtn = $('#previewEdit');
    if (editBtn) editBtn.remove();
  }

  function openPreview(item) {
    if (!item || item.type === 'dir') return;
    state.preview = { item: item, content: null, editing: false };
    el.previewTitle.textContent = item.name;
    el.previewDownload.href = downloadUrl(item.path);
    el.previewMask.hidden = false;
    document.body.style.overflow = 'hidden';
    var oldEdit = $('#previewEdit');
    if (oldEdit) oldEdit.remove();

    var kind = kindOf(item);
    var url = rawUrl(item.path);

    if (kind === 'image') {
      el.previewBody.innerHTML = '<img src="' + url + '" alt="' + esc(item.name) + '">';
      el.previewBody.querySelector('img').addEventListener('error', function () {
        el.previewBody.innerHTML = '<div class="preview-note">图片加载失败，可能文件已损坏</div>';
      });
    } else if (kind === 'video') {
      el.previewBody.innerHTML = '<video src="' + url + '" controls autoplay playsinline></video>';
    } else if (kind === 'audio') {
      el.previewBody.innerHTML = '<audio src="' + url + '" controls autoplay></audio>';
    } else if (kind === 'pdf') {
      el.previewBody.innerHTML = '<iframe src="' + url + '" title="PDF 预览"></iframe>';
    } else if (isTextFile(item)) {
      loadText(item);
    } else {
      el.previewBody.innerHTML = '<div class="preview-note"><i class="ri-file-3-line" style="font-size:34px;display:block;margin-bottom:12px"></i>这种文件暂时不能预览，可直接下载查看</div>';
    }
  }

  function loadText(item) {
    el.previewBody.innerHTML = '<div class="preview-note"><i class="ri-loader-4-line spin"></i> 正在读取文件…</div>';
    api('read_text', { params: { path: item.path } }).then(function (res) {
      if (!state.preview) return;
      state.preview.content = res.content;
      el.previewBody.innerHTML = '<div class="text-preview"><pre>' + esc(res.content) + '</pre></div>';
      addEditButton();
    }).catch(function (err) {
      el.previewBody.innerHTML = '<div class="preview-note">' + esc(err.message) + '</div>';
    });
  }

  function addEditButton() {
    if (!el.previewTools || $('#previewEdit')) return;
    var btn = document.createElement('button');
    btn.className = 'icon-btn';
    btn.id = 'previewEdit';
    btn.title = '编辑文本';
    btn.innerHTML = '<i class="ri-edit-2-line"></i>';
    btn.addEventListener('click', function () {
      if (!state.preview) return;
      if (state.preview.editing) {
        saveText();
      } else {
        startEditText();
      }
    });
    el.previewTools.insertBefore(btn, el.previewDownload);
  }

  function startEditText() {
    if (!state.preview) return;
    state.preview.editing = true;
    el.previewBody.innerHTML = '<textarea class="editor-textarea" id="editorArea"></textarea>';
    var ta = $('#editorArea');
    ta.value = state.preview.content || '';
    var btn = $('#previewEdit');
    if (btn) {
      btn.innerHTML = '<i class="ri-save-3-line"></i>';
      btn.title = '保存';
    }
    setTimeout(function () { ta.focus(); }, 50);
  }

  function saveText() {
    if (!state.preview) return;
    var ta = $('#editorArea');
    if (!ta) return;
    var content = ta.value;
    api('save_text', { method: 'POST', data: { path: state.preview.item.path, content: content } })
      .then(function () {
        toast('文件已保存');
        state.preview.content = content;
        state.preview.editing = false;
        el.previewBody.innerHTML = '<div class="text-preview"><pre>' + esc(content) + '</pre></div>';
        var btn = $('#previewEdit');
        if (btn) {
          btn.innerHTML = '<i class="ri-edit-2-line"></i>';
          btn.title = '编辑文本';
        }
        reloadCurrent();
      })
      .catch(function (err) { toast(err.message, 'err'); });
  }

  if (el.previewMask) {
    el.previewMask.addEventListener('click', function (e) {
      if (e.target === el.previewMask) closePreview();
    });
  }
  if ($('#previewClose')) $('#previewClose').addEventListener('click', closePreview);

  /* ------------------------------ 日志 ------------------------------ */

  var LOG_ICON = {
    '登录': 'ri-login-box-line',
    '上传': 'ri-upload-cloud-2-line',
    '删除': 'ri-delete-bin-6-line',
    '重命名': 'ri-edit-2-line',
    '复制': 'ri-file-copy-2-line',
    '移动': 'ri-drag-move-2-line',
    '压缩': 'ri-file-zip-line',
    '解压': 'ri-inbox-unarchive-line',
    '新建文件夹': 'ri-folder-add-line',
    '新建文件': 'ri-file-add-line',
    '编辑文件': 'ri-edit-box-line',
    '修改密码': 'ri-shield-keyhole-line',
    '修改设置': 'ri-settings-4-line',
    '新增用户': 'ri-user-add-line',
    '删除用户': 'ri-user-unfollow-line'
  };

  function loadLogs(page) {
    var list = $('#logList');
    var pager = $('#logPager');
    if (!list) return;
    list.innerHTML = '<div class="skeleton-wrap"><div class="skeleton-row"></div><div class="skeleton-row"></div><div class="skeleton-row"></div></div>';
    api('logs', { params: { page: page } }).then(function (res) {
      state.logsPage = res.page;
      state.logsPages = res.pages;
      if (!res.items.length) {
        list.innerHTML = '<div class="empty-state" style="padding:56px 20px"><div class="empty-orb" style="width:74px;height:74px;border-radius:28px;font-size:32px"><i class="ri-history-line"></i></div><h3>还没有任何动态</h3><p>每一次操作都会被温柔记录</p></div>';
        pager.innerHTML = '';
        return;
      }
      list.innerHTML = res.items.map(function (row) {
        var icon = LOG_ICON[row.action] || 'ri-record-circle-line';
        return '<div class="log-item">' +
          '<div class="log-dot"><i class="' + icon + '"></i></div>' +
          '<div class="log-body">' +
          '<div class="log-line"><span class="log-action">' + esc(row.action) + '</span><span class="log-user">· ' + esc(row.username) + '</span><span class="log-time">' + esc(fmtTime(row.created_at)) + '</span></div>' +
          '<div class="log-target">' + esc(row.target || '') + (row.ip ? ' · ' + esc(row.ip) : '') + '</div>' +
          '</div></div>';
      }).join('');
      pager.innerHTML = '<button data-page="' + (res.page - 1) + '"' + (res.page <= 1 ? ' disabled' : '') + '>上一页</button>' +
        '<span>第 ' + res.page + ' / ' + res.pages + ' 页 · 共 ' + res.total + ' 条</span>' +
        '<button data-page="' + (res.page + 1) + '"' + (res.page >= res.pages ? ' disabled' : '') + '>下一页</button>';
    }).catch(function (err) {
      list.innerHTML = '<div class="empty-state" style="padding:56px 20px"><h3>加载失败</h3><p>' + esc(err.message) + '</p></div>';
      pager.innerHTML = '';
    });
  }

  function bindLogEvents() {
    var pager = $('#logPager');
    if (pager) {
      pager.addEventListener('click', function (e) {
        var btn = e.target.closest('[data-page]');
        if (!btn) return;
        var page = Number(btn.getAttribute('data-page'));
        if (page >= 1 && page <= state.logsPages) loadLogs(page);
      });
    }
    var refresh = $('#recentRefresh');
    if (refresh) refresh.addEventListener('click', function () { loadLogs(state.logsPage); });
  }

  /* ------------------------------ 设置 ------------------------------ */

  function loadSettings() {
    if (!$('#settingsView')) return;
    api('settings_get').then(function (res) {
      var nameEl = $('#setSiteName');
      var tagEl = $('#setTagline');
      var rootEl = $('#setRoot');
      if (nameEl) nameEl.value = res.site_name || '';
      if (tagEl) tagEl.value = res.site_tagline || '';
      if (rootEl) rootEl.value = res.root_dir || '';
      loadUsers();
    }).catch(function (err) {
      if (err.message && err.message.indexOf('权限') >= 0) {
        toast('没有权限访问设置', 'err');
        location.hash = '#/files';
      }
    });
  }

  function loadUsers() {
    var box = $('#userList');
    if (!box) return;
    box.innerHTML = '<div class="picker-empty">加载中…</div>';
    api('users_list').then(function (res) {
      var users = res.users || [];
      box.innerHTML = users.map(function (u) {
        var name = u.nickname || u.username;
        var self = boot.user && Number(u.id) === Number(boot.user.id);
        return '<div class="user-row">' +
          '<div class="avatar">' + esc(name.charAt(0).toUpperCase()) + '</div>' +
          '<div class="user-row-info"><b>' + esc(name) + '</b><small>@' + esc(u.username) + ' · ' + (u.last_login ? '最近登录 ' + esc(fmtTime(u.last_login)) : '从未登录') + '</small></div>' +
          '<span class="role-pill">' + (u.role === 'admin' ? '管理员' : '成员') + '</span>' +
          (self ? '' : '<button class="user-del" data-uid="' + u.id + '" data-name="' + esc(u.username) + '" title="删除"><i class="ri-delete-bin-6-line"></i></button>') +
          '</div>';
      }).join('');
    }).catch(function (err) {
      box.innerHTML = '<div class="picker-empty">' + esc(err.message) + '</div>';
    });
  }

  function bindSettings() {
    var saveSite = $('#saveSiteBtn');
    if (saveSite) {
      saveSite.addEventListener('click', function () {
        var payload = {
          site_name: ($('#setSiteName') || {}).value || '',
          site_tagline: ($('#setTagline') || {}).value || '',
          root_dir: ($('#setRoot') || {}).value || ''
        };
        saveSite.disabled = true;
        api('settings_save', { method: 'POST', data: payload }).then(function (res) {
          toast('设置已保存');
          document.title = res.site_name || document.title;
          var brand = $('.brand-text b');
          if (brand) brand.textContent = res.site_name || brand.textContent;
          var pathEl = $('.storage-path span');
          if (pathEl) pathEl.textContent = res.root_dir || pathEl.textContent;
          if (payload.root_dir !== res.root_dir) {
            var rootEl = $('#setRoot');
            if (rootEl) rootEl.value = res.root_dir || '';
          }
          if (!state.searchMode) loadDir(state.path);
        }).catch(function (err) { toast(err.message, 'err'); })
          .then(function () { saveSite.disabled = false; });
      });
    }

    var savePass = $('#savePasswordBtn');
    if (savePass) {
      savePass.addEventListener('click', function () {
        var oldP = ($('#oldPassword') || {}).value || '';
        var newP = ($('#newPassword') || {}).value || '';
        if (!oldP || !newP) { toast('请填写原密码和新密码', 'err'); return; }
        if (newP.length < 6) { toast('新密码至少 6 位', 'err'); return; }
        savePass.disabled = true;
        api('password', { method: 'POST', data: { old: oldP, new: newP } }).then(function () {
          toast('密码已更新');
          if ($('#oldPassword')) $('#oldPassword').value = '';
          if ($('#newPassword')) $('#newPassword').value = '';
        }).catch(function (err) { toast(err.message, 'err'); })
          .then(function () { savePass.disabled = false; });
      });
    }

    var addUser = $('#addUserBtn');
    if (addUser) {
      addUser.addEventListener('click', function () {
        var username = ($('#newUserName') || {}).value || '';
        var password = ($('#newUserPass') || {}).value || '';
        var role = ($('#newUserRole') || {}).value || 'user';
        if (!username.trim() || !password) { toast('请填写账号和密码', 'err'); return; }
        addUser.disabled = true;
        api('user_add', { method: 'POST', data: { username: username.trim(), password: password, role: role } }).then(function () {
          toast('成员已添加');
          if ($('#newUserName')) $('#newUserName').value = '';
          if ($('#newUserPass')) $('#newUserPass').value = '';
          loadUsers();
        }).catch(function (err) { toast(err.message, 'err'); })
          .then(function () { addUser.disabled = false; });
      });
    }

    var userList = $('#userList');
    if (userList) {
      userList.addEventListener('click', function (e) {
        var btn = e.target.closest('[data-uid]');
        if (!btn) return;
        var uid = btn.getAttribute('data-uid');
        var name = btn.getAttribute('data-name') || '该成员';
        confirmDialog('删除成员', '确定要移除成员「' + name + '」吗？', { danger: true, okText: '移除' }).then(function (ok) {
          if (!ok) return;
          api('user_delete', { method: 'POST', data: { id: Number(uid) } })
            .then(function () { toast('成员已移除'); loadUsers(); })
            .catch(function (err) { toast(err.message, 'err'); });
        });
      });
    }
  }

  /* ------------------------------ 主题 / 视图 ------------------------------ */

  function applyTheme(theme) {
    document.documentElement.dataset.theme = theme;
    try { localStorage.setItem('fm-theme', theme); } catch (e) {}
    var btn = $('#themeBtn');
    if (btn) {
      btn.innerHTML = '<i class="' + (theme === 'yoru' ? 'ri-sun-line' : 'ri-moon-clear-line') + '"></i>';
      btn.title = theme === 'yoru' ? '切换到樱雾主题' : '切换到夜樱主题';
    }
    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', theme === 'yoru' ? '#120f1f' : '#f9f1fb');
  }

  function applyView() {
    lsSet('fm-view', state.view);
    var btn = $('#viewBtn');
    if (btn) {
      btn.innerHTML = '<i class="' + (state.view === 'grid' ? 'ri-list-check-2' : 'ri-grid-fill') + '"></i>';
      btn.title = state.view === 'grid' ? '切换为列表' : '切换为网格';
    }
    renderFiles();
  }

  /* ------------------------------ 侧栏 ------------------------------ */

  function openSidebar() {
    el.sidebar.classList.add('open');
    el.scrim.classList.add('active');
  }
  function closeSidebar() {
    el.sidebar.classList.remove('open');
    el.scrim.classList.remove('active');
  }

  /* ------------------------------ 事件绑定 ------------------------------ */

  function bindAppEvents() {
    bindFileEvents();
    bindLogEvents();
    bindSettings();

    $$('.nav-item').forEach(function (a) {
      a.addEventListener('click', function () { closeSidebar(); });
    });

    var menuBtn = $('#menuBtn');
    if (menuBtn) menuBtn.addEventListener('click', openSidebar);
    var sideClose = $('#sideClose');
    if (sideClose) sideClose.addEventListener('click', closeSidebar);
    if (el.scrim) el.scrim.addEventListener('click', closeSidebar);

    var uploadBtn = $('#uploadBtn');
    if (uploadBtn) uploadBtn.addEventListener('click', function () { el.filePicker.click(); });
    $$('[data-quick="upload"]').forEach(function (b) {
      b.addEventListener('click', function () { el.filePicker.click(); });
    });
    $$('[data-quick="mkdir"]').forEach(function (b) {
      b.addEventListener('click', createFolder);
    });

    el.filePicker.addEventListener('change', function () {
      var files = Array.prototype.slice.call(el.filePicker.files || []);
      el.filePicker.value = '';
      if (files.length) uploadFiles(files);
    });

    var newFolder = $('#newFolderBtn');
    if (newFolder) newFolder.addEventListener('click', createFolder);
    var newFile = $('#newFileBtn');
    if (newFile) newFile.addEventListener('click', createFile);
    var pasteBtn = $('#pasteBtn');
    if (pasteBtn) pasteBtn.addEventListener('click', pasteClipboard);
    var hiddenBtn = $('#hiddenBtn');
    if (hiddenBtn) hiddenBtn.addEventListener('click', toggleHidden);
    var selectAllBtn = $('#selectAllBtn');
    if (selectAllBtn) selectAllBtn.addEventListener('click', selectAllVisible);
    var invertBtn = $('#invertBtn');
    if (invertBtn) invertBtn.addEventListener('click', invertSelection);
    var refresh = $('#refreshBtn');
    if (refresh) refresh.addEventListener('click', function () { reloadCurrent(); });

    var container = $('#fileContainer');
    if (container) {
      container.addEventListener('contextmenu', function (e) {
        if (e.target.closest('[data-path]')) return;
        e.preventDefault();
        var hasClip = !!(state.clipboard && state.clipboard.paths && state.clipboard.paths.length);
        showMenu(e.clientX, e.clientY, [
          { label: '新建文件夹', icon: 'ri-folder-add-line', action: createFolder },
          { label: '新建文件', icon: 'ri-file-add-line', action: createFile },
          { label: hasClip ? ('粘贴 ' + state.clipboard.paths.length + ' 项') : '粘贴', icon: 'ri-clipboard-line', disabled: !hasClip, action: pasteClipboard },
          { sep: true },
          { label: '全选', icon: 'ri-checkbox-multiple-line', action: selectAllVisible },
          { label: '刷新', icon: 'ri-refresh-line', action: function () { reloadCurrent(); } }
        ]);
      });
    }

    var viewBtn = $('#viewBtn');
    if (viewBtn) {
      viewBtn.addEventListener('click', function () {
        state.view = state.view === 'grid' ? 'list' : 'grid';
        applyView();
      });
    }

    var themeBtn = $('#themeBtn');
    if (themeBtn) {
      themeBtn.addEventListener('click', function () {
        var current = document.documentElement.dataset.theme === 'yoru' ? 'yoru' : 'sakura';
        applyTheme(current === 'yoru' ? 'sakura' : 'yoru');
      });
    }

    var sortBtn = $('#sortBtn');
    if (sortBtn) {
      sortBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        var r = sortBtn.getBoundingClientRect();
        var opts = [
          { key: 'name', label: '按名称' },
          { key: 'mtime', label: '按修改时间' },
          { key: 'size', label: '按大小' },
          { key: 'type', label: '按类型' }
        ];
        var items = opts.map(function (o) {
          return {
            label: o.label + (state.sort === o.key ? ' ✓' : ''),
            icon: state.sort === o.key ? 'ri-check-line' : 'ri-sort-asc',
            action: function () {
              if (state.sort === o.key) {
                state.order = state.order === 'asc' ? 'desc' : 'asc';
              } else {
                state.sort = o.key;
                state.order = 'asc';
              }
              lsSet('fm-sort', state.sort);
              lsSet('fm-order', state.order);
              updateSortLabel();
              reloadCurrent();
            }
          };
        });
        items.push({ sep: true });
        items.push({
          label: '当前：' + (state.order === 'asc' ? '升序 ↑' : '降序 ↓'),
          icon: 'ri-swap-line',
          action: function () {
            state.order = state.order === 'asc' ? 'desc' : 'asc';
            lsSet('fm-order', state.order);
            updateSortLabel();
            reloadCurrent();
          }
        });
        showMenu(r.left, r.bottom + 8, items);
      });
    }

    var logoutBtn = $('#logoutBtn');
    if (logoutBtn) {
      logoutBtn.addEventListener('click', function () {
        confirmDialog('退出登录', '确定要退出当前账号吗？', { okText: '退出' }).then(function (ok) {
          if (!ok) return;
          api('logout', { method: 'POST', data: {} }).then(function () {
            location.href = 'index.php';
          }).catch(function () { location.href = 'index.php'; });
        });
      });
    }

    var avatarBtn = $('#avatarBtn');
    if (avatarBtn) {
      avatarBtn.addEventListener('click', openProfileModal);
    }
    var userMeta = $('.user-meta');
    if (userMeta) {
      userMeta.style.cursor = 'pointer';
      userMeta.title = '编辑资料';
      userMeta.addEventListener('click', openProfileModal);
    }

    function openProfileModal() {
      var u = boot.user || {};
      var curAvatar = u.avatar || '';
      var pickedFile = null;
      var html = '<div class="profile-edit">' +
        '<div class="profile-avatar">' +
          '<button type="button" class="profile-avatar-btn" id="profileAvatarBtn" title="选择头像">' +
            '<img id="profileAvatarImg"' + (curAvatar ? ' src="' + esc(curAvatar) + '"' : ' hidden') + ' alt="">' +
            '<span id="profileAvatarTip"' + (curAvatar ? ' hidden' : '') + '><i class="ri-camera-line"></i></span>' +
          '</button>' +
          '<small>点击更换头像</small>' +
          '<input type="file" id="profileAvatarInput" accept="image/jpeg,image/png,image/webp,image/gif" hidden>' +
        '</div>' +
        '<div class="modal-field"><span>昵称</span><input id="profileNickname" type="text" maxlength="32" value="' + esc(u.nickname || '') + '" placeholder="显示名称"></div>' +
        '<div class="modal-field"><span>原密码（修改密码时填写）</span><input id="profileOldPass" type="password" autocomplete="current-password" placeholder="不修改密码可留空"></div>' +
        '<div class="modal-field"><span>新密码（留空不修改）</span><input id="profileNewPass" type="password" autocomplete="new-password" placeholder="至少 6 位"></div>' +
        '<p class="modal-hint">头像支持 JPG、PNG、WEBP、GIF，最大 3MB；更换后会覆盖原头像。</p>' +
      '</div>';

      var modalPromise = openModal({
        title: '编辑资料',
        html: html,
        okText: '保存',
        onOk: function () {
          var nickname = (($('#profileNickname') || {}).value || '').trim();
          var oldPass = (($('#profileOldPass') || {}).value || '');
          var newPass = (($('#profileNewPass') || {}).value || '');
          if (newPass && newPass.length < 6) { toast('新密码至少 6 位', 'err'); return false; }
          if (newPass && !oldPass) { toast('请输入原密码', 'err'); return false; }
          var payload;
          if (pickedFile) {
            payload = new FormData();
            payload.append('nickname', nickname);
            payload.append('old_password', oldPass);
            payload.append('new_password', newPass);
            payload.append('avatar', pickedFile);
          } else {
            payload = { nickname: nickname, old_password: oldPass, new_password: newPass };
          }
          return api('profile_save', { method: 'POST', data: payload });
        }
      });

      setTimeout(function () {
        var btn = $('#profileAvatarBtn');
        var input = $('#profileAvatarInput');
        var img = $('#profileAvatarImg');
        var tip = $('#profileAvatarTip');
        if (btn && input) btn.addEventListener('click', function () { input.click(); });
        if (input) input.addEventListener('change', function () {
          var f = input.files && input.files[0];
          if (!f) return;
          if (!/^image\/(jpeg|png|webp|gif)$/.test(f.type)) {
            toast('仅支持 JPG、PNG、WEBP、GIF', 'err');
            input.value = '';
            return;
          }
          if (f.size > 3 * 1024 * 1024) {
            toast('头像不能超过 3MB', 'err');
            input.value = '';
            return;
          }
          pickedFile = f;
          if (img) { img.src = URL.createObjectURL(f); img.hidden = false; }
          if (tip) tip.hidden = true;
        });
      }, 0);

      return modalPromise.then(function (res) {
        if (res && res.user) {
          boot.user = Object.assign({}, boot.user, res.user, { avatar: res.avatar || '' });
        }
        if (res) {
          toast('资料已更新');
          setTimeout(function () { location.reload(); }, 420);
        }
        return true;
      });
    }

    if (el.search) {
      el.search.addEventListener('input', function () {
        state.filter = el.search.value.trim();
        if (!state.searchMode) renderFiles();
      });
      el.search.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          var q = el.search.value.trim();
          if (q) doSearch(q);
          else {
            if (state.searchMode) { state.searchMode = false; state.searchQuery = ''; }
            loadDir(state.path);
          }
        } else if (e.key === 'Escape') {
          el.search.blur();
        }
      });
    }

    var dockClose = $('#dockClose');
    if (dockClose) {
      dockClose.addEventListener('click', function () {
        el.dock.hidden = true;
        el.dockBody.innerHTML = '';
      });
    }

    window.addEventListener('hashchange', route);
    window.addEventListener('keydown', function (e) {
      var tag = (document.activeElement && document.activeElement.tagName) || '';
      var typing = tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT';

      if (e.key === 'Escape') {
        if (!el.ctxMenu.hidden) { hideMenu(); return; }
        if (!el.modalMask.hidden) { closeModal(null); return; }
        if (!el.previewMask.hidden) { closePreview(); return; }
        closeSidebar();
        return;
      }
      if (typing) return;
      if (e.key === '/' && el.search) {
        e.preventDefault();
        el.search.focus();
        return;
      }

      var mod = e.ctrlKey || e.metaKey;
      var filesViewEl = $('#filesView');
      var filesVisible = !!(filesViewEl && !filesViewEl.hidden);
      if (mod && !e.altKey && filesVisible) {
        var k = e.key.toLowerCase();
        if (k === 'a') {
          if (state.items.length) {
            e.preventDefault();
            selectAllVisible();
          }
          return;
        }
        if (k === 'c' && state.selected.size) {
          e.preventDefault();
          setClipboard('copy', selectedPaths());
          return;
        }
        if (k === 'x' && state.selected.size) {
          e.preventDefault();
          setClipboard('cut', selectedPaths());
          return;
        }
        if (k === 'v') {
          e.preventDefault();
          pasteClipboard();
          return;
        }
      }

      if ((e.key === 'Delete' || e.key === 'Backspace') && state.selected.size) {
        e.preventDefault();
        deleteItems(selectedPaths());
        return;
      }
      if (e.key === 'F2' && state.selected.size === 1) {
        var one = findItem(selectedPaths()[0]);
        if (one) {
          e.preventDefault();
          renameItem(one);
        }
      }
    });

    /* 拖拽上传 */
    var dragDepth = 0;
    var hasFiles = function (e) {
      return e.dataTransfer && Array.prototype.indexOf.call(e.dataTransfer.types || [], 'Files') >= 0;
    };
    window.addEventListener('dragenter', function (e) {
      if (!hasFiles(e)) return;
      e.preventDefault();
      dragDepth++;
      el.dropMask.classList.add('active');
    });
    window.addEventListener('dragover', function (e) {
      if (!hasFiles(e)) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = 'copy';
    });
    window.addEventListener('dragleave', function (e) {
      if (!hasFiles(e)) return;
      dragDepth = Math.max(0, dragDepth - 1);
      if (dragDepth === 0) el.dropMask.classList.remove('active');
    });
    window.addEventListener('drop', function (e) {
      if (!hasFiles(e)) return;
      e.preventDefault();
      dragDepth = 0;
      el.dropMask.classList.remove('active');
      var files = Array.prototype.slice.call(e.dataTransfer.files || []);
      if (files.length) {
        if (location.hash.indexOf('#/files') !== 0) location.hash = '#/files';
        uploadFiles(files);
      }
    });
  }

  function updateSortLabel() {
    var map = { name: '名称', mtime: '时间', size: '大小', type: '类型' };
    var label = $('#sortLabel');
    if (label) label.textContent = map[state.sort] || '名称';
    var btn = $('#sortBtn');
    if (btn) btn.innerHTML = '<i class="ri-sort-' + (state.order === 'asc' ? 'asc' : 'desc') + '"></i><span id="sortLabel">' + (map[state.sort] || '名称') + '</span>';
  }

  /* ------------------------------ 启动 ------------------------------ */

  applyTheme(document.documentElement.dataset.theme === 'yoru' ? 'yoru' : 'sakura');
  updateSortLabel();
  updateHiddenBtn();
  updatePasteUI();
  bindAppEvents();
  if (el.fileList) el.fileList.className = 'file-list ' + state.view;
  route();
})();
