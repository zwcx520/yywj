<?php
/**
 * 樱屿文件管理器 · 安装向导
 */
declare(strict_types=1);

require __DIR__ . '/core.php';

$configFile = __DIR__ . '/config.php';
$lockFile = __DIR__ . '/install.lock';

$step = (int)($_GET['step'] ?? 1);
if ($step < 1 || $step > 4) {
    $step = 1;
}

$installed = is_file($lockFile) && is_file($configFile);
if ($installed && $step !== 4) {
    if (fm_db() !== null) {
        header('Location: index.php');
        exit;
    }
    http_response_code(500);
    header('Content-Type: text/html; charset=utf-8');
    echo '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">'
        . '<meta name="viewport" content="width=device-width, initial-scale=1">'
        . '<title>数据库连接失败 · 樱屿文件管理器</title>'
        . '<style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px;'
        . 'font:14px/1.8 system-ui,-apple-system,"Microsoft YaHei",sans-serif;color:#4b3f52;background:#fbf4fb}'
        . '.card{width:min(540px,100%);background:#fff;border-radius:18px;padding:28px;box-shadow:0 24px 60px -30px rgba(120,90,160,.4)}'
        . 'h1{margin:0 0 10px;font-size:19px}p{margin:0 0 10px;color:#7f6f8b;font-size:13px}code{color:#a4659a}'
        . '</style></head><body><div class="card"><h1>🌸 数据库连接失败</h1>'
        . '<p>配置文件 <code>config.php</code> 与 <code>install.lock</code> 已存在，但无法连接数据库。'
        . '请检查数据库服务是否启动、账号密码是否正确。</p>'
        . '<p>如需重新安装，请删除这两个文件后刷新本页。</p>'
        . '</div></body></html>';
    exit;
}

$error = '';
$done = false;
$dbConf = $_SESSION['fm_install_db'] ?? null;

/* ---------------- 环境检测 ---------------- */
$checks = [];
$checks[] = ['PHP 版本 ≥ 8.0', PHP_VERSION_ID >= 80000, PHP_VERSION];
$checks[] = ['PDO MySQL 扩展', extension_loaded('pdo_mysql'), extension_loaded('pdo_mysql') ? '已安装' : '未安装'];
$checks[] = ['mbstring 扩展', extension_loaded('mbstring'), extension_loaded('mbstring') ? '已安装' : '未安装'];
$checks[] = ['ZipArchive（压缩功能）', class_exists('ZipArchive'), class_exists('ZipArchive') ? '已启用' : '未启用（仍可安装）'];
$checks[] = ['程序目录可写', is_writable(__DIR__), is_writable(__DIR__) ? '可写' : '不可写'];
$envOk = true;
foreach ($checks as $c) {
    if (!$c[1] && $c[0] !== 'ZipArchive（压缩功能）') {
        $envOk = false;
    }
}

/* ---------------- 第二步：测试数据库 ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'db') {
    $host = trim((string)($_POST['host'] ?? '127.0.0.1'));
    $port = (int)($_POST['port'] ?? 3306);
    $name = trim((string)($_POST['name'] ?? 'fm_sakura'));
    $user = trim((string)($_POST['user'] ?? 'root'));
    $pass = (string)($_POST['pass'] ?? '');

    if (!preg_match('/^[A-Za-z0-9_\-]+$/', $name)) {
        $error = '数据库名只能包含字母、数字、下划线或短横线';
    } elseif ($host === '' || $user === '') {
        $error = '请填写数据库地址和用户名';
    } else {
        try {
            $pdo = new PDO(
                sprintf('mysql:host=%s;port=%d;charset=utf8mb4', $host, $port),
                $user,
                $pass,
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_TIMEOUT => 5]
            );
            $pdo->exec('CREATE DATABASE IF NOT EXISTS `' . $name . '` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
            $pdo->exec('USE `' . $name . '`');
            $_SESSION['fm_install_db'] = [
                'host' => $host,
                'port' => $port,
                'name' => $name,
                'user' => $user,
                'pass' => $pass,
                'charset' => 'utf8mb4',
            ];
            header('Location: install.php?step=3');
            exit;
        } catch (Throwable $e) {
            $error = '数据库连接失败：' . $e->getMessage();
        }
    }
    $step = 2;
}

/* ---------------- 第三步：管理员与站点 ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'setup') {
    $dbConf = $_SESSION['fm_install_db'] ?? null;
    $adminUser = trim((string)($_POST['admin_user'] ?? ''));
    $adminPass = (string)($_POST['admin_pass'] ?? '');
    $adminPass2 = (string)($_POST['admin_pass2'] ?? '');
    $nickname = trim((string)($_POST['nickname'] ?? ''));
    $siteName = trim((string)($_POST['site_name'] ?? ''));
    $tagline = trim((string)($_POST['tagline'] ?? ''));
    $rootDir = trim((string)($_POST['root_dir'] ?? ''));

    if (!$dbConf) {
        $error = '数据库信息已丢失，请回到第二步重新填写';
        $step = 2;
    } elseif (!preg_match('/^[A-Za-z0-9_\x{4e00}-\x{9fa5}]{2,32}$/u', $adminUser)) {
        $error = '管理员账号需为 2-32 位的中文、字母、数字或下划线';
    } elseif (mb_strlen($adminPass) < 6) {
        $error = '管理员密码至少 6 位';
    } elseif ($adminPass !== $adminPass2) {
        $error = '两次输入的密码不一致';
    } elseif ($siteName === '') {
        $error = '请填写站点名称';
    } else {
        $realRoot = $rootDir === '' ? __DIR__ : $rootDir;
        $real = realpath($realRoot);
        if ($real === false || !is_dir($real)) {
            $error = '文件根目录不存在：' . $realRoot;
        } elseif (!is_writable($real)) {
            $error = '文件根目录不可写：' . $real;
        } elseif (is_file($lockFile)) {
            $error = '系统已安装，如需重装请删除 install.lock';
        } else {
            try {
                $pdo = new PDO(
                    sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $dbConf['host'], (int)$dbConf['port'], $dbConf['name']),
                    $dbConf['user'],
                    $dbConf['pass'],
                    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
                );
                foreach (fm_schema() as $sql) {
                    $pdo->exec($sql);
                }

                $hash = password_hash($adminPass, PASSWORD_DEFAULT);
                $st = $pdo->prepare('SELECT id FROM fm_user WHERE username = ? LIMIT 1');
                $st->execute([$adminUser]);
                if ($st->fetchColumn()) {
                    $pdo->prepare('UPDATE fm_user SET password_hash = ?, nickname = ?, role = ? WHERE username = ?')
                        ->execute([$hash, $nickname !== '' ? $nickname : $adminUser, 'admin', $adminUser]);
                } else {
                    $pdo->prepare('INSERT INTO fm_user (username, password_hash, nickname, role, created_at) VALUES (?, ?, ?, ?, NOW())')
                        ->execute([$adminUser, $hash, $nickname !== '' ? $nickname : $adminUser, 'admin']);
                }

                $settings = [
                    'site_name'    => $siteName,
                    'site_tagline' => $tagline !== '' ? $tagline : '把每一份文件，安放在温柔的地方',
                    'root_dir'     => fm_from_sys($real),
                    'installed_at' => date('Y-m-d H:i:s'),
                    'version'      => FM_VERSION,
                ];
                $st = $pdo->prepare('INSERT INTO fm_setting (skey, svalue) VALUES (?, ?) ON DUPLICATE KEY UPDATE svalue = VALUES(svalue)');
                foreach ($settings as $k => $v) {
                    $st->execute([$k, $v]);
                }

                $content = "<?php\n"
                    . "return [\n"
                    . "    'db' => [\n"
                    . "        'host'    => " . var_export($dbConf['host'], true) . ",\n"
                    . "        'port'    => " . var_export((int)$dbConf['port'], true) . ",\n"
                    . "        'name'    => " . var_export($dbConf['name'], true) . ",\n"
                    . "        'user'    => " . var_export($dbConf['user'], true) . ",\n"
                    . "        'pass'    => " . var_export($dbConf['pass'], true) . ",\n"
                    . "        'charset' => 'utf8mb4',\n"
                    . "    ],\n"
                    . "    'installed_at' => " . var_export($settings['installed_at'], true) . ",\n"
                    . "    'version'      => " . var_export(FM_VERSION, true) . ",\n"
                    . "];\n";
                if (@file_put_contents($configFile, $content, LOCK_EX) === false) {
                    throw new RuntimeException('无法写入 config.php，请检查目录权限');
                }
                @chmod($configFile, 0640);
                if (@file_put_contents($lockFile, date('Y-m-d H:i:s'), LOCK_EX) === false) {
                    throw new RuntimeException('无法写入 install.lock，请检查目录权限');
                }

                unset($_SESSION['fm_install_db']);
                header('Location: install.php?step=4');
                exit;
            } catch (Throwable $e) {
                $error = '安装失败：' . $e->getMessage();
                $step = 3;
            }
        }
    }

    if ($step !== 2) {
        $step = 3;
    }
}

/* ---------------- 第四步 ---------------- */
if ($step === 4) {
    if (!is_file($lockFile)) {
        $step = 1;
    } else {
        $done = true;
    }
}

$defaultRoot = fm_from_sys(__DIR__);
$fileDb = fm_config()['db'] ?? [];
if (!is_array($fileDb)) {
    $fileDb = [];
}
$db = $dbConf ?: ($fileDb + ['host' => '127.0.0.1', 'port' => 3306, 'name' => 'fm_sakura', 'user' => 'root', 'pass' => '']);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>安装 · 樱屿文件管理器</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/remixicon@4.5.0/fonts/remixicon.css">
<style>
*{box-sizing:border-box}
body{margin:0;min-height:100vh;font:14px/1.6 system-ui,-apple-system,"Microsoft YaHei",sans-serif;color:#3d3350;
  background:linear-gradient(135deg,#fdf3fb 0%,#eef4ff 45%,#f7f0ff 100%);display:flex;align-items:center;justify-content:center;padding:24px}
.shell{width:100%;max-width:560px}
.brand{text-align:center;margin-bottom:20px}
.brand h1{margin:0;font-size:22px;font-weight:650;letter-spacing:.02em}
.brand h1 span{color:#d4618f}
.brand p{margin:6px 0 0;color:#8b7f9e;font-size:12.5px}
.panel{background:rgba(255,255,255,.82);border:1px solid rgba(255,255,255,.9);box-shadow:0 18px 48px -20px rgba(80,60,140,.35);
  border-radius:18px;padding:26px 26px 24px;backdrop-filter:blur(18px)}
.steps{display:flex;gap:8px;margin-bottom:22px}
.steps i{flex:1;height:3px;border-radius:2px;background:#e6e1ef}
.steps i.on{background:linear-gradient(90deg,#e88ab5,#8fa8ff)}
h2{margin:0 0 4px;font-size:16.5px;font-weight:650}
.hint{margin:0 0 18px;color:#8b7f9e;font-size:12.5px}
.check{display:flex;align-items:center;gap:10px;padding:9px 12px;border-radius:10px;background:#faf8fe;margin-bottom:8px;font-size:13px}
.check em{margin-left:auto;font-style:normal;color:#8b7f9e}
.check.ok i{color:#3aa675}
.check.bad i{color:#cf5a6d}
.field{margin-bottom:13px}
.field label{display:block;font-size:12.5px;color:#6f6486;margin-bottom:5px}
.field input{width:100%;height:40px;border-radius:10px;border:1px solid #e4dff0;background:#fdfcff;padding:0 12px;font:inherit;color:inherit;outline:none}
.field input:focus{border-color:#c3a6e8;box-shadow:0 0 0 3px rgba(180,150,240,.14)}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.actions{display:flex;gap:10px;align-items:center;margin-top:20px}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;height:41px;padding:0 20px;border-radius:11px;border:0;
  cursor:pointer;font:inherit;font-weight:600;color:#fff;background:linear-gradient(135deg,#ec8bb6,#a58bf3);text-decoration:none}
.btn:hover{filter:brightness(1.04)}
.btn[disabled]{opacity:.5;cursor:not-allowed}
.btn.ghost{background:#f4f0fb;color:#6f6486}
.err{background:#fdeef1;color:#b3405a;border-radius:10px;padding:10px 12px;font-size:12.5px;margin-bottom:14px}
.ok-box{text-align:center;padding:8px 0 4px}
.ok-box .big{font-size:42px;line-height:1}
.ok-box h2{margin:12px 0 6px}
.ok-box p{color:#8b7f9e;font-size:13px;margin:0 0 20px}
.foot{text-align:center;color:#a79cba;font-size:11.5px;margin-top:16px}
@media(max-width:480px){.panel{padding:20px 16px 18px;border-radius:14px}.grid2{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="shell">
  <div class="brand">
    <h1>🌸 <span>樱屿</span> 文件管理器</h1>
    <p>SAKURA ISLE · 安装向导</p>
  </div>
  <div class="panel">
    <div class="steps">
      <?php for ($i = 1; $i <= 4; $i++): ?><i class="<?= $i <= $step ? 'on' : '' ?>"></i><?php endfor; ?>
    </div>

    <?php if ($error !== ''): ?>
      <div class="err"><i class="ri-error-warning-line"></i> <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
    <?php endif; ?>

    <?php if ($done): ?>
      <div class="ok-box">
        <div class="big">🌸</div>
        <h2>安装完成</h2>
        <p>现在可以登录并开始管理文件了。</p>
        <a class="btn" href="index.php"><i class="ri-arrow-right-line"></i> 进入登录页</a>
      </div>

    <?php elseif ($step === 1): ?>
      <h2>环境检测</h2>
      <p class="hint">确认服务器满足运行条件后继续。</p>
      <?php foreach ($checks as $c): ?>
        <div class="check <?= $c[1] ? 'ok' : 'bad' ?>">
          <i class="<?= $c[1] ? 'ri-checkbox-circle-fill' : 'ri-close-circle-fill' ?>"></i>
          <span><?= htmlspecialchars($c[0], ENT_QUOTES, 'UTF-8') ?></span>
          <em><?= htmlspecialchars($c[2], ENT_QUOTES, 'UTF-8') ?></em>
        </div>
      <?php endforeach; ?>
      <div class="actions">
        <?php if ($envOk): ?>
          <a class="btn" href="install.php?step=2"><i class="ri-arrow-right-line"></i> 下一步</a>
        <?php else: ?>
          <button class="btn" disabled>请先修复环境</button>
        <?php endif; ?>
      </div>

    <?php elseif ($step === 2): ?>
      <h2>连接数据库</h2>
      <p class="hint">填写 MySQL 信息，数据库不存在时会自动创建。</p>
      <form method="post" action="install.php?step=2">
        <input type="hidden" name="do" value="db">
        <div class="grid2">
          <div class="field">
            <label>数据库地址</label>
            <input name="host" value="<?= htmlspecialchars((string)$db['host'], ENT_QUOTES, 'UTF-8') ?>" placeholder="127.0.0.1" required>
          </div>
          <div class="field">
            <label>端口</label>
            <input name="port" type="number" value="<?= (int)$db['port'] ?>" placeholder="3306" required>
          </div>
        </div>
        <div class="field">
          <label>数据库名</label>
          <input name="name" value="<?= htmlspecialchars((string)$db['name'], ENT_QUOTES, 'UTF-8') ?>" placeholder="fm_sakura" required>
        </div>
        <div class="grid2">
          <div class="field">
            <label>用户名</label>
            <input name="user" value="<?= htmlspecialchars((string)$db['user'], ENT_QUOTES, 'UTF-8') ?>" placeholder="root" required>
          </div>
          <div class="field">
            <label>密码</label>
            <input name="pass" type="password" value="<?= htmlspecialchars((string)$db['pass'], ENT_QUOTES, 'UTF-8') ?>" placeholder="数据库密码">
          </div>
        </div>
        <div class="actions">
          <button class="btn" type="submit"><i class="ri-plug-line"></i> 测试并继续</button>
          <a class="btn ghost" href="install.php?step=1">返回</a>
        </div>
      </form>

    <?php elseif ($step === 3): ?>
      <h2>站点与管理员</h2>
      <p class="hint">安装后使用该管理员账号登录。</p>
      <form method="post" action="install.php?step=3">
        <input type="hidden" name="do" value="setup">
        <div class="grid2">
          <div class="field">
            <label>管理员账号</label>
            <input name="admin_user" value="<?= htmlspecialchars((string)($_POST['admin_user'] ?? 'admin'), ENT_QUOTES, 'UTF-8') ?>" required>
          </div>
          <div class="field">
            <label>昵称</label>
            <input name="nickname" value="<?= htmlspecialchars((string)($_POST['nickname'] ?? '管理员'), ENT_QUOTES, 'UTF-8') ?>">
          </div>
        </div>
        <div class="grid2">
          <div class="field">
            <label>管理员密码</label>
            <input name="admin_pass" type="password" minlength="6" required>
          </div>
          <div class="field">
            <label>确认密码</label>
            <input name="admin_pass2" type="password" minlength="6" required>
          </div>
        </div>
        <div class="grid2">
          <div class="field">
            <label>站点名称</label>
            <input name="site_name" value="<?= htmlspecialchars((string)($_POST['site_name'] ?? '樱屿文件管理器'), ENT_QUOTES, 'UTF-8') ?>" required>
          </div>
          <div class="field">
            <label>站点标语</label>
            <input name="tagline" value="<?= htmlspecialchars((string)($_POST['tagline'] ?? '把每一份文件，安放在温柔的地方'), ENT_QUOTES, 'UTF-8') ?>">
          </div>
        </div>
        <div class="field">
          <label>文件根目录（可留空使用程序所在目录）</label>
          <input name="root_dir" value="<?= htmlspecialchars((string)($_POST['root_dir'] ?? $defaultRoot), ENT_QUOTES, 'UTF-8') ?>">
        </div>
        <div class="actions">
          <button class="btn" type="submit"><i class="ri-check-line"></i> 开始安装</button>
          <a class="btn ghost" href="install.php?step=2">返回</a>
        </div>
      </form>

    <?php else: ?>
      <h2>准备安装</h2>
      <p class="hint">请按步骤完成安装。</p>
      <div class="actions"><a class="btn" href="install.php?step=1">开始</a></div>
    <?php endif; ?>
  </div>
  <div class="foot">SAKURA ISLE · v<?= FM_VERSION ?></div>
</div>
</body>
</html>
