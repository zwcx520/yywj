<?php
/**
 * 樱屿 · 核心引导文件
 * 运行环境：PHP 8.0+ / MySQL 5.7+ / 无任何框架依赖
 */
declare(strict_types=1);

define('FM_ROOT', __DIR__);
define('FM_VERSION', '1.0.0');

error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
date_default_timezone_set('Asia/Shanghai');

if (session_status() !== PHP_SESSION_ACTIVE) {
    $https = (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    session_name('FM_SID');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure'   => $https,
    ]);
    session_start();
}

/* ------------------------------------------------------------------ *
 *  基础工具
 * ------------------------------------------------------------------ */

/**
 * 系统是否已安装（config.php + install.lock + 数据库可连接）
 */
function fm_is_installed(): bool
{
    static $ready = null;
    if ($ready !== null) {
        return $ready;
    }
    if (!is_file(FM_ROOT . '/config.php') || !is_file(FM_ROOT . '/install.lock')) {
        return $ready = false;
    }
    return $ready = fm_db() !== null;
}

/* ------------------------------------------------------------------ *
 *  MySQL 数据层
 * ------------------------------------------------------------------ */

function fm_config(): array
{
    static $cfg = null;
    if ($cfg !== null) {
        return $cfg;
    }
    $file = FM_ROOT . '/config.php';
    if (!is_file($file)) {
        return $cfg = [];
    }
    $data = require $file;
    return $cfg = is_array($data) ? $data : [];
}

function fm_db(): ?PDO
{
    static $pdo = null;
    static $tried = false;
    if ($pdo instanceof PDO) {
        return $pdo;
    }
    if ($tried) {
        return null;
    }
    $tried = true;

    $cfg = fm_config();
    $d = $cfg['db'] ?? [];
    $name = (string)($d['name'] ?? '');
    if ($name === '') {
        return null;
    }
    $dsn = sprintf(
        'mysql:host=%s;port=%d;dbname=%s;charset=%s',
        (string)($d['host'] ?? '127.0.0.1'),
        (int)($d['port'] ?? 3306),
        $name,
        (string)($d['charset'] ?? 'utf8mb4')
    );
    try {
        $pdo = new PDO($dsn, (string)($d['user'] ?? ''), (string)($d['pass'] ?? ''), [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::ATTR_TIMEOUT            => 5,
        ]);
    } catch (Throwable $e) {
        return null;
    }
    fm_ensure_user_columns($pdo);
    return $pdo;
}

/**
 * 兼容旧库：没有 avatar 列时自动补上
 */
function fm_ensure_user_columns(PDO $pdo): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    try {
        $pdo->query('SELECT avatar FROM fm_user LIMIT 1');
    } catch (Throwable $e) {
        try {
            $pdo->exec("ALTER TABLE fm_user ADD COLUMN avatar VARCHAR(255) NOT NULL DEFAULT ''");
        } catch (Throwable $e2) {
            // 忽略
        }
    }
}

function fm_schema(): array
{
    $opt = 'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
    return [
        "CREATE TABLE IF NOT EXISTS `fm_user` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `username` VARCHAR(64) NOT NULL,
            `password_hash` VARCHAR(255) NOT NULL,
            `nickname` VARCHAR(64) NOT NULL DEFAULT '',
            `role` VARCHAR(16) NOT NULL DEFAULT 'user',
            `avatar` VARCHAR(255) NOT NULL DEFAULT '',
            `created_at` DATETIME NOT NULL,
            `last_login` DATETIME NULL,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uk_username` (`username`)
        ) $opt",
        "CREATE TABLE IF NOT EXISTS `fm_setting` (
            `skey` VARCHAR(64) NOT NULL,
            `svalue` MEDIUMTEXT NULL,
            PRIMARY KEY (`skey`)
        ) $opt",
        "CREATE TABLE IF NOT EXISTS `fm_log` (
            `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            `user_id` INT UNSIGNED NULL,
            `username` VARCHAR(64) NOT NULL DEFAULT '',
            `action` VARCHAR(32) NOT NULL DEFAULT '',
            `target` VARCHAR(1000) NOT NULL DEFAULT '',
            `ip` VARCHAR(64) NOT NULL DEFAULT '',
            `created_at` DATETIME NOT NULL,
            PRIMARY KEY (`id`),
            KEY `idx_created` (`created_at`)
        ) $opt",
    ];
}

/* ------------------------------------------------------------------ *
 *  本地文件工具（安装辅助）
 * ------------------------------------------------------------------ */

function fm_data_dir(): string
{
    static $dir = null;
    if ($dir !== null) {
        return $dir;
    }
    $dir = FM_ROOT . '/storage/data';
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
    return $dir;
}

function fm_json_load(string $file, array $default = []): array
{
    if (!is_file($file)) {
        return $default;
    }
    $raw = @file_get_contents($file);
    if ($raw === false || $raw === '') {
        return $default;
    }
    $data = json_decode($raw, true);
    return is_array($data) ? $data : $default;
}

function fm_json_save(string $file, array $data): bool
{
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE | JSON_PRETTY_PRINT);
    if (!is_string($json)) {
        return false;
    }
    $tmp = $file . '.tmp';
    if (@file_put_contents($tmp, $json, LOCK_EX) === false) {
        return false;
    }
    if (!@rename($tmp, $file)) {
        if (@file_put_contents($file, $json, LOCK_EX) === false) {
            @unlink($tmp);
            return false;
        }
        @unlink($tmp);
    }
    @chmod($file, 0640);
    return true;
}

function fm_users_path(): string
{
    return fm_data_dir() . '/users.json';
}

function fm_users_all(): array
{
    $data = fm_json_load(fm_users_path(), ['seq' => 0, 'users' => []]);
    if (!isset($data['users']) || !is_array($data['users'])) {
        $data['users'] = [];
    }
    if (!isset($data['seq'])) {
        $data['seq'] = 0;
    }
    return $data;
}

function fm_users_save(array $data): bool
{
    return fm_json_save(fm_users_path(), $data);
}

function fm_find_user(string $username): ?array
{
    foreach (fm_users_all()['users'] as $u) {
        if ((string)($u['username'] ?? '') === $username) {
            return $u;
        }
    }
    return null;
}

function fm_find_user_by_id(int $id): ?array
{
    foreach (fm_users_all()['users'] as $u) {
        if ((int)($u['id'] ?? 0) === $id) {
            return $u;
        }
    }
    return null;
}

function fm_user_create(array $fields): ?array
{
    $data = fm_users_all();
    $data['seq'] = (int)$data['seq'] + 1;
    $user = array_merge([
        'id'         => $data['seq'],
        'avatar'     => '',
        'created_at' => date('Y-m-d H:i:s'),
        'last_login' => null,
    ], $fields);
    $data['users'][] = $user;
    return fm_users_save($data) ? $user : null;
}

function fm_user_update(int $id, array $patch): bool
{
    $data = fm_users_all();
    $found = false;
    foreach ($data['users'] as $i => $u) {
        if ((int)($u['id'] ?? 0) === $id) {
            $data['users'][$i] = array_merge($u, $patch);
            $found = true;
            break;
        }
    }
    return $found && fm_users_save($data);
}

function fm_user_delete(int $id): bool
{
    $data = fm_users_all();
    $before = count($data['users']);
    $data['users'] = array_values(array_filter($data['users'], function (array $u) use ($id): bool {
        return (int)($u['id'] ?? 0) !== $id;
    }));
    if (count($data['users']) === $before) {
        return false;
    }
    return fm_users_save($data);
}

function fm_settings_file(): string
{
    return fm_data_dir() . '/settings.json';
}

function fm_logs_file(): string
{
    return fm_data_dir() . '/logs.jsonl';
}

/**
 * 数据库连接可用即视为已就绪（建表与初始数据由安装向导完成）
 */
function fm_bootstrap(): bool
{
    return fm_db() !== null;
}

/**
 * 默认管理员密码是否仍为 admin123（用于在登录页提示）
 */
function fm_default_admin_exists(): bool
{
    $db = fm_db();
    if (!$db) {
        return false;
    }
    try {
        $st = $db->prepare('SELECT password_hash FROM fm_user WHERE username = ? LIMIT 1');
        $st->execute(['admin']);
        $hash = (string)($st->fetchColumn() ?: '');
        return $hash !== '' && password_verify('admin123', $hash);
    } catch (Throwable $e) {
        return false;
    }
}

/**
 * 读取全部操作日志（旧 → 新）
 */
function fm_logs_read(): array
{
    $file = fm_logs_file();
    if (!is_file($file)) {
        return [];
    }
    $rows = [];
    $fp = @fopen($file, 'rb');
    if ($fp === false) {
        return [];
    }
    $id = 0;
    while (($line = fgets($fp)) !== false) {
        $row = json_decode($line, true);
        if (!is_array($row)) {
            continue;
        }
        $id++;
        $row['id'] = $id;
        $rows[] = $row;
    }
    fclose($fp);
    return $rows;
}

function fm_json(array $payload, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: no-store');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function fm_ok(array $data = []): void
{
    fm_json(array_merge(['ok' => true], $data));
}

function fm_fail(string $message, int $status = 400): void
{
    fm_json(['ok' => false, 'error' => $message], $status);
}

function fm_post(string $key, string $default = ''): string
{
    $v = $_POST[$key] ?? $default;
    return is_string($v) ? $v : $default;
}

function fm_input(): array
{
    $raw = file_get_contents('php://input');
    $json = json_decode((string)$raw, true);
    if (is_array($json)) {
        return $json;
    }
    return $_POST;
}

function fm_csrf(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(24));
    }
    return (string)$_SESSION['csrf'];
}

function fm_verify_csrf(): void
{
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($_POST['_csrf'] ?? '');
    if (!is_string($token) || !hash_equals((string)($_SESSION['csrf'] ?? ''), $token)) {
        fm_fail('页面会话已过期，请刷新后重试', 419);
    }
}

function fm_user(): ?array
{
    static $user = null;
    static $loaded = false;
    if ($loaded) {
        return $user;
    }
    $loaded = true;

    $uid = (int)($_SESSION['uid'] ?? 0);
    if ($uid <= 0) {
        return null;
    }
    $db = fm_db();
    if (!$db) {
        return null;
    }
    try {
        $st = $db->prepare('SELECT id, username, nickname, role, avatar FROM fm_user WHERE id = ? LIMIT 1');
        $st->execute([$uid]);
        $row = $st->fetch();
    } catch (Throwable $e) {
        return null;
    }
    if (!$row) {
        unset($_SESSION['uid']);
        return null;
    }
    return $user = $row;
}

function fm_require_login(): array
{
    $u = fm_user();
    if (!$u) {
        fm_fail('登录状态已失效，请重新登录', 401);
    }
    return $u;
}

function fm_require_admin(): array
{
    $u = fm_require_login();
    if (($u['role'] ?? '') !== 'admin') {
        fm_fail('没有权限执行该操作', 403);
    }
    return $u;
}

function fm_log(string $action, string $target = ''): void
{
    $db = fm_db();
    if (!$db) {
        return;
    }
    $u = fm_user();
    try {
        $st = $db->prepare('INSERT INTO fm_log (user_id, username, action, target, ip, created_at) VALUES (?, ?, ?, ?, ?, NOW())');
        $st->execute([
            $u['id'] ?? null,
            mb_substr((string)($u['username'] ?? '-'), 0, 64),
            mb_substr($action, 0, 32),
            mb_substr($target, 0, 1000),
            mb_substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 64),
        ]);
    } catch (Throwable $e) {
        // 忽略日志写入失败
    }
}

function fm_hsize(int $bytes): string
{
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = 0;
    $n = (float)$bytes;
    while ($n >= 1024 && $i < count($units) - 1) {
        $n /= 1024;
        $i++;
    }
    return ($i === 0 ? (string)(int)$n : number_format($n, $n < 10 ? 1 : 0)) . ' ' . $units[$i];
}

function fm_bool($v): bool
{
    return in_array($v, [true, 1, '1', 'true', 'on', 'yes'], true);
}

/* ------------------------------------------------------------------ *
 *  设置项
 * ------------------------------------------------------------------ */

function fm_settings_all(): array
{
    $cache = $GLOBALS['FM_SETTINGS_CACHE'] ?? null;
    if (is_array($cache)) {
        return $cache;
    }
    $cache = [];
    $db = fm_db();
    if ($db) {
        try {
            foreach ($db->query('SELECT skey, svalue FROM fm_setting') as $row) {
                $cache[(string)$row['skey']] = (string)$row['svalue'];
            }
        } catch (Throwable $e) {
            $cache = [];
        }
    }
    $GLOBALS['FM_SETTINGS_CACHE'] = $cache;
    return $cache;
}

function fm_setting(string $key, string $default = ''): string
{
    $all = fm_settings_all();
    return isset($all[$key]) ? (string)$all[$key] : $default;
}

function fm_set(string $key, string $value): void
{
    $db = fm_db();
    if (!$db) {
        return;
    }
    $st = $db->prepare('INSERT INTO fm_setting (skey, svalue) VALUES (?, ?) ON DUPLICATE KEY UPDATE svalue = VALUES(svalue)');
    $st->execute([$key, $value]);
    $all = fm_settings_all();
    $all[$key] = $value;
    $GLOBALS['FM_SETTINGS_CACHE'] = $all;
}

/* ------------------------------------------------------------------ *
 *  文件系统 · 编码与安全路径
 * ------------------------------------------------------------------ */

/**
 * 探测当前系统文件系统是否为 UTF-8 命名（Windows 中文系统为 GBK）。
 * 使用 ANSI 代码页判断，65001 表示 UTF-8。
 */
function fm_fs_utf8(): bool
{
    static $result = null;
    if ($result !== null) {
        return $result;
    }
    if (DIRECTORY_SEPARATOR !== '\\') {
        return $result = true;
    }
    if (function_exists('sapi_windows_cp_get')) {
        return $result = ((int)sapi_windows_cp_get('ansi') === 65001);
    }
    return $result = true;
}

function fm_to_sys(string $utf8): string
{
    if (fm_fs_utf8() || !function_exists('iconv')) {
        return $utf8;
    }
    $r = @iconv('UTF-8', 'GB18030', $utf8);
    return $r !== false ? $r : $utf8;
}

function fm_from_sys(string $sys): string
{
    if ($sys === '' || preg_match('//u', $sys) === 1) {
        return $sys;
    }
    if (function_exists('iconv')) {
        $r = @iconv('GB18030', 'UTF-8', $sys);
        if ($r !== false) {
            return $r;
        }
    }
    return mb_convert_encoding($sys, 'UTF-8', 'GB18030');
}

function fm_normalize_rel(string $rel): string
{
    $rel = str_replace('\\', '/', $rel);
    $rel = trim($rel, '/');
    if ($rel === '') {
        return '';
    }
    $out = [];
    foreach (explode('/', $rel) as $seg) {
        if ($seg === '' || $seg === '.') {
            continue;
        }
        if ($seg === '..') {
            throw new RuntimeException('非法的路径');
        }
        if (strpos($seg, "\0") !== false) {
            throw new RuntimeException('非法的路径');
        }
        $out[] = $seg;
    }
    return implode('/', $out);
}

/**
 * 站点的全局文件根目录（不含用户隔离）
 */
function fm_base_root(): string
{
    static $base = null;
    if ($base !== null) {
        return $base;
    }
    $configured = fm_setting('root_dir', '');
    if ($configured === '') {
        $configured = FM_ROOT;
    } else {
        // 设置中统一存 UTF-8，文件系统操作需要系统编码
        $configured = fm_to_sys($configured);
    }
    if (!is_dir($configured)) {
        @mkdir($configured, 0775, true);
    }
    $real = realpath($configured);
    if ($real === false) {
        $real = rtrim(str_replace('\\', '/', $configured), '/');
    }
    return $base = $real;
}

/**
 * 系统自身文件与目录（在根目录列表中隐藏，避免误删与暴露源码）
 */
function fm_system_entries(): array
{
    return ['index.php', 'api.php', 'core.php', 'config.php', 'install.php', 'install.lock',
        '.htaccess', '.user.ini', 'composer.json', 'assets', 'storage', 'admin', 'users'];
}

function fm_is_system_entry(string $name, string $parentRel = ''): bool
{
    if ($parentRel !== '') {
        return false;
    }
    // 仅当浏览的是站点全局根目录（管理员）时隐藏，普通用户的个人目录不隐藏
    $root = rtrim(str_replace('\\', '/', fm_root_dir()), '/');
    $base = rtrim(str_replace('\\', '/', fm_base_root()), '/');
    if (strcasecmp($root, $base) !== 0) {
        return false;
    }
    return in_array(strtolower($name), fm_system_entries(), true);
}

/**
 * 由账号得到安全的文件夹名
 */
function fm_user_dir_name(string $username): string
{
    $safe = (string)preg_replace('/[^\w\x{4e00}-\x{9fa5}\-]+/u', '_', $username);
    $safe = trim($safe, '_');
    if ($safe === '') {
        $safe = 'user_' . substr(md5($username), 0, 8);
    }
    // 避免与程序目录同名，防止误删程序文件
    $reserved = ['assets', 'storage', 'admin', 'users', 'api', 'index', 'core', 'config', 'install'];
    if (in_array(strtolower($safe), $reserved, true)) {
        $safe = 'u_' . $safe;
    }
    return $safe;
}

/**
 * 当前用户的文件根目录（绝对路径，系统编码）
 * 普通用户：<全局根>/<账号>；管理员：<全局根>
 */
function fm_root_dir(): string
{
    static $root = null;
    if ($root !== null) {
        return $root;
    }
    $base = fm_base_root();
    $u = fm_user();
    if ($u && ($u['role'] ?? '') !== 'admin') {
        $dir = fm_user_dir((string)$u['username']);
        if (!is_dir($dir)) {
            @mkdir($dir, 0775, true);
        }
        return $root = $dir;
    }
    return $root = $base;
}

function fm_within_root(string $path): bool
{
    $root = fm_root_dir();
    $rootNorm = rtrim(str_replace('\\', '/', $root), '/');
    $pathNorm = rtrim(str_replace('\\', '/', $path), '/');
    return $pathNorm === $rootNorm || str_starts_with($pathNorm . '/', $rootNorm . '/');
}

/**
 * 把相对路径解析为系统绝对路径。
 * $mustExist=true 时校验真实路径；否则校验其父目录。
 */
function fm_abs(string $rel, bool $mustExist = true): string
{
    $rel = fm_normalize_rel($rel);
    $root = fm_root_dir();
    $sysRel = $rel === '' ? '' : str_replace('/', DIRECTORY_SEPARATOR, fm_to_sys($rel));
    $abs = $rel === '' ? $root : rtrim($root, '/\\') . DIRECTORY_SEPARATOR . $sysRel;

    if ($mustExist) {
        $real = realpath($abs);
        if ($real === false) {
            throw new RuntimeException('文件或目录不存在');
        }
        if (!fm_within_root($real)) {
            throw new RuntimeException('访问越界，已拦截');
        }
        return $real;
    }

    $parent = dirname($abs);
    $realParent = realpath($parent);
    if ($realParent === false) {
        throw new RuntimeException('目标目录不存在');
    }
    if (!fm_within_root($realParent)) {
        throw new RuntimeException('访问越界，已拦截');
    }
    return $realParent . DIRECTORY_SEPARATOR . basename($abs);
}

function fm_safe_name(string $name): string
{
    $name = trim($name);
    $name = str_replace(['/', '\\', "\0"], '', $name);
    $name = preg_replace('/[\x00-\x1F\x7F]/u', '', $name) ?? $name;
    if (DIRECTORY_SEPARATOR === '\\') {
        $name = str_replace(['<', '>', ':', '"', '|', '?', '*'], '_', $name);
        $name = rtrim($name, '. ');
    }
    if ($name === '' || $name === '.' || $name === '..') {
        throw new RuntimeException('名称不能为空或含有非法字符');
    }
    if (mb_strlen($name) > 120) {
        throw new RuntimeException('名称过长');
    }
    return $name;
}

function fm_join_rel(string $dir, string $name): string
{
    $dir = fm_normalize_rel($dir);
    return $dir === '' ? $name : $dir . '/' . $name;
}

function fm_unique_path(string $dirAbs, string $name): string
{
    $path = $dirAbs . DIRECTORY_SEPARATOR . $name;
    if (!file_exists($path)) {
        return $path;
    }
    $info = pathinfo($name);
    $base = $info['filename'] ?? $name;
    $ext = isset($info['extension']) ? '.' . $info['extension'] : '';
    for ($i = 1; $i < 1000; $i++) {
        $candidate = $dirAbs . DIRECTORY_SEPARATOR . $base . ' (' . $i . ')' . $ext;
        if (!file_exists($candidate)) {
            return $candidate;
        }
    }
    return $dirAbs . DIRECTORY_SEPARATOR . $base . '_' . bin2hex(random_bytes(4)) . $ext;
}

function fm_rmdir_recursive(string $dir): bool
{
    if (!is_dir($dir) || is_link($dir)) {
        return @unlink($dir);
    }
    $items = @scandir($dir);
    if ($items === false) {
        return false;
    }
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }
        $p = $dir . DIRECTORY_SEPARATOR . $item;
        if (is_dir($p) && !is_link($p)) {
            fm_rmdir_recursive($p);
        } else {
            @unlink($p);
        }
    }
    return @rmdir($dir);
}

/* ------------------------------------------------------------------ *
 *  头像与用户个人目录
 * ------------------------------------------------------------------ */

function fm_avatar_exts(): array
{
    return ['jpg', 'jpeg', 'png', 'webp', 'gif'];
}

function fm_avatar_dir(): string
{
    $dir = FM_ROOT . '/storage/avatars';
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
    return $dir;
}

/**
 * 按账号查找头像文件（统一存放在 storage/avatars，文件名为账号）
 */
function fm_avatar_path_for(string $username): ?string
{
    if ($username === '') {
        return null;
    }
    $slug = fm_to_sys(fm_user_dir_name($username));
    foreach (fm_avatar_exts() as $ext) {
        $p = fm_avatar_dir() . '/' . $slug . '.' . $ext;
        if (is_file($p)) {
            return $p;
        }
    }
    return null;
}

function fm_avatar_path(int $uid): ?string
{
    if ($uid <= 0) {
        return null;
    }
    $db = fm_db();
    if (!$db) {
        return null;
    }
    try {
        $st = $db->prepare('SELECT username FROM fm_user WHERE id = ? LIMIT 1');
        $st->execute([$uid]);
        $uname = (string)($st->fetchColumn() ?: '');
    } catch (Throwable $e) {
        return null;
    }
    return fm_avatar_path_for($uname);
}

/**
 * 按账号直接生成头像地址（不查询数据库，适合列表批量渲染）
 */
function fm_avatar_url_for(string $username, string $prefix = 'api.php'): string
{
    if ($username === '') {
        return '';
    }
    $p = fm_avatar_path_for($username);
    if (!$p) {
        return '';
    }
    return $prefix . '?action=avatar_name&username=' . rawurlencode($username) . '&v=' . (int)@filemtime($p);
}

function fm_avatar_url(array $user): string
{
    return fm_avatar_url_for((string)($user['username'] ?? ''));
}

function fm_delete_avatar(int $uid): void
{
    $db = fm_db();
    $uname = '';
    if ($db) {
        try {
            $st = $db->prepare('SELECT username FROM fm_user WHERE id = ? LIMIT 1');
            $st->execute([$uid]);
            $uname = (string)($st->fetchColumn() ?: '');
        } catch (Throwable $e) {
            $uname = '';
        }
    }
    $dir = fm_avatar_dir();
    $slug = $uname !== '' ? fm_to_sys(fm_user_dir_name($uname)) : '';
    foreach (fm_avatar_exts() as $ext) {
        foreach (array_filter([$slug, 'u' . $uid]) as $prefix) {
            $p = $dir . '/' . $prefix . '.' . $ext;
            if (is_file($p)) {
                @unlink($p);
            }
        }
    }
    if ($db) {
        try {
            $db->prepare('UPDATE fm_user SET avatar = ? WHERE id = ?')->execute(['', $uid]);
        } catch (Throwable $e) {
            // 忽略
        }
    }
}

/**
 * 保存头像（同名覆盖：先清掉旧扩展名文件）
 */
function fm_save_avatar(int $uid, array $file, ?string &$error = null): bool
{
    $error = null;
    if ($uid <= 0) {
        $error = '用户不存在';
        return false;
    }
    if ((int)($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK
        || !isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
        $error = '没有收到有效的头像文件';
        return false;
    }
    if ((int)($file['size'] ?? 0) > 3 * 1024 * 1024) {
        $error = '头像不能超过 3MB';
        return false;
    }
    $info = @getimagesize($file['tmp_name']);
    $allowed = [
        IMAGETYPE_JPEG => 'jpg',
        IMAGETYPE_PNG  => 'png',
        IMAGETYPE_WEBP => 'webp',
        IMAGETYPE_GIF  => 'gif',
    ];
    if (!$info || !isset($allowed[$info[2]])) {
        $error = '仅支持 JPG、PNG、WEBP、GIF 图片';
        return false;
    }
    $ext = $allowed[$info[2]];
    $dir = fm_avatar_dir();
    if (!is_dir($dir)) {
        $error = '无法创建头像目录，请检查 storage 写入权限';
        return false;
    }

    $db = fm_db();
    $uname = '';
    if ($db) {
        try {
            $st = $db->prepare('SELECT username FROM fm_user WHERE id = ? LIMIT 1');
            $st->execute([$uid]);
            $uname = (string)($st->fetchColumn() ?: '');
        } catch (Throwable $e) {
            $uname = '';
        }
    }
    if ($uname === '') {
        $error = '用户不存在';
        return false;
    }

    // 统一存放在 storage/avatars，文件名使用账号，保证一个账号只有一个头像
    $slug = fm_to_sys(fm_user_dir_name($uname));
    $name = $slug . '.' . $ext;
    $target = $dir . '/' . $name;

    foreach (fm_avatar_exts() as $e) {
        foreach (array_filter([$slug, 'u' . $uid]) as $prefix) {
            $old = $dir . '/' . $prefix . '.' . $e;
            if (is_file($old)) {
                @unlink($old);
            }
        }
    }
    if (!@move_uploaded_file($file['tmp_name'], $target)) {
        $error = '保存头像失败，请检查目录权限';
        return false;
    }
    @chmod($target, 0644);
    if ($db) {
        try {
            $db->prepare('UPDATE fm_user SET avatar = ? WHERE id = ?')->execute([$name, $uid]);
        } catch (Throwable $e) {
            // 忽略
        }
    }

    // 同时保存一份到用户个人目录（删除用户时会随目录一起清理）
    $udir = fm_user_dir($uname);
    if (!is_dir($udir)) {
        @mkdir($udir, 0775, true);
    }
    if (is_dir($udir)) {
        foreach (fm_avatar_exts() as $e) {
            $old = $udir . DIRECTORY_SEPARATOR . 'avatar.' . $e;
            if (is_file($old)) {
                @unlink($old);
            }
        }
        @copy($target, $udir . DIRECTORY_SEPARATOR . 'avatar.' . $ext);
    }
    return true;
}

/**
 * 用户个人目录：<全局根>/<账号>（直接放在根目录下）
 */
/**
 * 合并移动目录：把 $src 的内容移动到 $dst（同名项保留目标、目录递归合并）
 */
function fm_merge_move_dir(string $src, string $dst): void
{
    if (!is_dir($dst)) {
        @mkdir($dst, 0775, true);
    }
    $items = @scandir($src) ?: [];
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }
        $s = $src . DIRECTORY_SEPARATOR . $item;
        $d = $dst . DIRECTORY_SEPARATOR . $item;
        if (!file_exists($d)) {
            @rename($s, $d);
        } elseif (is_dir($s) && is_dir($d)) {
            fm_merge_move_dir($s, $d);
        }
    }
    @rmdir($src);
}

function fm_user_dir(string $username): string
{
    $base = fm_base_root();
    $name = fm_to_sys(fm_user_dir_name($username));
    $dir = $base . DIRECTORY_SEPARATOR . $name;
    // 兼容旧版 users 子目录：迁移并合并到根目录下的账号文件夹
    $legacy = $base . DIRECTORY_SEPARATOR . 'users' . DIRECTORY_SEPARATOR . $name;
    if (is_dir($legacy) && $legacy !== $dir) {
        if (!is_dir($dir)) {
            @rename($legacy, $dir);
        } else {
            fm_merge_move_dir($legacy, $dir);
        }
    }
    return $dir;
}

function fm_ensure_user_dir(string $username): void
{
    $dir = fm_user_dir($username);
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
}

/**
 * 删除用户的所有内容：头像 + 个人目录
 */
function fm_purge_user_files(int $uid, string $username): void
{
    fm_delete_avatar($uid);
    $dir = fm_user_dir($username);
    if (is_dir($dir)) {
        fm_rmdir_recursive($dir);
    }
}

function fm_copy_recursive(string $src, string $dst): bool
{
    if (is_dir($src) && !is_link($src)) {
        if (!is_dir($dst) && !@mkdir($dst, 0775, true)) {
            return false;
        }
        $items = @scandir($src) ?: [];
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }
            if (!fm_copy_recursive($src . DIRECTORY_SEPARATOR . $item, $dst . DIRECTORY_SEPARATOR . $item)) {
                return false;
            }
        }
        return true;
    }
    return @copy($src, $dst);
}

function fm_dir_size(string $dir, int $limit = 50000): int
{
    $total = 0;
    $count = 0;
    $stack = [$dir];
    while ($stack) {
        $cur = array_pop($stack);
        $items = @scandir($cur);
        if ($items === false) {
            continue;
        }
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }
            if (++$count > $limit) {
                return $total;
            }
            $p = $cur . DIRECTORY_SEPARATOR . $item;
            if (is_dir($p) && !is_link($p)) {
                $stack[] = $p;
            } else {
                $total += (int)@filesize($p);
            }
        }
    }
    return $total;
}

function fm_ext(string $name): string
{
    return strtolower((string)pathinfo($name, PATHINFO_EXTENSION));
}

function fm_item(string $abs, string $relPath): array
{
    $isDir = is_dir($abs);
    $name = fm_from_sys(basename($abs));
    return [
        'name'  => $name,
        'path'  => $relPath,
        'type'  => $isDir ? 'dir' : 'file',
        'size'  => $isDir ? 0 : (int)@filesize($abs),
        'mtime' => (int)@filemtime($abs),
        'ext'   => $isDir ? '' : fm_ext($name),
    ];
}

function fm_mime(string $ext): string
{
    $map = [
        'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif',
        'webp' => 'image/webp', 'bmp' => 'image/bmp', 'svg' => 'image/svg+xml', 'ico' => 'image/x-icon',
        'avif' => 'image/avif', 'heic' => 'image/heic',
        'mp4' => 'video/mp4', 'webm' => 'video/webm', 'mov' => 'video/quicktime', 'mkv' => 'video/x-matroska',
        'mp3' => 'audio/mpeg', 'wav' => 'audio/wav', 'ogg' => 'audio/ogg', 'flac' => 'audio/flac',
        'm4a' => 'audio/mp4', 'aac' => 'audio/aac',
        'pdf' => 'application/pdf', 'txt' => 'text/plain; charset=utf-8', 'md' => 'text/plain; charset=utf-8',
        'json' => 'application/json; charset=utf-8', 'xml' => 'text/xml; charset=utf-8',
        'html' => 'text/html; charset=utf-8', 'css' => 'text/css; charset=utf-8',
        'js' => 'text/javascript; charset=utf-8', 'php' => 'text/plain; charset=utf-8',
        'zip' => 'application/zip', 'rar' => 'application/vnd.rar', '7z' => 'application/x-7z-compressed',
        'gz' => 'application/gzip', 'tar' => 'application/x-tar',
    ];
    return $map[$ext] ?? 'application/octet-stream';
}

/* ------------------------------------------------------------------ *
 *  主题 / 站点辅助
 * ------------------------------------------------------------------ */

function fm_site_name(): string
{
    return fm_setting('site_name', '樱屿文件管理器');
}

function fm_site_tagline(): string
{
    return fm_setting('site_tagline', '把每一份文件，安放在温柔的地方');
}

function fm_json_out_response(Throwable $e): void
{
    fm_json(['ok' => false, 'error' => $e->getMessage()], 400);
}
